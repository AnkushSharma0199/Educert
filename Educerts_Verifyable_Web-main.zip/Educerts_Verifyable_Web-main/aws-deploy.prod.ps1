Write-Host -ForegroundColor Yellow "Prod - Installing npm packages"
# npm install

Write-Host -ForegroundColor Yellow "`nProd - Building Project"
node --max_old_space_size=16384 ./node_modules/@angular/cli/bin/ng build --configuration production

Write-Host -ForegroundColor Yellow "`nProd - Deploying to S3"

#upload files
aws s3 cp ./dist s3://verifyable.net --recursive --acl public-read --profile Docker
write-host -ForegroundColor Yellow "`nProd - Successfully deployed"

Write-Host -ForegroundColor Yellow "`nProd - Invalidating cache"
aws cloudfront create-invalidation --paths /* --distribution-id --profile Docker

Read-Host -Prompt "`nPress Enter to exit"
