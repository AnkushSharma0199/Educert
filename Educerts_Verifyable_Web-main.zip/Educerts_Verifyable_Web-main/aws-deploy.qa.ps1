Write-Host -ForegroundColor Yellow "QA - Installing npm packages"
# npm install

Write-Host -ForegroundColor Yellow "`nQA - Building Project"
node --max_old_space_size=16384 ./node_modules/@angular/cli/bin/ng build --configuration qa

Write-Host -ForegroundColor Yellow "`nQA - Deploying to S3"

#upload files
aws s3 cp ./dist s3://verifyable.layered-security.com --recursive --acl public-read --profile DockerQA
write-host -ForegroundColor Yellow "`nQA - Successfully deployed"

Write-Host -ForegroundColor Yellow "`nQA - Invalidating cache"
aws cloudfront create-invalidation --paths /* --distribution-id E38UPHKMZSHANU --profile DockerQA

Read-Host -Prompt "`nPress Enter to exit"
