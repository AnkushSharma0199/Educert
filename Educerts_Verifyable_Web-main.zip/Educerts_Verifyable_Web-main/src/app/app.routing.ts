import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UserRole } from './app.enum';
import { ChangePasswordComponent } from './user/change-password/change-password.component';
import { EmailVerificationComponent } from './user/email-verification/email-verification.component';
import { FirstChangePasswordComponent } from './user/first-change-password/first-change-password.component';
import { ResetPasswordComponent } from './user/reset-password/reset-password.component';
import { SignInComponent } from './user/sign-in/sign-in.component';
import { SignUpComponent } from './user/sign-up/sign-up.component';
import { ProfileComponent } from './user/profile/profile.component';
import { AuthenticationGuard } from './core/authentication.guard';
import { DashboardComponent } from './dashboard/dashboard/dashboard.component';




const routes: Routes = [

    { path: '', redirectTo: 'signIn', pathMatch: 'full', },
    { path: 'signUp', component: SignUpComponent },
    { path: 'signIn', component: SignInComponent },
    { path: 'reset-password', component: ResetPasswordComponent },
    { path: 'email-verification', component: EmailVerificationComponent },
    { path: 'first-change-password', component: FirstChangePasswordComponent },
    { path: 'change-password', component: ChangePasswordComponent, canActivate: [AuthenticationGuard] },
    { path: 'profile', component: ProfileComponent, canActivate: [AuthenticationGuard] },
    { path: 'home', component: DashboardComponent, canActivate: [AuthenticationGuard] },
    { path: '**', redirectTo: 'home' },
];

@NgModule({
    imports: [
        RouterModule.forRoot(routes, {
            useHash: false,
        }),
    ],
    exports: [],
})
export class AppRoutingModule { }
