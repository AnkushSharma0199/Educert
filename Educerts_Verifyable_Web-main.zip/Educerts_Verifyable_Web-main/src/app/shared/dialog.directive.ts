import {
    Directive,
    HostListener,
    OnInit,
    Output,
    EventEmitter,
    Input,
} from '@angular/core';
import { MatDialogConfig, MatDialog } from '@angular/material/dialog';
import { DialogConfirmationComponent } from '../shared/dialog-confirmation/dialog-confirmation.component';

@Directive({
    selector: '[appDialog]',
})
export class DialogDirective implements OnInit {
    @Input() appDialog: 'alert' | 'input' = 'alert';
    @Input() dialogEnabled = true;
    @Input() dialogIcon = '';

    @Input() dialogTitle = '';
    @Input() dialogDescription = '';
    @Input() dialogDescriptionBold = '';
    @Input() dialogNote = '';

    @Input()
    dialogButtons: {
        path: string | string[];
        name: string;
        type: string;
        value: any;
    }[] = [];

    @Output() dialogResult = new EventEmitter<any>();
    dialogConfig = new MatDialogConfig();

    constructor(public dialog: MatDialog) {}

    ngOnInit() {
        this.dialogConfig.panelClass = 'confirmation-popup'
        this.dialogConfig.disableClose = true;
        this.dialogConfig.autoFocus = true;
        this.dialogConfig.data = {
            icon: this.dialogIcon,
            title: this.dialogTitle,
            description: this.dialogDescription,
            descriptionBold: this.dialogDescriptionBold,
            note: this.dialogNote,
            buttons: this.dialogButtons,
        };
    }

    // Open the Popup on button click
    @HostListener('click', ['$event'])
    handleClick(event: Event) {
        const dialogRef = this.dialog.open(
            DialogConfirmationComponent,
            this.dialogConfig
        );
        dialogRef.afterClosed().subscribe((result) => {
            this.dialogResult.emit(result);
        });
    }
}
