import { Component, Input } from '@angular/core';

@Component({
    selector: 'app-pdf-preview',
    templateUrl: './pdf-preview.component.html',
    styleUrls: []
})
export class PdfPreviewComponent {
    @Input() filePath;
}
