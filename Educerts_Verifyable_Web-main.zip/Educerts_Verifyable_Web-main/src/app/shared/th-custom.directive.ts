import { Directive, AfterViewInit, ElementRef, Renderer2 } from '@angular/core';

@Directive({
    // tslint:disable-next-line:directive-selector
    selector: 'th',
})
export class ThCustomDirective implements AfterViewInit {
    constructor(public el: ElementRef, public renderer: Renderer2) { }

    ngAfterViewInit() {
        // user renderer to render the element with styles
        setTimeout(
            () =>
                this.renderer.setAttribute(
                    this.el.nativeElement,
                    'title',
                    this.el.nativeElement.innerText,
                ),
            0,
        );
    }
}
