import { Directive, ElementRef, Renderer2, AfterViewInit, Input, } from '@angular/core';

@Directive({
    // tslint:disable-next-line:directive-selector
    selector: 'td',
})
export class TdCustomDirective implements AfterViewInit {
    @Input() noTooltip = false;
    constructor(public el: ElementRef, public renderer: Renderer2) { }
    ngAfterViewInit() {
        // Use renderer to render the element with styles
        if (!this.noTooltip) {
            this.renderer.setAttribute(
                this.el.nativeElement,
                'title',
                this.el.nativeElement.innerText,
            );
        }
    }
}
