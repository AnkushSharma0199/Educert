import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { TranslateModule } from '@ngx-translate/core';
import { RouterModule } from '@angular/router';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatMenuModule } from '@angular/material/menu';
import { MatListModule } from '@angular/material/list';
import { CoreModule } from 'app/core/core.module';
import { PipeModule } from 'app/pipe/pipe.module';
import { PdfViewerModule } from 'ng2-pdf-viewer';

import { DialogDirective } from './dialog.directive';
import { PdfPreviewComponent } from './pdf-preview/pdf-preview.component';
import { DialogConfirmationComponent } from './dialog-confirmation/dialog-confirmation.component';
import { LoadingSpinnerComponent } from './loading-spinner/loading-spinner.component';
import { ToolTipDirective } from './tooltip.directive';
import { TdCustomDirective } from './td-custom.directive';
import { ThCustomDirective } from './th-custom.directive';
import { NoDataFoundComponent } from './no-data-found/no-data-found.component';
import { FooterComponent } from './footer/footer.component';
import { HeaderComponent } from './header/header.component';

@NgModule({
    declarations: [
        LoadingSpinnerComponent,
        DialogConfirmationComponent,
        PdfPreviewComponent,
        DialogDirective,
        ToolTipDirective,
        TdCustomDirective,
        ThCustomDirective,
        NoDataFoundComponent,
        FooterComponent,
        HeaderComponent,
    ],
    imports: [
        CommonModule,
        CoreModule,
        PdfViewerModule,
        RouterModule,
        MatMenuModule,
        TranslateModule,
        MatSidenavModule,
        MatListModule,
        PipeModule,
    ],
    exports: [
        LoadingSpinnerComponent,
        DialogConfirmationComponent,
        PdfPreviewComponent,
        NoDataFoundComponent,
        FooterComponent,
        HeaderComponent,
        DialogDirective,
        ToolTipDirective,
        TdCustomDirective,
        ThCustomDirective
    ],
    providers: []
})
export class SharedModule { }
