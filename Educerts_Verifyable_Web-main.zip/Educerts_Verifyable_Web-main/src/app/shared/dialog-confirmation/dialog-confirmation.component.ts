import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
    selector: 'app-dialog-confirmation',
    templateUrl: './dialog-confirmation.component.html',
    styleUrls: [],
})
export class DialogConfirmationComponent implements OnInit {
    modalTitle: string;
    constructor(@Inject(MAT_DIALOG_DATA) public data: any) {
    }

    ngOnInit() { }

}
