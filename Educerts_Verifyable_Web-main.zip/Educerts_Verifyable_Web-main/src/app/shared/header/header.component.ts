import { Component, Input, OnChanges, OnDestroy, OnInit, SimpleChanges } from '@angular/core';
import { NavigationEnd, Router, ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs';
import { environment } from 'environments/environment';
import { UserData } from 'app/app.interface';
import { SharedService } from 'app/service/shared.service';
import { UserService } from 'app/service/user.service';
import { SessionStoreService } from 'app/service/session-store.service';
import { thru } from 'lodash';

@Component({
    selector: 'app-header',
    templateUrl: './header.component.html',
    styleUrls: ['./header.component.css'],
})
export class HeaderComponent implements OnInit, OnChanges, OnDestroy {
    @Input() public isAuthorized = true;
    public sidebarOpened = false;
    public currentParentRoute = 'home'; // By default, set to dashboard
    parent: string;
    child: string;
    subChild: string;
    isUserDocOwner = false;
    isChecker = false;
    isMaker = false;
    isPublisher = false;
    isStateRegulator = false;
    isOrgAdmin = false;
    isApprover = false;
    isUploader = false;
    isNationalRegulator = false;
    isAdmin = false;
    isDocOwner = false;
    isSalesPartner = false;
    isRegUser = false;
    isApprUser = false;
    organizationNameFromParam: string = null;
    fullName = '';
    defaultCountryName = environment.uiSettings.defaultCountry.name;
    appInstance = environment.appInstance;
    public sidebarToggleSubscription: Subscription;
    public routeChangeSubscription: Subscription;
    public userData : UserData;
    public authSubscription: Subscription;

    constructor(
        private userService: UserService,
        private router: Router,
        private route: ActivatedRoute,
        private sharedService: SharedService,
        private sessionStoreService: SessionStoreService,
    ) {
        this.userData = userService.getUserData();
        this.isChecker = this.sharedService.isChecker()
        this.isMaker = this.sharedService.isMaker()
        this.isApprover = this.sharedService.isApprover()
        this.isStateRegulator = this.sharedService.isStateRegulator()
        this.isNationalRegulator = this.sharedService.isNationalRegulator()
        this.isAdmin = this.sharedService.isAdmin()
        this.isDocOwner = this.sharedService.isUserDocOwner()
        this.isSalesPartner = this.sharedService.isSalesPartner()
        this.isUploader = this.sharedService.isUploader()
        this.isRegUser = this.sharedService.isRegUser()
        this.isApprUser = this.sharedService.isApprUser()
    }

    async ngOnInit() {
        this.sidebarToggleSubscription = this.sharedService.onSidebarToggle.subscribe(
            (x: boolean) => {
                this.sidebarOpened = x
            }
        );
        this.routeChangeSubscription = this.router.events.subscribe((x) => {
            if (x instanceof NavigationEnd) {
                // Set Module header On url Change
                this.currentParentRoute = x.url;

                const url = x.urlAfterRedirects;
                // splitting the route names and queryparams
                const urlArray = url.split('?');
                const routeNamesArray = urlArray[0] ? urlArray[0].split('/') : '';
                this.parent = routeNamesArray[1];
                this.child = routeNamesArray[2] ? routeNamesArray[2] : '';
                this.subChild = routeNamesArray[3] || '';

                this.organizationNameFromParam = this.route.snapshot.queryParamMap.get('organizationName');
            }
        });

        this.authSubscription = this.userService.authUpdated.subscribe(
            (data: UserData) => {
                if (data) {
                    // set auth in header on change
                    this.userData = data;
                    this.fullName = this.sharedService.getFullName(this.userData?.firstName, this.userData?.middleName, this.userData?.lastName)
                    this.isChecker = this.sharedService.isChecker()
                    this.isMaker = this.sharedService.isMaker()
                    this.isApprover = this.sharedService.isApprover()
                    this.isPublisher= this.sharedService.isPublisher()
                    this.isOrgAdmin = this.sharedService.isOrgAdmin()
                    this.isStateRegulator = this.sharedService.isStateRegulator()
                    this.isNationalRegulator = this.sharedService.isNationalRegulator()
                    this.isAdmin = this.sharedService.isAdmin()
                    this.isDocOwner = this.sharedService.isUserDocOwner()
                    this.isSalesPartner = this.sharedService.isSalesPartner()
                    this.isRegUser = this.sharedService.isRegUser();
                    this.isApprUser = this.sharedService.isApprUser();
                }
            }
        );
    }

    getChildRoute() {
        return 'module.' + this.child;
    }

    ngOnChanges(changes: SimpleChanges): void {
        if (changes.isAuthorized) {
            this.isAuthorized = changes.isAuthorized.currentValue;
            this.sidebarOpened = !this.isAuthorized;
        }
    }

    ngOnDestroy(): void {
        this.sidebarToggleSubscription.unsubscribe();
        this.routeChangeSubscription.unsubscribe();
        this.authSubscription.unsubscribe();
    }

    logOut() {
        this.userService.logOut();
        this.router.navigate(['signIn']);
    }

    toggleSidebar() {
        this.sharedService.onSidebarToggle.emit(!this.sidebarOpened);
    }

    openHelpUrl() {
        window.open(this.sessionStoreService.getInitConfig()?.helpUrl)
    }
}
