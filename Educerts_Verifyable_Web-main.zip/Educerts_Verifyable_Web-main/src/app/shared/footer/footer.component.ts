import { Component, Input, OnInit, OnChanges, SimpleChanges, OnDestroy } from '@angular/core';
import * as _ from 'lodash';
import { Subscription } from 'rxjs';
import { environment } from 'environments/environment';
import { SessionStoreService } from 'app/service/session-store.service';

@Component({
    selector: 'app-footer',
    templateUrl: './footer.component.html',
    styleUrls: ['./footer.component.css']
})
export class FooterComponent implements OnInit, OnChanges, OnDestroy {
    @Input() public isAuthorized = true;
    public copyrightMsg = ''
    public phone = ''
    public email = ''
    public appVersion = environment.appVersion;
    appInstance = environment.appInstance;
    currentYear = new Date().getFullYear();
    appConfigUpdatedSubscription: Subscription = null;

    constructor(
        private sessionStoreService: SessionStoreService
    ) { }

    ngOnInit() {
        this.appConfigUpdatedSubscription = this.sessionStoreService.appConfigUpdated.subscribe((appConfig) => {
            this.copyrightMsg = appConfig?.copyrightMsg;
            this.phone = appConfig?.phone;
            this.email = appConfig?.email;
        });
    }

    ngOnChanges(changes: SimpleChanges): void {
        if (changes.isAuthorized) {
            this.isAuthorized = changes.isAuthorized.currentValue;
        }
    }

    ngOnDestroy(): void {
        if (this.appConfigUpdatedSubscription) {
            this.appConfigUpdatedSubscription.unsubscribe();
        }
    }
}
