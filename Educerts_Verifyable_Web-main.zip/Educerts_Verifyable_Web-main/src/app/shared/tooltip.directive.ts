import { Directive, HostListener, Input } from '@angular/core';
import { MatTooltip } from '@angular/material/tooltip';

@Directive({
    selector: '[appTooltip]',
    providers: [MatTooltip]
})
// TODO- implement tooltip through directive
export class ToolTipDirective {

    matToolTip: MatTooltip;

    @Input() appTooltip = '';

    constructor(tooltip: MatTooltip) {
        this.matToolTip = tooltip;
    }

    @HostListener('mouseover') mouseover() {
        this.matToolTip.message = this.appTooltip;
        this.matToolTip.show();
    }

    @HostListener('mouseleave') mouseleave() {
        this.matToolTip.hide();
    }
}
