import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { SharedService } from 'app/service/shared.service';
import { Subscription } from 'rxjs';

@Component({
    selector: 'app-idle-timeout-dialog',
    templateUrl: './idle-timeout-dialog.component.html',
    styleUrls: ['./idle-timeout-dialog.component.css']
})
export class IdleTimeoutDialogComponent {

    message = ''
    counterIdleTimeoutSubscription: Subscription
    constructor(
        @Inject(MAT_DIALOG_DATA) private data: any,
        private sharedService: SharedService) {

        this.counterIdleTimeoutSubscription = this.sharedService.counterIdleTimeout.subscribe(countdown => {
            if (countdown) {
                this.message = 'You will be time out in ' + countdown + ' seconds!'
            }
        })
    }

    onDestroy() {
        if (this.counterIdleTimeoutSubscription) {
            this.counterIdleTimeoutSubscription.unsubscribe();
        }
    }

}
