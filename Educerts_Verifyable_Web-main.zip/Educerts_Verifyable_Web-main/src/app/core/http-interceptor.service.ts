import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { from, Observable } from 'rxjs';
import * as publicIp from 'public-ip'
import { SessionStoreService } from 'app/service/session-store.service';
import { UserRole } from 'app/app.enum';

@Injectable({
    providedIn: 'root',
})
export class HttpInterceptorService implements HttpInterceptor {
    constructor(private sessionStorageService: SessionStoreService) { }

    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        // convert promise to observable using 'from' operator
        return from(this.handle(req, next))
    }

    async handle(req: HttpRequest<any>, next: HttpHandler): Promise<HttpEvent<any>> {
        let headers = req.headers

        // Get the user data from the service.
        const authData = this.sessionStorageService.getUserData();
        if (authData && authData.id) {
            headers = headers.set('Authorization', 'Bearer ' + authData.accessToken);
        }

        // Send IP address only when user type is maker
        if (authData && authData.role === UserRole.Maker) {
            const ipAddress = await publicIp.default.v4();
            headers = headers.set('Public-Ip', ipAddress);
        }

        return next.handle(req.clone({ headers })).toPromise();
    }
}
