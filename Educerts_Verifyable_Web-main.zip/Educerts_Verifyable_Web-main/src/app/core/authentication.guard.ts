import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { SessionStoreService } from 'app/service/session-store.service';
import { UserService } from '../service/user.service';

@Injectable({
    providedIn: 'root'
})
export class AuthenticationGuard implements CanActivate {

    constructor(
        private router: Router,
        private userService: UserService,
        private sessionStoreService: SessionStoreService
    ) { }

    /**
     * Check if the user is logged in before calling http
     *
     * @param route
     * @param state
     * @returns {boolean}
     */
    canActivate(
        route: ActivatedRouteSnapshot,
        state: RouterStateSnapshot
    ): Observable<boolean> | Promise<boolean> | boolean {
        if (this.userService.isSignedIn()) {
            /**when we navigate to dashboard without going through app component
            then auth data is null, so sidebar and header component not gets loaded
            So, initializing the auth data from session storage value**/
            this.userService.AuthData = this.sessionStoreService.getUserData()
            const userRole = this.sessionStoreService.getUserData()?.role;

            // protecting routes based on user role
            if (!route.data.roles || route.data.roles.indexOf(userRole) !== -1) {
                return true;
            }
        }
        this.router.navigate(['signIn'], { queryParams: { returnUrl: state.url } });
        return;
    }
}
