export enum UserRole {
    Admin = 1,
    SalesPartner = 2,
    Maker = 3,
    NationalRegulator = 4,
    StateRegulator = 5,
    DocOwner = 6,
    Checker = 7,
    Approver = 8,
    Publisher = 9,
    OrgAdmin = 10,
    Uploader = 11,
    RegUser = 12,
    ApprUser = 13,
}

export enum AppType {
    Portal,
    App,
}


export enum DocFlowUserStatusEnum {
    Disabled = 0,
    Enabled = 1,
}

/**
 * Snackbar notifications
 */

export enum NotificationTypeEnum {
    Info = 'info',
    Danger = 'danger',
    Warning = 'warning',
    Success = 'success',
}

/**
 * Status of Active/Inactive, used in Account/User table
 */
export enum StatusEnum {
    Disabled,
    Enabled,
    Invited
}

export enum ReportFormatType {
    xlsx = 'XLSX',
    pdf = 'PDF',
}

export enum TimeFilterInMonths {
    All = '',
    LastOneMonth = 1,
    LastSixMonths = 6,
    LastOneYear = 12,
    CustomDate = 'customDate'
}

export enum TimeFilterInDays {
    LastOneDay = 1,
    LastTwoDays = 2,
    LastThreeDays = 3,
    LastFourDays = 4,
    LastFiveDays = 5,
    LastSixDays = 6,
    LastSevenDays = 7,
    CustomDate = 'customDate'
}

export enum FieldTypeEnum {
    Number,
    String,
    Date,
    Email,
    Year,
    Dropdown
}

export enum DynamicFieldTypeEnum {
    // value 1 and 5 is from its related enum FieldTypeEnum. We need to show user different enum but it's values
    // stored in db must remain same
    Textbox = 1,
    Dropdown = 5
}

export enum OrganizationType {
    Issuing = 1,
    Verifying = 2,
}

export enum DocActivityStatusEnum {
    Pending,
    Drafted,
    Signed,
    Approved,
    Rejected,
    Discarded,
    Revoked,
    Published
}
