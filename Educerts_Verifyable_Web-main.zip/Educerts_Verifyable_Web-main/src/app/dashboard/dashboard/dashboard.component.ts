import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { UserData, DocumentCategoriesDto, CustomFields, DocOwnerDocumentQueryParam, DocumentResponseDto} from 'app/app.interface';
import { SessionStoreService } from 'app/service/session-store.service';
import { SharedService } from 'app/service/shared.service';
import { NotificationService } from 'app/service/notification.service';
import { NgForm, UntypedFormBuilder, UntypedFormGroup } from '@angular/forms';
import { FormControlValidators } from 'app/app.validator';
import { AccountService } from 'app/service/account.service';
import { DynamicFieldTypeEnum } from 'app/app.enum';
import * as _ from 'lodash';
import { SafeUrl } from '@angular/platform-browser';
import { DocService } from 'app/service/doc.service';

@Component({
    selector: 'app-dashboard',
    templateUrl: './dashboard.component.html',
    styleUrls: ['./dashboard.component.css'],
})
export class DashboardComponent implements OnInit, OnDestroy {

    @ViewChild('form', { static: true }) form: NgForm;
    userData: UserData = this.sessionStorageService.getUserData();
    public verifiableStudentForm: UntypedFormGroup;
    fieldTypeEnum = DynamicFieldTypeEnum;
    public loading = false;
    supportedDocumentCategories: DocumentCategoriesDto[] = [];
    customFields: CustomFields[] = []
    displayPdfPreview = false
    public previewFilePath: SafeUrl;
    documentDto: DocumentResponseDto;
    enableDownloadButton = false;
    lastSelectedDocumentCategory = '';
    yearSelected = '';
    academicYears = [2018, 2019, 2020, 2021, 2022, 2023];
    filteredCustomFieldValues = {};
    customFieldValues = {};

    constructor(
        private fb: UntypedFormBuilder,
        private accountService: AccountService,
        private sessionStorageService: SessionStoreService,
        private documentService: DocService,
        private sharedService: SharedService,
        private notificationService: NotificationService,
    ) {
        this.verifiableStudentForm = fb.group({
            rollNo: FormControlValidators.Required,
            academicYear: FormControlValidators.Required,
            documentCategory: FormControlValidators.Required
        });
    }

    async ngOnInit() {
        const accountSetting = await this.accountService.getAccountSettingsByAccountId(this.userData.accountId);
        this.supportedDocumentCategories = accountSetting.supportedDocumentCategories;
        // let orgId = this.userData.accountId ? this.userData.accountId : '';
        // if (window && localStorage && (this.getWithExpiry("organizationId") === null || this.getWithExpiry("organizationId") !== orgId)) {
        //     // console.log("uncached")
        //     this.setWithExpiry("organizationId", orgId, this.daysToMilliseconds(6));
        //     if (this.supportedDocumentCategories && this.supportedDocumentCategories.length) {
        //         this.supportedDocumentCategories.map(async (docCategory) => {
        //             let queryParam = {};
        //             queryParam['organizationId'] =  orgId;
        //             queryParam['documentCategory'] = docCategory.name;
                    
        //             this.customFields.forEach(f => {
        //                 queryParam[f.name] = docCategory[f.name] || '';
        //             });
                
        //             await this.documentService.getCustomFieldValues(queryParam)
        //             .then(res => {
        //                 this.customFieldValuesMap[docCategory.name] = res;
        //                 this.setWithExpiry(`${orgId}_${docCategory.name}`, res, this.daysToMilliseconds(6));
        //             });
        //         });
        //     }
        // } else if (orgId === this.getWithExpiry("organizationId")) {
        //     // console.log(this.getWithExpiry("organizationId"))
        //     // console.log("cached")
        //     if (this.supportedDocumentCategories && this.supportedDocumentCategories.length) {
        //         this.supportedDocumentCategories.map(async (docCategory) => {
        //             let queryParam = {};
        //             queryParam['organizationId'] =  orgId;
        //             queryParam['documentCategory'] = docCategory.name;
                    
        //             this.customFields.forEach(f => {
        //                 queryParam[f.name] = docCategory[f.name] || '';
        //             });
        //             // console.log(this.getWithExpiry(`${orgId}_${docCategory.name}`))
        //             this.customFieldValuesMap[docCategory.name] = this.getWithExpiry(`${orgId}_${docCategory.name}`);
        //         });
        //     }
        // }

        // if (this.supportedDocumentCategories && this.supportedDocumentCategories.length) {
        //     this.supportedDocumentCategories.map(async (docCategory) => {
        //         let queryParam = {};
        //         queryParam['organizationId'] =  orgId;
        //         queryParam['documentCategory'] = docCategory.name;

        //         this.customFields.forEach(f => {
        //             queryParam[f.name] = docCategory[f.name] || '';
        //         });
            
        //         await this.documentService.getCustomFieldValues(queryParam)
        //         .then(res => {
        //             this.customFieldValuesMap[docCategory.name] = res;
        //         });
        //     });
        // }
    }

    reloadPage() {
        document.location.href = "/";
    }

    setWithExpiry(key, value, ttl) {
        const now = new Date()

        // `item` is an object which contains the original value
        // as well as the time when it's supposed to expire
        const item = {
            value: value,
            expiry: now.getTime() + ttl,
        }
        localStorage.setItem(key, JSON.stringify(item))
    }

    getWithExpiry(key) {
        const itemStr = localStorage.getItem(key)

        // if the item doesn't exist, return null
        if (!itemStr) {
            return null
        }

        const item = JSON.parse(itemStr)
        const now = new Date()

        // compare the expiry time of the item with the current time
        if (now.getTime() > item.expiry) {
            // If the item is expired, delete the item from storage
            // and return null
            localStorage.removeItem(key)
            return null
        }
        return item.value
    }

    daysToMilliseconds(days) {
        // 👇️                   hour  min  sec  ms
        return Math.round(days * 24 * 60 * 60 * 1000);
      }

    async verifiableStudent(data){
        await this.getDocByCategory();

        if(!(_.isEmpty(this.documentDto))){
            this.previewDocument(this.documentDto?.uniqueId);
        }else{
            this.displayPdfPreview = false;
            this.enableDownloadButton = false;
            this.previewFilePath = '';
            this.notificationService.errorToastNotification('documentNotFound');
        }

    }

    get f(){
        return this.verifiableStudentForm.controls; 
    }
     
    onChangeAcademicYear(academicYear) {
        this.yearSelected = academicYear;
        const documentCategory = this.lastSelectedDocumentCategory;
        const year = parseInt(academicYear);
        console.log(this.yearSelected);
        // debugger
        // for (const customField in this.customFieldValues) {
        //     this.filteredCustomFieldValues = this.customFieldValues;
        //     console.log(this.filteredCustomFieldValues)
        //     break;
        // }
        // debugger
        let orgId = this.userData.accountId ? this.userData.accountId : '';
        // TO REFACTOR
        this.setCustomFieldsForMpBoard(orgId, this.lastSelectedDocumentCategory);
        if (this.customFieldValues && this.customFieldValues["customField1"]) {
            const customField1 = this.customFieldValues["customField1"];
            const customField2 = this.customFieldValues["customField2"];
            if (documentCategory.startsWith("D.El.Ed")) {
                this.filteredCustomFieldValues["customField1"] = customField1.filter(customField => {
                    var customFieldYear = parseInt(customField.split('-')[1]);
                    var customFieldSemester = customField.split('-')[0];
                    return (customFieldYear === year && customFieldSemester === 'FIRST/SEPTEMBER') ||
                        (customFieldYear === (year + 1) && customFieldSemester === 'SECOND/MARCH') ?
                            true : false
                });
            } 
        }
        
        // this.filteredCustomFieldValues.filter(c => {
        //     var a = parseInt(c.split('-')[1]);
        //     var b = c.split('-')[0];
        //     // console.log(a,b);
        //     if ((a === myY && b === 'FIRST/SEPTEMBER') || (a === myY + 1 && b === 'SECOND/MARCH')) {
        //         return (a + " " + b);

        //     }
        // });
    }




    // async onChangeDocumentCategory(documentCategory){
    //     let orgId = this.userData.accountId ? this.userData.accountId : ''; 
    //     this.yearSelected = '';
    //     // Removed the validation of previous documentCategory
    //     if(!this.lastSelectedDocumentCategory){
    //         this.lastSelectedDocumentCategory = documentCategory;
    //     }else {
    //         const customFields = this.getCustomFields(this.lastSelectedDocumentCategory);
    //         customFields.forEach( x => this.verifiableStudentForm.removeControl(x.name));
    //         this.lastSelectedDocumentCategory = documentCategory;
    //     }

    //     // Assign customFields of selected documentCategory 
    //     this.customFields = this.getCustomFields(documentCategory);
    
    //     // update filter form with custom fields
    //     if(this.customFields){
    //         this.customFields?.forEach( f => {    
    //             this.verifiableStudentForm.addControl(f.name, FormControlValidators.Required);
    //         });
    //     }

    //     // if (this.customFieldValuesMap[documentCategory]) {
    //     //     this.customFieldValues = this.customFieldValuesMap[documentCategory];
    //     // } else {
    //         // change custom field options on change of document category
    //         // debugger
    //         if (orgId === "64f4e3fb54817103f4f29589") {
    //             switch(documentCategory) {
    //                 case 'D.El.Ed1':
    //                     this.customFieldValues = {
    //                         "customField1": [
    //                             "FIRST/SEPTEMBER-2022",
    //                             "SECOND/MARCH-2023"
    //                         ],
    //                         "customField2": [
    //                             "D.El.Ed 1st year"
    //                         ]
    //                     }
    //                     break;
    //                 case 'D.El.Ed2':
    //                     this.customFieldValues = {
    //                         "customField1": [
    //                             "FIRST/SEPTEMBER-2022",
    //                             "SECOND/MARCH-2023"
    //                         ],
    //                         "customField2": [
    //                             "D.El.Ed 2nd year"
    //                         ]
    //                     }
    //                     break;
    //                 case '12th':
    //                     this.customFieldValues = {
    //                         "customField1": [
    //                             "Main"
    //                         ], 
    //                         "customField2": [
    //                             "12th"
    //                         ]
    //                     }
    //                     break;
    //                 case '10th': {
    //                     this.customFieldValues = {
    //                         "customField1": [
    //                             "Main"
    //                         ],
    //                         "customField2": [
    //                             "10th"
    //                         ]
    //                     }
    //                     break;
    //                 }
    //                 default: 
    //                     const query = this.makeQueryParams(true);
    //                     const res = await this.documentService.getCustomFieldValues(query);
    //                     this.customFieldValues = res;
    //                     break;
    //             }
    //         } else {
    //             const query = this.makeQueryParams(true);
    //             const res = await this.documentService.getCustomFieldValues(query);
    //             this.customFieldValues = res;
    //         }
            
    //         // TO FIX
    //         // const query = this.makeQueryParams(true);
    //         // const res = await this.documentService.getCustomFieldValues(query);
    //         // this.customFieldValues = res;
    //     // }

    //     // Select default option if number of options is not more than one
    //     if(this.customFields){
    //         this.customFields?.forEach( f => {    
    //             if (this.customFieldValues[f.name]?.length === 1) {
    //                 this.verifiableStudentForm.get(f.name)
    //                     .setValue(this.customFieldValues[f.name][0])
    //             }
    //         });
    //     }
    // }
    async onChangeDocumentCategory(documentCategory) {
        let orgId = this.userData.accountId ? this.userData.accountId : '';
        this.yearSelected = '';
        // Removed the validation of previous documentCategory
        if (!this.lastSelectedDocumentCategory) {
            this.lastSelectedDocumentCategory = documentCategory;
        } else {
            const customFields = this.getCustomFields(this.lastSelectedDocumentCategory);
            customFields.forEach(x => this.verifiableStudentForm.removeControl(x.name));
            this.lastSelectedDocumentCategory = documentCategory;
        }

        // Assign customFields of selected documentCategory 
        this.customFields = this.getCustomFields(documentCategory);

        // update filter form with custom fields
        if (this.customFields) {
            this.customFields?.forEach(f => {
                this.verifiableStudentForm.addControl(f.name, FormControlValidators.Required);
            });
        }

        // TO REMOVE
        this.setCustomFieldsForMpBoard(orgId, documentCategory);

        // TO FIX
        // let customField1ForDlEd= [
        //     "FIRST/SEPTEMBER-2018",
        //     "SECOND/MARCH-2019",
        //     "FIRST/SEPTEMBER-2019",
        //     "SECOND/MARCH-2020",
        //     "FIRST/SEPTEMBER-2020",
        //     "SECOND/MARCH-2021",
        //     "FIRST/SEPTEMBER-2021",
        //     "SECOND/MARCH-2022",
        //     "FIRST/SEPTEMBER-2022",
        //     "SECOND/MARCH-2023",
        //     "FIRST/SEPTEMBER-2023",
        //     "SECOND/MARCH-2024"
        // ];
        // let customField2For10thand12th = [
        //     "Main",
        //     "Supplementary"
        // ];

        // if (this.yearSelected) {
        //     customField1ForDlEd.filter(customField => {
        //         var customFieldYear = customField.split('-')[1];
        //         var customFieldSemester = customField.split('-')[0];
        //         (customFieldYear === year && customFieldSemester === 'FIRST/SEPTEMBER') ||
        //             (customFieldYear === (year + 1) && customFieldSemester === 'SECOND/MARCH') ?
        //                 true : false
        //     })
        // }

        // if (this.customFieldValuesMap[documentCategory]) {
        //     this.customFieldValues = this.customFieldValuesMap[documentCategory];
        // } else {
        // change custom field options on change of document category
        // if (orgId === "64f4e3fb54817103f4f29589" 
        //     || orgId === "62b9ce9721ec852188cece0e" 
        //     /* MP board org ids for QA and Prod */
        //     ) {
        //     switch (documentCategory) {
        //         case 'D.El.Ed1':
        //             this.customFieldValues = {
        //                 customField1: customField1ForDlEd,
        //                 customField2: [
        //                     "D.El.Ed 1st year"
        //                 ]
        //             }
        //             break;
        //         case 'D.El.Ed2':
        //             this.customFieldValues = {
        //                 customField1: customField1ForDlEd,
        //                 customField2: [
        //                     "D.El.Ed 2nd year"
        //                 ]
        //             }
        //             break;
        //         case '12th':
        //             this.customFieldValues = {
        //                 customField1: customField2For10thand12th,
        //                 customField2: [
        //                     "12th"
        //                 ]
        //             }
        //             break;
        //         case '10th': {
        //             this.customFieldValues = {
        //                 customField1: customField2For10thand12th,
        //                 customField2: [
        //                     "10th"
        //                 ]
        //             }
        //             break;
        //         }
        //         default:
        //             const query = this.makeQueryParams(true);
        //             const res = await this.documentService.getCustomFieldValues(query);
        //             this.customFieldValues = res;
        //             break;
        //     }
        //     this.filteredCustomFieldValues = this.customFieldValues;
        // } else {
        //     const query = this.makeQueryParams(true);
        //     const res = await this.documentService.getCustomFieldValues(query);
        //     this.customFieldValues = res;
        //     this.filteredCustomFieldValues = this.customFieldValues;
        // }

        // TO FIX
        // const query = this.makeQueryParams(true);
        // const res = await this.documentService.getCustomFieldValues(query);
        // this.customFieldValues = res;
        // }

        // Select default option if number of options is not more than one
        if (this.customFields) {
            this.customFields?.forEach(f => {
                if (this.customFieldValues[f.name]?.length === 1) {
                    this.verifiableStudentForm.get(f.name)
                        .setValue(this.customFieldValues[f.name][0])
                }
            });
        }
    }


    async setCustomFieldsForMpBoard(orgId, documentCategory) {
        let customField1ForDlEd= [
            "FIRST/SEPTEMBER-2018",
            "SECOND/MARCH-2019",
            "FIRST/SEPTEMBER-2019",
            "SECOND/MARCH-2020",
            "FIRST/SEPTEMBER-2020",
            "SECOND/MARCH-2021",
            "FIRST/SEPTEMBER-2021",
            "SECOND/MARCH-2022",
            "FIRST/SEPTEMBER-2022",
            "SECOND/MARCH-2023",
            "FIRST/SEPTEMBER-2023",
            "SECOND/MARCH-2024"
        ];
        let customField2For10thand12th = [
            "Main",
            "Supplementary"
        ];

        console.log("___HELLO___", orgId)

        if (orgId === "64f4e3fb54817103f4f29589" 
            || orgId === "62b9ce9721ec852188cece0e" 
            || orgId === null
            /* MP board org ids for QA and Prod */
            ) {
            switch (documentCategory) {
                case 'D.El.Ed1':
                    this.customFieldValues = {
                        customField1: customField1ForDlEd,
                        customField2: [
                            "D.El.Ed 1st year"
                        ]
                    }
                    break;
                case 'D.El.Ed2':
                    this.customFieldValues = {
                        customField1: customField1ForDlEd,
                        customField2: [
                            "D.El.Ed 2nd year"
                        ]
                    }
                    break;
                case '12th':
                    this.customFieldValues = {
                        customField1: customField2For10thand12th,
                        customField2: [
                            "12th"
                        ]
                    }
                    break;
                case '10th': {
                    this.customFieldValues = {
                        customField1: customField2For10thand12th,
                        customField2: [
                            "10th"
                        ]
                    }
                    break;
                }
                default:
                    const query = this.makeQueryParams(true);
                    const res = await this.documentService.getCustomFieldValues(query);
                    this.customFieldValues = res;
                    break;
            }
            this.filteredCustomFieldValues = this.customFieldValues;
        } else {
            const query = this.makeQueryParams(true);
            const res = await this.documentService.getCustomFieldValues(query);
            this.customFieldValues = res;
            this.filteredCustomFieldValues = this.customFieldValues;
        }
    }
    getCustomFields(documentCategory){
        const index = this.supportedDocumentCategories.findIndex( x => x.name === documentCategory);
        const customFields = this.supportedDocumentCategories[index].customFields?.filter( x => !x.isDisable);
        return customFields;
    }
   

    ngOnDestroy() {
        
    }

    onResetTimePeriod() {
        this.verifiableStudentForm.patchValue(
            {
                documentCategory: '',
            }
        )
       
    }

    async previewDocument(uniqueId) {
        this.loading=true;
        this.enableDownloadButton = true;
        this.displayPdfPreview = true;
        const fileBlob = await this.documentService.downloadDocument(uniqueId);
        this.previewFilePath = window.URL.createObjectURL(fileBlob);
        this.loading = false
    }

    parseFieldValues(fieldValue: string): string[] {
        return _.split(fieldValue, ',').map(_.trim);
    }

    async getDocByCategory(){
        const query = this.makeQueryParams(false);

        this.loading = true;
        this.documentDto = null;
        try {
            const res = await this.documentService.getDocByCategory(query);
            this.documentDto = res;
        } catch (e) {
            this.notificationService.errorToastNotification(e?.error?.message);
        }
        finally {
            this.loading = false
        }

    }

    makeQueryParams(isAutoCompleteProcessing: boolean){
        const value = this.verifiableStudentForm.getRawValue();
        const queryParam: DocOwnerDocumentQueryParam = {}
        if(!isAutoCompleteProcessing){
            queryParam['organizationId'] =  this.userData.accountId ? this.userData.accountId : '',
            queryParam['rollNo'] = value.rollNo ? value.rollNo : '' ,
            queryParam['academicYear'] =  value.academicYear ? value.academicYear : '',
            queryParam['documentCategory'] = value.documentCategory ? value.documentCategory : ''  
        }else{
            queryParam['organizationId'] =  this.userData.accountId ? this.userData.accountId : '',
            queryParam['documentCategory'] = value.documentCategory ? value.documentCategory : ''
        }
        
        this.customFields.forEach(f => {
            queryParam[f.name] = value[f.name] || '';
        });

        return queryParam;
    }

    async downloadDocument() {
        if(!(_.isEmpty(this.documentDto))){
            const fileBlob = await this.documentService.downloadDocument(this.documentDto.uniqueId);
            const urlParts = this.documentDto.docPath.split('/');
            const fileName = urlParts.length === 1 ? urlParts[0] : urlParts[urlParts.length - 1];
            this.sharedService.downloadFileByBlob(fileBlob, fileName)
        }
    }

    async printDocument() {
        if(!(_.isEmpty(this.documentDto))){
            const fileBlob = await this.documentService.downloadDocument(this.documentDto.uniqueId);
            const urlParts = this.documentDto.docPath.split('/');
            const fileName = urlParts.length === 1 ? urlParts[0] : urlParts[urlParts.length - 1];
            const fl = URL.createObjectURL(fileBlob);
            window.open(fl).print();
        }
    }

    getCustomValuesOption(customFieldName){
       // return _.isEmpty(this.customFieldValues) ? [] : this.customFieldValues[customFieldName];
       return _.isEmpty(this.filteredCustomFieldValues) ? [] : this.filteredCustomFieldValues[customFieldName];
    }
}
