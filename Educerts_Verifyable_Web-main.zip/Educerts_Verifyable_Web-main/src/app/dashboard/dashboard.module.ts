import { NgModule } from '@angular/core';
import { CoreModule } from 'app/core/core.module';
import { PipeModule } from 'app/pipe/pipe.module';
import { SharedModule } from 'app/shared/shared.module';
import { DashboardComponent } from './dashboard/dashboard.component';

@NgModule({
    declarations: [DashboardComponent],
    imports: [
        CoreModule,
        PipeModule,
        SharedModule
    ],
    providers: [],
})
export class DashboardModule { }
