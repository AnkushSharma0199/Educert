import { AppType, DocActivityStatusEnum, DocFlowUserStatusEnum, FieldTypeEnum, ReportFormatType, StatusEnum, UserRole } from './app.enum';

export class SignInResponse {
    firstName: string;
    lastName: string;
    email: string;
    accessToken: string;
    firstPasswordChanges: boolean;
    role: UserRole;
    dateOfBirth: Date;
    mobile: string;
    aadhaarNumber: string;
    isAuthenticated: boolean;
    passwordSecurityCode: string;
}

export class SignUpResponse {
    name: string;
    email: string;
    firstPasswordChanges: boolean;
    role: UserRole;
}

export class SignUpRequest {
    firstName: string;
    lastName: string;
    email: string;
    password: string;
}

export class Profile {
    firstName: string;
    lastName: string;
    email: string;
    role?: string;
    dateOfBirth: Date;
    mobile: string;
    aadhaarNumber: string;
}

export class PasswordResetResponse {
    name: string;
    email: string;
    token: string;
    firstPasswordChanges: boolean;
    role: UserRole;
}

export class ResetPasswordRequest {
    password: string;
    email: string;
    confirmPassword: string;
    emailSecurityCode: string;
}

export class EmailVerificationParams {
    email: string;
    emailSecurityCode: string;
    userId?: string;
}

export class UserData {
    id?: string;
    accountId?: string;
    firstName?: string;
    middleName?: string;
    lastName?: string;
    email?: string;
    accessToken?: string;
    firstPasswordChanges?: boolean;
    role?: UserRole;
    dateOfBirth?: Date;
    mobile?: string;
    designation?: string;
    employeeID?: string;
    aadhaarNumber?: string;
    isAuthenticated?: boolean;
    status?: StatusEnum;
    account?: AccountData;
    state?: State;
    stateId?: string;
    isEmailVerified?: boolean;
    additionalEmails?: AdditionalEmailData[];

    // client side property
    fullName?: string;
}

export interface UserDocData {
    docTypeId: string;
    isEdit?: boolean;
    statusValidation?: string[];
    userRowsErrors?: boolean;
    docFlowReset?: boolean;
    userHeirarichyValidation?: string[];
    data: {
        level?: number;
        role?: string;
        user?: string;
        status?: DocFlowUserStatusEnum;
        rowHeader?: boolean;
        selectableRole?: boolean;
    }[];
}

export class AdditionalEmailData {
    email?: string;
    isVerified?: boolean;
    emailSecurityCode?: string;
    emailTimestamp?: Date;

    // client side properties
    isAddedInDB?: boolean; // we use this in API, to find out the already addedEmails in DB, and then check, if their is any new duplicate email
    isSendVerificationMail?: boolean; // to identify emails(new email or updated email) to which we have to send emails after updating profile
}
export class SignInRequest {
    email?: string;
    password?: string;
    appType?: AppType;
}

export class AccountData {
    id?: string;
    organizationName?: string;
    logo?: string;
    salesPartnerUserId?: string;
    salesPartner?: UserData;
    address?: Address;
    status?: StatusEnum;
    isVisible?: boolean;
    type?: any;
    settings?: AccountSettingResponseDto;
    allowedEmailDomains?: string;
    allowedIPRange?: string;
}

export class AccountSettingRequestDto {
    accountId?: string;
    supportedFields?: FieldTypeDto[];
    supportedDocumentTypes?: DocumentTypeDto[];
    supportedDocumentCategories?: DocumentCategoriesDto[];
    rejectionReasons?: string[];
}
export class DocumentFlowRequestDto {
    accountId?: string;
    userDocData?: UserDocData;
}
export class AccountSettingResponseDto {
    accountId?: string;
    enableDocOwnerInvite?: boolean;
    supportedFields?: FieldTypeDto[];
    supportedDocumentTypes?: DocumentTypeDto[];
    supportedDocumentCategories?: DocumentCategoriesDto[];
    rejectionReasons?: string[];
}

export class DocumentCategoriesDto {
    name?: string;
    description?: string;
    customFields?: CustomFields[];
}

export class DocumentResponseDto {
    public Id: string;
    public uniqueId: string;
    public storageLocation?: number;
    public docTypeCode?: string;
    public docPath: string;
    public fields: string;
    public datePublished?: Date;
    public dateDrafted: Date;
    public lastDocActivity?: LastDocActivityUserDto;
    public docActivity?: DocActivityDto;
    public activityDate?: Date;
}

export class LastDocActivityUserDto {
    level?: number;
    roleId?: number;
    userId?: string;
    user?: UserInfoDto;
    date?: Date;
    comment?: string;
    reason?: string;
    docVersionId?: string;
    status?: DocActivityStatusEnum;
}

export class UserInfoDto {
    id: string;
    email: string;
    fullName: string;
}

export class DocActivityDto {
    id?: string;
    docId?: string;
    level?: number;
    date?: Date;
    docVersionId?: string;
    user?: UserInfoDto;
    roleId?: number;
    status?: number;
    userId?: string;
    comment?: string;
    reason?: string;
}




export class CustomFields{
    name?: string;
    displayName?: string;
    fieldValue?: string;
    type?: string;
    isDisable?: boolean;
}

export class DocumentFlowResponseDto {
    accountId?: string;
    documentFlow?: ResponseDocFlowType[];
}

export class ResponseDocFlowType {
    public docTypeId?: string;
    public level?: number;
    public userId?: string;
    public roleId?: number;
    public status?: boolean;
}

export class FieldTypeDto {
    name: string;
    displayName: string;
    type: FieldTypeEnum;
    fieldValue?: string;
    isReadonly: boolean;
    isVisible: boolean;
    isRequired: boolean;
    isVisiblePublic: boolean;
}

export class DocumentTypeDto {
    code: string;
    name: string;
    docSubTypes?: DocumentSubTypeDto[];
}

export class DocumentSubTypeDto {
    code: string;
    name: string;
}

export class DashboardCounterData {
    makerCounter?: number;
    checkerCounter?: number;
    documentCounter?: number;
    docOwnerCounter?: number;
    regulatorCounter?: number;
    organizationCounter?: number;
    uploadCounter?: number;
    approverCounter?: number;
}

export class DashboardGraphData {
    appLogins?: any;
    signedDocuments?: any;
    portalLogins?: any;
    organizationsByMonth?: any;
    makersByMonth?: any;
    checkersByMonth?: any;
    documentsByOrganization?: DocumentGroupByOrganizationDto[];
}

export class DashboardTableData {
    recentLogins?: any;
    recentActivity?: RecentActivityData[];
    recentOrganizations?: RecentOrganizationData[];
    recentDocuments?: DocOwnerDocumentData[];
}

export class RecentActivityData {
    uniqueId: string;
    email: string;
    name: string;
    dateUploaded: Date;
}

export class RecentOrganizationData {
    createdDate: Date;
    organizationName: string;
}

export class Address {
    public address1?: string;
    public address2?: string;
    public address3?: string;
    public stateId?: string;
    public state?: State;
    public city?: string;
    public country?: string;
    public postalCode?: string;
}

export class State {
    code?: string;
    name?: string;
    id?: string;
    welcomeImage?: string;
    logo?: string;
}

export interface ListResult<T> {
    records: T;
    totalRecords: number;
}

export interface GetQueryParam {
    size?: number;
    page?: number;
    sortBy?: string;
    sortingOrder?: string;
}

export interface OrganizationQueryParam extends GetQueryParam {
    organizationName?: string;
    stateId?: string;
    salesPartnerUserId?: string;
    status?: StatusEnum
}

export interface UserQueryParam extends GetQueryParam {
    name?: string;
    email?: string;
    organizationId?: string;
    role?: UserRole;
    status?: StatusEnum;
}

export interface DocOwnerDocumentQueryParam extends GetQueryParam {
    organizationId?: string;
    rollNo?: string;
    academicYear?: string;
    email?: string;
    name?: string;
    documentCategory?: string;
}

export class DocOwnerDocumentData {
    id: string;
    dateSigned: Date;
    date: Date;
    uniqueId: String
    email: string
    docPath: string
    organizationName: string;
    rollNo: string;
    academicYear: string;
    customField1: string;
    customField2: string;
    customField3: string;
    customField4: string;
    customField5: string;
    accountId: string;
}

export class DocumentGroupByOrganizationDto {
    organizationName?: string;
    logo?: string;
    count?: number;
}

export interface ReportFilter extends GetQueryParam {
    organizationId?: string;
    docOwnerEmail?: string;
    stateOrNationalRegulatorId?: string;
    stateId?: string;
    dateFrom?: Date;
    dateTo?: Date;
    type?: ReportFormatType;

    docTypeCode?: string;
    docSubTypeCode?: string;
    academicYear?: string;
    programmeName?: string;
    salesPartnerUserId?: string;
    makerId?: string

}

export class DocumentDto {}

export class filterFormRole {
    name: string;
    value: number;
}

export class UserFilterForm {
    name: string;
    email: string;
    organization: string;
    role: filterFormRole;
}

export class OrganizationFilterForm {
    organizationName: string;
    state: string;
    salesPartner: string;
}

export class DocumentFilterForm {
    organization: string;
    rollNumber: string;
    academicYear: string;
    email: string;
    name: string;
    timePeriodInMonths: string;
    dateFrom: string;
    dateTo: string;
}

export class StateSummaryReportFilterForm {
    organization: string;
    maker: string;
    docTypeCode: string;
    timePeriodInMonths: string;
    dateFrom: string;
    dateTo: string;
    programmeName: string;
}

export class UploadsByOrgProgramReportFilterForm {
    timePeriodInMonths: string;
    dateFrom: string;
    dateTo: string;
    docTypeCode: string;
    docSubTypeCode: string;
    organization: string;
    academicYear: string;
    programmeName: string;
    salesPartner: string;
    state: string;
}

export class UploadsByOryMakerReportFilterForm {
    timePeriodInMonths: string;
    dateFrom: string;
    dateTo: string;
    docTypeCode: string;
    docSubTypeCode: string;
    organization: string;
    academicYear: string;
    programmeName: string;
    salesPartner: string;
    state: string;
}

export class MakerActivityByDateReportFilterForm {
    timePeriodInMonths: string;
    dateFrom: string;
    dateTo: string;
    maker: string;
    docTypeCode: string;
    docSubTypeCode: string;
    programmeName: string;
    salesPartner: string;
}

export class SummaryByStateReportData {
    state: string;
    makersCount: number;
    organizationsCount: number;
    docOwnersCount: number;
    docUploadsCount: number;
}

export class DocTypeUploadsByOrgAndProgramData {
    organizationName?: string;
    programmeName?: string;
}

export class DocTypeUploadsByOrgAndMakerData {
    organizationName?: string;
    makerName?: string;
}

export class MakerActivityByDateReportData {
    day: string;
    documentsCount: number;
    docOwnersCount: number;
}

export class DocTypeData {
    code?: string;
    name?: string;
    docSubTypes?: DocSubTypeData[];
}

export class DocSubTypeData {
    code?: string;
    name?: string;
}

export class RecentLoginData {
    lastLogin: Date;
    firstName: string;
    middleName: string;
    lastName: string;
}

export class RoleDto {
    code?: string;
    role?: string;
    description?: string;
}

export class InitConfigurationData {
    email: string;
    phone: string;
    copyrightMsg: string;
    helpUrl: string;
    dockerExePath: string;
}

export interface CheckInProgressDocsRequest {
    accountId: string;
    userIds?: string[];
    documentCode: string;
}

export interface CheckInProgressDocsResponse {
    isInProgressDocs: Boolean
}
