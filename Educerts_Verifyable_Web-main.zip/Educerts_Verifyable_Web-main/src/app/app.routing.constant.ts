const routingConstants = {
    home: '/home',
    profile: '/profile',
    organization: '/organization', // Organinzation route for maker, and Organizations for others
    organizations: '/organizations',
    issuingOrganizations: '/issuing-organizations',
    users: '/users',
    changePassword: '/change-password',
    documents: '/documents',
    report: '/report',
    summaryByState: '/report/summary-by-state',
    docTypeUploadsByOrgProgram: '/report/doc-type-uploads-by-org-program',
    docTypeUploadsByOrgPublisher: '/report/doc-type-uploads-by-org-publisher',
    makerActivityByDate: '/report/maker-activity-by-date',
    appDownload: '/app-download',
};

export const RoutingConstant = Object.freeze(routingConstants);
