import { Component, HostListener, NgZone, OnDestroy, OnInit } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { Idle, DEFAULT_INTERRUPTSOURCES } from '@ng-idle/core';
import { Subscription } from 'rxjs';
import { IdleTimeoutDialogComponent } from './core/idle-timeout-dialog/idle-timeout-dialog.component';
import { UserData } from './app.interface';
import { environment } from '../environments/environment';
import { UserService } from './service/user.service';
import { SharedService } from './service/shared.service';
import { InitService } from './service/config.service';
import { SessionStoreService } from './service/session-store.service';
const SmallScreenBreakpoint = 991;

@Component({
    selector: 'app-root',
    templateUrl: './app.component.html',
    styleUrls: [],
})
export class AppComponent implements OnInit, OnDestroy {
    public isSmScreen = false;
    public isAuthorized = this.userService.IsAuthorized;
    public sidebarOpened = false;
    public sidebarBackdrop = false;
    public appVersion = environment.appVersion;
    public sidebarToggleSubscription: Subscription;
    public authSubscription: Subscription;
    public routeChangeSubscription: Subscription
    public isExternalComponent = false;
    dialogRef: MatDialogRef<IdleTimeoutDialogComponent, boolean>

    constructor(
        private userService: UserService,
        private translateService: TranslateService,
        private sharedService: SharedService,
        private router: Router,
        private idle: Idle,
        private dialog: MatDialog,
        private zone: NgZone,
        private initService: InitService,
        private sessionStoreService: SessionStoreService
    ) {
        this.sideBarOnWidthChange()
        this.configureLanguage();

        // sets an idle timeout of 5 seconds, for testing purposes.
        idle.setIdle(environment.idleTimeout.timerWillStartInSec);
        // sets a timeout period of 5 seconds. after 10 seconds of inactivity, the user will be considered timed out.
        idle.setTimeout(environment.idleTimeout.timerWillWaitInSec);
        // sets the default interrupts, in this case, things like clicks, scrolls, touches to the document
        idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);

        idle.onIdleStart.subscribe(() => {
            this.openDialog()
        });

        idle.onTimeout.subscribe(() => {
            this.dialogRef.close(false);
        });

        idle.onTimeoutWarning.subscribe((countdown) => {
            this.sharedService.counterIdleTimeout.emit(countdown)
        });

        idle.onIdleEnd.subscribe(() => {
            this.dialogRef.close(true);
        });

        this.authSubscription = this.userService.authUpdated?.subscribe(
            (data: UserData) => {
                if (data) {
                    this.isAuthorized = data.isAuthenticated;
                } else {
                    this.isAuthorized = false;
                    idle.stop();
                }
            }
        );

        this.routeChangeSubscription = this.router.events.subscribe(async (x) => {
            if (x instanceof NavigationEnd) {
                const userId = this.sessionStoreService.getUserData()?.id
                if (userId) {
                    const userData = await this.userService.getUserById(userId)
                    const updatedAuthData = {
                        ...this.sessionStoreService.getUserData(),
                        ...userData
                    }
                    this.sessionStoreService.setUserData(updatedAuthData);
                    this.userService.AuthData = updatedAuthData
                }
                this.isExternalComponent = false;
                const currentParentRoute = x.url;
                if (currentParentRoute.includes('email-verification') || currentParentRoute.includes('reset-password')) {
                    this.isExternalComponent = true;
                }

                if (currentParentRoute !== '/' && currentParentRoute.indexOf('signIn') === -1
                    && currentParentRoute.indexOf('signUp') === -1 && currentParentRoute.indexOf('/reset-password') === -1
                    && currentParentRoute.indexOf('email-verification') === -1) {
                    // idle.watch();
                } else {
                    idle.stop();
                    this.dialogRef?.close(true);
                }
            }
        });
    }

    async ngOnInit() {
        const userData = this.userService.getUserData();
        this.isAuthorized = userData?.isAuthenticated;

        this.sidebarToggleSubscription = this.sharedService.onSidebarToggle.subscribe(
            (x: boolean) => {
                this.sidebarOpened = x;
            }
        );

        await this.setInitConfig();
    }

    async setInitConfig(): Promise<void> {
        await this.initService.getInitConfig().then((appConfig) => {
            this.sessionStoreService.setInitConfig(appConfig);
        })
    }

    logout() {
        this.userService.logOut();
        // to resolve navigation-triggered-outside-angular-zone warning, using ngZone
        this.zone.run(() => {
            this.router.navigate(['signIn']);
        })
    }

    openDialog() {
        this.dialogRef = this.dialog.open(IdleTimeoutDialogComponent);
        this.dialogRef.afterClosed().subscribe((stay: boolean) => {
            // TODO: handle undefined case. It should be either true or false
            if (stay || stay === undefined) {
                // this.idle.watch();
            } else {
                this.logout()
            }
        });
    }

    /**
    * Configure app language on startup
    * @param language Language from config
    */
    private configureLanguage() {
        // Get browser default language
        const lang = this.translateService.getBrowserLang();
        this.translateService.setDefaultLang(lang);
        this.translateService.use(lang);
    }

    toggleSidebar() {
        this.isSmScreen = window.innerWidth < SmallScreenBreakpoint;
        if (this.isSmScreen) {
            this.sharedService.onSidebarToggle.emit(!this.sidebarOpened);
        }
    }

    @HostListener('window:resize')
    public onWindowResize() {
        this.sideBarOnWidthChange()
    }

    sideBarOnWidthChange() {
        this.isSmScreen = window.innerWidth < SmallScreenBreakpoint;
        this.sidebarOpened = !this.isSmScreen;
        this.sidebarBackdrop = this.isSmScreen;
        if (this.isAuthorized && !this.isSmScreen) {
            this.sidebarOpened = true;
        }
    }

    ngOnDestroy() {
        if (this.authSubscription) {
            this.authSubscription.unsubscribe()
        }
        if (this.sidebarToggleSubscription) {
            this.sidebarToggleSubscription.unsubscribe()
        }
        if (this.routeChangeSubscription) {
            this.routeChangeSubscription.unsubscribe();
        }
    }
}
