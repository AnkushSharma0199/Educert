import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'environments/environment';
import { AccountData, AccountSettingRequestDto, AccountSettingResponseDto, DocumentFlowRequestDto, DocumentFlowResponseDto, ListResult, OrganizationQueryParam, State } from '../app.interface';

@Injectable({
    providedIn: 'root'
})
export class AccountService {

    baseUrl = environment.baseUrl + 'account/';
    constructor(private httpClient: HttpClient) { }

    async getAccountById(accountId: string): Promise<AccountData> {
        const accountUrl = this.baseUrl + accountId + '/withsettings';
        return this.httpClient.get<AccountData>(accountUrl).toPromise();
    }

    async updateAccount(id: string, formData: FormData): Promise<AccountData> {
        const accountUrl = this.baseUrl + id;
        return this.httpClient.patch<AccountData>(accountUrl, formData).toPromise();
    }

    async createAccount(formData: FormData): Promise<AccountData> {
        const accountUrl = this.baseUrl;
        return this.httpClient.post<AccountData>(accountUrl, formData).toPromise();
    }

    async deleteOrganization(id: string): Promise<AccountData> {
        const accountUrl = this.baseUrl + id;
        return this.httpClient.delete<AccountData>(accountUrl, {}).toPromise();
    }

    async getOrganizationList(queryParam: OrganizationQueryParam): Promise<ListResult<AccountData[]>> {
        const accountUrl = this.baseUrl;
        return this.httpClient.get<ListResult<AccountData[]>>(accountUrl, {
            params: queryParam as any
        }).toPromise();
    }

    async getOrganizationDropdownList(): Promise<AccountData[]> {
        const accountUrl = this.baseUrl + 'ddl';
        return this.httpClient.get<AccountData[]>(accountUrl).toPromise();
    }

    async changeStatus(bodyData): Promise<AccountData> {
        const accountUrl = this.baseUrl + 'changeStatus';
        return this.httpClient.patch<AccountData>(accountUrl, bodyData).toPromise();
    }

    async getStateListOfOrganization(countryCode: string): Promise<State[]> {
        const accountUrl = this.baseUrl + 'stateListOfOrganization/' + countryCode;
        return this.httpClient.get<State[]>(accountUrl).toPromise();
    }

    async getAccountSettingsByAccountId(accountId: string): Promise<AccountSettingResponseDto> {
        const accountUrl = this.baseUrl + 'settings/' + accountId;
        return this.httpClient.get<AccountSettingResponseDto>(accountUrl).toPromise();
    }

    async saveAccountSettings(accountSetings: AccountSettingRequestDto): Promise<AccountSettingResponseDto> {
        const accountUrl = this.baseUrl + 'settings/';
        return this.httpClient.post<AccountSettingResponseDto>(accountUrl, accountSetings).toPromise();
    }
    async saveDocumentFlow(documentFlowData: DocumentFlowRequestDto): Promise<DocumentFlowResponseDto> {
        const accountUrl = this.baseUrl + 'documentFlow/';
        return this.httpClient.post<DocumentFlowResponseDto>(accountUrl, documentFlowData).toPromise();
    }
    async getDocumentFlowByAccountId(accountId: string): Promise<DocumentFlowResponseDto> {
        const accountUrl = this.baseUrl + 'documentFlow/' + accountId;
        return this.httpClient.get<DocumentFlowResponseDto>(accountUrl).toPromise();
    }
}
