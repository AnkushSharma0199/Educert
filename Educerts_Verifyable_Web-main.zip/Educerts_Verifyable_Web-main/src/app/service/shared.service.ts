import { trigger, state, style, transition, animate, } from '@angular/animations';
import { EventEmitter, Inject, Injectable, LOCALE_ID } from '@angular/core';
import { formatDate } from '@angular/common';
import { EventManager } from '@angular/platform-browser';
import { Observable, Subject } from 'rxjs';
import * as moment from 'moment';
import * as _ from 'lodash'
import { UserRole } from 'app/app.enum';
import { Global } from 'app/app.global';
import { SessionStoreService } from './session-store.service';

@Injectable({
    providedIn: 'root',
})
export class SharedService {
    private resizeSubject: Subject<Window>;
    public onSidebarToggle = new EventEmitter<boolean>();

    public counterIdleTimeout = new EventEmitter<number>();

    /**
     * Animations used in table row detail
     */
    public static getAnimationForTableDetail() {
        return [
            trigger('detailExpand', [
                state('collapsed', style({ height: '0px', minHeight: '0' })),
                state('expanded', style({ height: '*' })),
                transition(
                    'expanded <=> collapsed',
                    animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')
                ),
            ]),
        ];
    }

    public static allowOnlyPositiveNumbers(event) {
        return event.charCode === 8 || event.charCode === 0 ? null : event.charCode >= 48 && event.charCode <= 57;
    }

    constructor(
        @Inject(LOCALE_ID) private locale: string,
        private eventManager: EventManager,
        private sessionStoreService: SessionStoreService,
    ) {
        this.resizeSubject = new Subject();
        this.eventManager.addGlobalEventListener(
            'window',
            'resize',
            this.onResize.bind(this)
        );
    }

    get onResize$(): Observable<Window> {
        return this.resizeSubject.asObservable();
    }

    private onResize(event: UIEvent) {
        this.resizeSubject.next(<Window>event.target);
    }

    public isExpansionIndicator(target: HTMLElement): boolean {
        const expansionIndicatorClass = 'mat-expansion-indicator';
        return (target.classList && target.classList.contains(expansionIndicatorClass));
    }

    /**
     * Parse the provided string return Integer
     * @param: id String to Parse
     */
    public parseInt(id: any) {
        const res = id ? parseInt(id.toString(), 10) : null;
        return res;
    }

    /**
     * Convert enum to object of type { name: string; value: string }[]
     * @param enumVar Enum
     */
    public enumToObjectArray(enumVar: any): { name: string; value: string }[] {
        const objectArray: { name: string; value: string }[] = [];

        for (const n in enumVar) {
            if (enumVar.hasOwnProperty(n) && isNaN(this.parseInt(n))) {
                objectArray.push({
                    name: n,
                    value: <any>enumVar[n],
                });
            }
        }
        return objectArray;
    }

    getEnumValueByKey(enumObj, name) {
        const enumArray = this.enumToObjectArray(enumObj);
        const selectedEnum = enumArray.find((item) => JSON.stringify(item.name) === JSON.stringify(name));
        return selectedEnum ? selectedEnum.value : ''
    }

    getEnumKeyByValue(enumObj, value) {
        const enumArray = this.enumToObjectArray(enumObj);
        const selectedEnum = enumArray.find((item) => JSON.stringify(item.value) === JSON.stringify(value));
        return selectedEnum ? selectedEnum.name : ''
    }

    getUserRoleName(enumId: Number) {
        const userRole = this.enumToObjectArray(UserRole).find((x) => this.parseInt(x.value) === enumId);
        return userRole ? userRole.name : '';
    }

    isMakerOrChecker(): boolean {
        const userData = this.sessionStoreService.getUserData();
        return (userData?.role === UserRole.Maker || userData?.role === UserRole.Checker);
    }

    isMakerCheckerOrApprover(): boolean {
        const userData = this.sessionStoreService.getUserData();
        return (userData?.role === UserRole.Maker || userData?.role === UserRole.Checker || userData?.role === UserRole.Approver);
    }

    isMakerCheckerApproverPublisherOrUploader(): boolean {
        const userData = this.sessionStoreService.getUserData();
        return (userData?.role === UserRole.Maker || userData?.role === UserRole.Checker || userData?.role === UserRole.Approver || userData?.role === UserRole.Publisher || userData?.role === UserRole.Uploader);
    }

    isUserDocOwner(): boolean {
        return (this.sessionStoreService.getUserData()?.role === UserRole.DocOwner);
    }

    isMaker(): boolean {
        const userData = this.sessionStoreService.getUserData();
        return userData?.role === UserRole.Maker;
    }

    isChecker(): boolean {
        const userData = this.sessionStoreService.getUserData();
        return userData?.role === UserRole.Checker;
    }

    isApprover(): boolean {
        const userData = this.sessionStoreService.getUserData();
        return userData?.role === UserRole.Approver;
    }

    isPublisher(): boolean {
        const userData = this.sessionStoreService.getUserData();
        return userData?.role === UserRole.Publisher;
    }

    isOrgAdmin(): boolean {
        const userData = this.sessionStoreService.getUserData();
        return userData?.role === UserRole.OrgAdmin;
    }

    isUploader(): boolean {
        const userData = this.sessionStoreService.getUserData();
        return userData?.role === UserRole.Uploader;
    }

    isAdmin(): boolean {
        const userData = this.sessionStoreService.getUserData();
        return userData?.role === UserRole.Admin;
    }

    isStateOrNationalRegulator(): boolean {
        const userData = this.sessionStoreService.getUserData();
        return (userData?.role === UserRole.StateRegulator || userData?.role === UserRole.NationalRegulator);
    }

    isNationalRegulator(): boolean {
        const userData = this.sessionStoreService.getUserData();
        return (userData?.role === UserRole.NationalRegulator);
    }

    isStateRegulator(): boolean {
        const userData = this.sessionStoreService.getUserData();
        return (userData?.role === UserRole.StateRegulator);
    }

    isSalesPartner(): boolean {
        const userData = this.sessionStoreService.getUserData();
        return userData?.role === UserRole.SalesPartner;
    }

    isRegUser(): boolean {
        const userData = this.sessionStoreService.getUserData();
        return userData?.role === UserRole.RegUser
    }

    isApprUser(): boolean {
        const userData = this.sessionStoreService.getUserData();
        return userData?.role === UserRole.ApprUser
    }

    formatDateInDayMonth(date: Date = new Date()) {
        return moment(date).format('DD-MMM')
    }

    getShortMonthName(monthNumber) {
        const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        return months[monthNumber - 1];
    }

    /**
     * Downloads a file using Blob
     */
    public downloadFileByBlob(blob: Blob|MediaSource, name?: string) {
        const a = document.createElement('a');
        a.style.display = 'none';
        const url = window.URL.createObjectURL(blob);
        a.href = url;
        a.download = name;
        a.click();
        window.URL.revokeObjectURL(url);
    }

    /**
     * Downloads a file using URL
     */
    downloadFileByUrl(fileURL, name = 'sd') {
        const link = document.createElement('a');
        link.href = fileURL;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }

    /**
     * Get Formatted Date Time
     */
    public formatDateTime(
        date: Date = new Date(),
        format: string = 'yyyyMMdd_HHmmss',
        locale: string = this.locale,
    ): any {
        return formatDate(date, format, locale);
    }

    /**
     * Build file name using info
     */
    public buildFileName(
        data: {
            Name?: string,
            TimeStamp: number,
            Extension: string,
        },
    ): string {
        return this.compileTemplate(Global.entity.fileName, data);
    }

    /**
     * Compile template
     */
    public compileTemplate(
        template: string,
        data: any,
        replace: {
            replace: string;
            with: string;
            notFoundUse?: string;
        }[] = [],
    ): string {
        const compiled = _.template(template);
        let str = compiled(data);
        replace.forEach(x => {
            if (!x.notFoundUse) {
                x.notFoundUse = '0';
            }
            let code = x.with;
            const replaceLength = x.replace.length;
            const codeLength = code.length;

            if (codeLength < replaceLength) {
                const loop = replaceLength - codeLength;
                for (let i = 0; i < loop; i++) {
                    code = x.notFoundUse + code;
                }
            }

            str = str.replace(x.replace, code);
        });
        return str;
    }

    public filterDropdownForFullName(searchArray, value) {
        const filterValue = value.toLowerCase();
        return searchArray.filter(option =>
            option.fullName.toLowerCase().includes(filterValue),
        );
    }

    public filterDropdownForEmail(searchArray, value) {
        const filterValue = value.toLowerCase();
        return searchArray.filter(option =>
            option.email.toLowerCase().includes(filterValue),
        );
    }

    public filterDropdownForName(searchArray, value) {
        if (value) {
            const filterValue = value.toLowerCase();
            return searchArray.filter(option =>
                option.name.toLowerCase().includes(filterValue),
            );
        }
    }

    /**
     * Get Formatted Date
     */
    public formatDate(
        date: Date = new Date(),
        format: string = 'dd/MM/yyyy',
        locale: string = this.locale,
    ): string {
        return formatDate(date, format, locale);
    }

    public getFullName(firstName, middleName, lastName): string {
        let fullName = firstName;
        if (middleName) {
            fullName = fullName + ' ' + middleName;
        }
        if (lastName) {
            fullName = fullName + ' ' + lastName;
        }
        return fullName;
    }

    public getChildTableMargin(tableRef, columnWidthClass) {
        let marginLeft = Global.values.childTableLeftMargin
        if (tableRef && columnWidthClass) {
            const tableWidth = tableRef._elementRef.nativeElement.clientWidth
            const innerWidth = tableWidth ? tableWidth - 8 : 0;
            const splittedArray = columnWidthClass.split('-')
            const percentage = splittedArray[1];
            marginLeft = (percentage * innerWidth / 200) + 'px';
        }
        return marginLeft
    }

    // Method to get date with current time
    public getDateWithCurrentTime(date: Date): Date {
        const _ = moment();
        const dateWithTime = moment(date).add({hours: _.hour(), minutes:_.minute() , seconds:_.second()})
        const dateWithCurrentTime = dateWithTime.toDate();
        return dateWithCurrentTime
    }
}
