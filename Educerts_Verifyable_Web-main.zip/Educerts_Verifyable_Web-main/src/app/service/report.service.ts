import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { MakerActivityByDateReportData, ListResult, ReportFilter, DocTypeUploadsByOrgAndProgramData, SummaryByStateReportData } from '../app.interface';

@Injectable({
    providedIn: 'root'
})
export class ReportService {

    private baseUrl = '';
    constructor(private httpClient: HttpClient) {
        this.baseUrl = environment.baseUrl + 'report' + '/';
    }

    public async getSummaryByState(options: any): Promise<ListResult<SummaryByStateReportData[]>> {
        const apiUrl = this.baseUrl + 'summary-by-state';
        return this.httpClient.get<ListResult<SummaryByStateReportData[]>>(apiUrl, { params: options as any }).toPromise();
    }

    public async downloadSummaryByStateReport(options: ReportFilter): Promise<Blob> {
        const apiUrl = this.baseUrl + 'summary-by-state/download';
        return this.httpClient.post(apiUrl, options, { responseType: 'blob', }).toPromise();
    }

    public async getDocTypeUploadsByOrgAndProgramme(options: any): Promise<ListResult<DocTypeUploadsByOrgAndProgramData[]>> {
        const apiUrl = this.baseUrl + 'doc-type-uploads-by-Org-Programme';
        return this.httpClient.get<ListResult<DocTypeUploadsByOrgAndProgramData[]>>(apiUrl, { params: options as any }).toPromise();
    }

    public async downloadDocTypeUploadsByOrgAndProgrammeReport(options: ReportFilter): Promise<Blob> {
        const apiUrl = this.baseUrl + 'doc-type-uploads-by-Org-Programme/download';
        return this.httpClient.post(apiUrl, options, { responseType: 'blob', }).toPromise();
    }

    public async getDocTypeUploadsByOrgAndPublisher(options: any): Promise<ListResult<DocTypeUploadsByOrgAndProgramData[]>> {
        const apiUrl = this.baseUrl + 'doc-type-uploads-by-Org-Publisher';
        return this.httpClient.get<ListResult<DocTypeUploadsByOrgAndProgramData[]>>(apiUrl, { params: options as any }).toPromise();
    }

    public async downloadDocTypeUploadsByOrgAndPublisherReport(options: ReportFilter): Promise<Blob> {
        const apiUrl = this.baseUrl + 'doc-type-uploads-by-Org-Publisher/download';
        return this.httpClient.post(apiUrl, options, { responseType: 'blob', }).toPromise();
    }

    public async getMakerActivityByDate(options: any): Promise<ListResult<MakerActivityByDateReportData[]>> {
        const apiUrl = this.baseUrl + 'maker-activity-by-date';
        return this.httpClient.get<ListResult<MakerActivityByDateReportData[]>>(apiUrl, { params: options as any }).toPromise();
    }

    public async downloadMakerActivityByDateReport(options: ReportFilter): Promise<Blob> {
        const apiUrl = this.baseUrl + 'maker-activity-by-date/download';
        return this.httpClient.post(apiUrl, options, { responseType: 'blob', }).toPromise();
    }
}

