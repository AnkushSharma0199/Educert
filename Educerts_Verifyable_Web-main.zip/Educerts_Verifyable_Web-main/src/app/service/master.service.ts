import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'environments/environment';
import { DocTypeData, RoleDto, State } from '../app.interface';

@Injectable({
    providedIn: 'root'
})
export class MasterService {
    baseUrl = environment.baseUrl + 'master/';
    constructor(private httpClient: HttpClient) {
    }

    async getStateList(): Promise<State[]> {
        const masterUrl = this.baseUrl + 'state';
        return this.httpClient.get<State[]>(masterUrl).toPromise();
    }

    async getDocTypeDDL(): Promise<DocTypeData[]> {
        const masterUrl = this.baseUrl + 'docType/getList';
        return this.httpClient.get<DocTypeData[]>(masterUrl).toPromise();
    }

    async getStateById(id: string): Promise<any> {
        const masterUrl = this.baseUrl + 'state/' + id;
        return this.httpClient.get<any>(masterUrl).toPromise();
    }

    async getRoleByCode(code: string): Promise<RoleDto> {
        const masterUrl = this.baseUrl + 'role/' + code;
        return this.httpClient.get<any>(masterUrl).toPromise();
    }
}
