import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'environments/environment';
import { DocumentDto, DocOwnerDocumentData, DocOwnerDocumentQueryParam, DocumentGroupByOrganizationDto, ListResult, CheckInProgressDocsResponse, CheckInProgressDocsRequest, DocumentResponseDto } from '../app.interface';

@Injectable({
    providedIn: 'root'
})
export class DocService {
    documentUrl = environment.baseUrl + 'document/';
    docOwnerDocsUrl = this.documentUrl + 'docOwnerDocumentList';
    getDocByCategoryUrl = this.documentUrl + 'getDocByCategory';
    customFieldValues = this.documentUrl + 'getCustomFieldValues';

    downloadUrl = this.documentUrl + 'download/';

    constructor(private httpClient: HttpClient) { }

    async getProgrammeNameDDL(): Promise<DocumentDto[]> {
        const accountUrl = this.documentUrl + 'programmeNameDDL';
        return this.httpClient.get<DocumentDto[]>(accountUrl, {}).toPromise();
    }

    async getIssuingOrganization(): Promise<DocumentGroupByOrganizationDto[]> {
        const accountUrl = this.documentUrl + 'issuing-org';
        return this.httpClient.get<DocumentGroupByOrganizationDto[]>(accountUrl, {}).toPromise();
    }

    async getDocOwnerDocuments(queryParam: DocOwnerDocumentQueryParam): Promise<ListResult<DocOwnerDocumentData[]>> {
        const documentUrl = this.docOwnerDocsUrl;
        return this.httpClient.get<ListResult<DocOwnerDocumentData[]>>(documentUrl, { params: queryParam as any }).toPromise();
    }

    async downloadDocument(id: string): Promise<any> {
        const requestOptions: any = {
            responseType: 'blob'
        };
        return this.httpClient.get<any>(this.downloadUrl + id, requestOptions).toPromise();
    }

    async isDocumentsInProcess(queryParam: CheckInProgressDocsRequest): Promise<CheckInProgressDocsResponse> {
        const url = this.documentUrl + 'isInProgressDocs';
        return this.httpClient.post<CheckInProgressDocsResponse>(url, {
            request: queryParam
        }).toPromise();
    }

    async getDocByCategory(queryParam: DocOwnerDocumentQueryParam): Promise<DocumentResponseDto> {
        const documentUrl = this.getDocByCategoryUrl;
        return this.httpClient.get<DocumentResponseDto>(documentUrl, { params: queryParam as any }).toPromise();
    }

    /**
     * 
     * @param queryParam 
     * @returns object of mulitple custom field array e.g. : { customField1: [], customField2: []}
     * NOTE: response type is any[] because we can have dynamic custom fields for particular document category
     */
    async getCustomFieldValues(queryParam: DocOwnerDocumentQueryParam): Promise<ListResult<any[]>> {
        const documentUrl = this.customFieldValues;
        return this.httpClient.get<ListResult<any[]>>(documentUrl, { params: queryParam as any }).toPromise();
    }

}
