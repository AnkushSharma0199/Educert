import { HttpClient } from '@angular/common/http';
import { Injectable } from "@angular/core";
import { environment } from 'environments/environment';
import { InitConfigurationData } from '../app.interface';

@Injectable({
    providedIn: 'root'
})
export class InitService {
    contactInfoUrl = environment.baseUrl + 'init/configuration/';

    constructor(private httpClient: HttpClient) { }

    async getInitConfig(): Promise<InitConfigurationData> {
        return this.httpClient.get<InitConfigurationData>(this.contactInfoUrl).toPromise();
    }
}
