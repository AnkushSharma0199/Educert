import { Component, Inject, Injectable, Optional } from '@angular/core';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarRef, MatSnackBarVerticalPosition, MAT_SNACK_BAR_DATA, } from '@angular/material/snack-bar';
import { TranslateService } from '@ngx-translate/core';
import { NotificationTypeEnum } from 'app/app.enum';
import { environment } from 'environments/environment';

interface NotificationData {
    type: NotificationTypeEnum;
    finalMessage: string;
}

@Component({
    template:
        `<div class="row alert custom-alert-{{ notificationData?.type }}">
            <span>{{ notificationData?.finalMessage }} </span>
            <span class="ml-auto cursor-pointer">
                <i class="material-icons white-color-icon" (click)="snackBarRef.dismiss()">close</i>
            </span>
         </div>`,
})
export class NotificationComponent {
    constructor(
        @Inject(MAT_SNACK_BAR_DATA)
        @Optional()
        public notificationData: NotificationData,
        public snackBarRef: MatSnackBarRef<NotificationComponent>,
    ) { }
}

@Injectable({
    providedIn: 'root'
})
export class NotificationService {
    horizontalPosition: MatSnackBarHorizontalPosition = 'end';
    verticalPosition: MatSnackBarVerticalPosition = 'top';

    constructor(private snackBar: MatSnackBar,
        private translateService: TranslateService) { }

    public notify(
        message: string,
        type: NotificationTypeEnum,
        componentName?: string,
    ) {
        const duration = environment.uiSettings.snackBarDurationInSec;
        this.translateService.get('msg.' + message).subscribe(msg => {
            const finalMessage = componentName ? componentName + ' ' + msg : msg;
            this.snackBar.openFromComponent(NotificationComponent, {
                panelClass: 'app-snack-bar-no-bg-container',
                data: {
                    type,
                    finalMessage,
                },
                duration: duration,
                horizontalPosition: this.horizontalPosition,
                verticalPosition: this.verticalPosition,
            });
        });
    }

    public errorToastNotification(message) {
        if (!message) {
            message = 'internalError';
        }
        this.notify(message, NotificationTypeEnum.Danger);
    }

    public successToastNotification(msg, componentName?: string) {
        this.notify(msg, NotificationTypeEnum.Success, componentName);
    }

    public infoToastNotification(msg, componentName?: string) {
        this.notify(msg, NotificationTypeEnum.Info, componentName);
    }

}
