import { HttpClient } from '@angular/common/http';
import { EventEmitter, Injectable } from '@angular/core';
import { Router } from '@angular/router';
import * as publicIp from 'public-ip';
import { UserRole } from 'app/app.enum';
import { environment } from 'environments/environment';
import {
    EmailVerificationParams,
    ListResult,
    PasswordResetResponse,
    Profile,
    ResetPasswordRequest,
    SignInRequest,
    SignInResponse,
    SignUpRequest,
    SignUpResponse,
    UserData,
    UserQueryParam
} from '../app.interface';
import { SessionStoreService } from './session-store.service';

@Injectable({
    providedIn: 'root',
})
export class UserService {
    authUpdated = new EventEmitter<UserData>();
    baseUrl = environment.baseUrl + 'user/';
    signInUrl = environment.baseUrl + 'user/signin';
    signUpUrl = environment.baseUrl + 'user/signUp';
    constructor(
        private sessionStoreService: SessionStoreService,
        private router: Router,
        private httpClient: HttpClient
    ) { }

    public get DefaultUserAuth(): UserData {
        return {
            accountId: '',
            firstName: '',
            lastName: '',
            email: '',
            accessToken: '',
            isAuthenticated: false,
        };
    }

    /**
     * Check, if user already authorized.
     */
    public get IsAuthorized(): boolean {
        return !!this.AccessToken;
    }

    /**
     * Get access token
     * @returns {Promise<string>}
     */
    public get AccessToken(): string {
        return <string>sessionStorage.getItem('accessToken');
    }

    public async signIn(data: SignInRequest): Promise<SignInResponse> {
        const ipAddress = await publicIp.default.v4();
        return this.httpClient.post<SignInResponse>(this.signInUrl, data, {
            headers: {
                'Public-Ip': ipAddress
            }
        }).toPromise();
    }

    /**
     * Set access token
     */
    public setAccessToken(token: string) {
        sessionStorage.setItem('accessToken', token);
    }

    public async signUp(signUpRequest: SignUpRequest): Promise<SignUpResponse> {
        return this.httpClient.post<SignUpResponse>(this.signUpUrl, signUpRequest).toPromise();
    }

    async getUserById(id: string): Promise<UserData> {
        const profileUrl = this.baseUrl + id;
        return this.httpClient.get<UserData>(profileUrl).toPromise();
    }

    async updateProfile(profile: Profile): Promise<boolean> {
        const profileUrl = this.baseUrl + 'profile';
        return this.httpClient.patch<boolean>(profileUrl, profile).toPromise();
    }

    async resetPassword(resetPasswordRequest: ResetPasswordRequest): Promise<PasswordResetResponse> {
        const apiUrl = this.baseUrl + 'reset-password';
        return this.httpClient.patch<PasswordResetResponse>(apiUrl, resetPasswordRequest).toPromise();
    }

    async verifyEmailLink(emailVerificationParams: EmailVerificationParams): Promise<PasswordResetResponse> {
        const apiUrl = this.baseUrl + 'verifyEmailLink';
        return this.httpClient.patch<PasswordResetResponse>(apiUrl, emailVerificationParams).toPromise();
    }

    /**
     * Logout
     */
    logOut(): void {
        this.router.navigate(['signIn']);
        this.AuthData = this.DefaultUserAuth;
        this.sessionStoreService.removeUserData();
    }

    // To set Auth data of Current User
    public set AuthData(data: UserData) {
        sessionStorage.setItem('userData', JSON.stringify(data));
        this.authUpdated.emit(data);
    }

    // To get auth data of current user
    public get AuthData(): UserData {
        return JSON.parse(sessionStorage.getItem('userData'));
    }

    public async forgotPassword(email: string): Promise<boolean> {
        const apiUrl = this.baseUrl + 'forgot-password';
        return this.httpClient.post<boolean>(apiUrl, { email: email, }).toPromise();
    }

    isSignedIn(): boolean {
        return !!this.sessionStoreService.getUserData();
    }

    isUserDocOwner(): boolean {
        return this.sessionStoreService.getUserData()?.role === UserRole.DocOwner;
    }

    async retrieveJwtToken(): Promise<string> {
        const jwtToken = this.sessionStoreService.getUserData().accessToken;
        return new Promise((resolve) => resolve(jwtToken));
    }

    getUserData() {
        return this.sessionStoreService.getUserData();
    }

    async updateUser(id: string, userData: UserData): Promise<UserData> {
        const accountUrl = this.baseUrl + id;
        return this.httpClient.patch<UserData>(accountUrl, userData).toPromise();
    }

    async createUser(userData: UserData): Promise<UserData> {
        const accountUrl = this.baseUrl;
        return this.httpClient.post<UserData>(accountUrl, userData).toPromise();
    }

    async deleteUser(id: string): Promise<UserData> {
        const accountUrl = this.baseUrl + id;
        return this.httpClient.delete<UserData>(accountUrl, {}).toPromise();
    }

    async getUserList(queryParam: UserQueryParam): Promise<ListResult<UserData[]>> {
        const accountUrl = this.baseUrl;
        return this.httpClient.get<ListResult<UserData[]>>(accountUrl, {
            params: queryParam as any
        }).toPromise();
    }

    async getUserDDL(queryParams) {
        const accountUrl = this.baseUrl + 'ddl'
        return this.httpClient.get<UserData[]>(accountUrl, {
            params: queryParams as any
        }).toPromise();
    }

    async changeStatus(id: string, bodyData): Promise<UserData> {
        const accountUrl = this.baseUrl + 'changeStatus/' + id;
        return this.httpClient.patch<UserData>(accountUrl, bodyData).toPromise();
    }

    async resendInvitationEmail(id: string) {
        const accountUrl = this.baseUrl + 'resendInvitationEmail/' + id;
        return this.httpClient.patch<UserData>(accountUrl, {}).toPromise();
    }

    async changePassword(userId, model: any) {
        const apiUrl = this.baseUrl + userId + '/changePassword';
        return this.httpClient.patch<UserData>(apiUrl, model).toPromise();
    }

    async sendVerificationEmail(userData: UserData): Promise<boolean> {
        const emailVerificationUrl = this.baseUrl + 'verificationEmail';
        return this.httpClient.patch<boolean>(emailVerificationUrl, userData).toPromise();
    }

    async firstPasswordChange(email: string, newPassword: string, passwordSecurityCode: string): Promise<UserData> {
        const firstPasswordChangeUrl = this.baseUrl + 'passwordReset';
        return this.httpClient.post<UserData>(firstPasswordChangeUrl, {
            email,
            password: newPassword,
            passwordSecurityCode
        }).toPromise();
    }
}
