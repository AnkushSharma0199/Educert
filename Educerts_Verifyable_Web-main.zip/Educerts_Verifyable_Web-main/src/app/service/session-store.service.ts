import { EventEmitter, Injectable } from '@angular/core';
import { InitConfigurationData, UserData } from '../app.interface';

const APP_CONFIG_KEY = 'appConfig';

@Injectable({
    providedIn: 'root'
})
export class SessionStoreService {
    appConfigUpdated = new EventEmitter<InitConfigurationData>();

    getUserData(): UserData {
        const data = sessionStorage.getItem('userData');
        return JSON.parse(data);
    }

    setUserData(userData: UserData): void {
        sessionStorage.setItem('userData', JSON.stringify(userData));
    }

    removeUserData(): void {
        sessionStorage.removeItem('userData');
        sessionStorage.removeItem('accessToken');
    }

    setInitConfig(appConfig: InitConfigurationData): void {
        sessionStorage.setItem(APP_CONFIG_KEY, JSON.stringify(appConfig));
        this.appConfigUpdated.emit(appConfig);
    }

    getInitConfig(): InitConfigurationData {
        const data = sessionStorage.getItem(APP_CONFIG_KEY);
        return JSON.parse(data);
    }
}
