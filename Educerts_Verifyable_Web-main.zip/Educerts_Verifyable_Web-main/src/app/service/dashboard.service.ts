import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'environments/environment';
import { DashboardCounterData, DashboardGraphData, DashboardTableData } from '../app.interface';

@Injectable({
    providedIn: 'root'
})
export class DashboardService {

    baseUrl = environment.baseUrl + 'dashboard/';
    constructor(private httpClient: HttpClient) { }

    async getDashboardCounters(): Promise<DashboardCounterData> {
        const accountUrl = this.baseUrl + 'counters';
        return this.httpClient.get<DashboardCounterData>(accountUrl).toPromise();
    }

    async getDashboardGraphs(): Promise<DashboardGraphData> {
        const accountUrl = this.baseUrl + 'graphs';
        return this.httpClient.get<DashboardGraphData>(accountUrl).toPromise();
    }

    async getDashboardTables(): Promise<DashboardTableData> {
        const accountUrl = this.baseUrl + 'tables';
        return this.httpClient.get<DashboardTableData>(accountUrl).toPromise();
    }

}
