import { Pipe, PipeTransform } from '@angular/core';
import { RoutingConstant } from 'app/app.routing.constant';
import * as _ from 'lodash';

@Pipe({
    name: 'route',
})
export class RoutePipe implements PipeTransform {
    transform(value: any, args?: any): any {
        return _.get(RoutingConstant, value);
    }
}
