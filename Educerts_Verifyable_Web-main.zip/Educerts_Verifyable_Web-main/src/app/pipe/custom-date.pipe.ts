import { DatePipe } from '@angular/common';
import { Pipe, PipeTransform } from '@angular/core';
import { environment } from '../../environments/environment';
@Pipe({
    name: 'customDate',
})
export class CustomDatePipe extends DatePipe implements PipeTransform {

    transform(value: any): any {
            return super.transform(value, environment.uiSettings.dateFormat);
    }
}
