import { Pipe, PipeTransform } from '@angular/core';
import { environment } from '../../environments/environment';
@Pipe({
    name: 'default',
})
export class DefaultPipe implements PipeTransform {
    transform(value: any, args?: any): any {
        return value ? value : environment.uiSettings.defaultValue;
    }
}
