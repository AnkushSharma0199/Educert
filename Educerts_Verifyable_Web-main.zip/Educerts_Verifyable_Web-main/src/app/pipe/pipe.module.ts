import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RoutePipe } from './route.pipe';
import { DefaultPipe } from './default.pipe';
import { CustomDatePipe } from './custom-date.pipe';

@NgModule({
    imports: [CommonModule],
    exports: [RoutePipe, DefaultPipe, CustomDatePipe],
    declarations: [RoutePipe, DefaultPipe, CustomDatePipe],
})
export class PipeModule { }
