import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup, Validators, NgForm, UntypedFormControl, FormGroupDirective, } from '@angular/forms';
import { Router } from '@angular/router';
import { FormControlValidators } from 'app/app.validator';
import { NotificationService } from 'app/service/notification.service';
import { UserService } from 'app/service/user.service';
import { environment } from 'environments/environment';
@Component({
    selector: 'app-sign-up',
    templateUrl: './sign-up.component.html',
    styleUrls: [],
})
export class SignUpComponent implements OnInit {
    public passwordHidden = true;
    public loading = false;
    public signUpForm: UntypedFormGroup;
    buildVersion: string;
    showError = false;
    @ViewChild(FormGroupDirective, { static: true }) ngForm: NgForm;
    constructor(
        fb: UntypedFormBuilder,
        private router: Router,
        private userService: UserService,
        private notificationService: NotificationService
    ) {
        this.signUpForm = fb.group({
            firstName: new UntypedFormControl('', [Validators.required]),
            lastName: new UntypedFormControl('', [Validators.required]),
            email: FormControlValidators.RequiredEmail,
            password: FormControlValidators.Password,
        });
    }

    ngOnInit() {
        this.buildVersion = environment.appVersion;
    }

    onReset() {
        this.ngForm.resetForm();
    }

    signIn() {
        this.router.navigate(['signIn']);
    }

    async createAccount() {
        this.loading = true;
        const formValues = {
            firstName: this.signUpForm.get('firstName').value,
            lastName: this.signUpForm.get('lastName').value,
            email: this.signUpForm.get('email').value,
            password: this.signUpForm.get('password').value,
        }
        try {
            const res = await this.userService.signUp(formValues)
            this.showError = false;
            this.notificationService.successToastNotification('signUpSuccessfully');
            this.router.navigate(['signIn']);
        } catch (e) {
            this.showError = true;
            this.notificationService.errorToastNotification(e?.error?.message);
        }
        finally {
            this.loading = false;
        }
    }

    // convenience getter for easy access to form fields
    get f() { return this.signUpForm.controls; }

}
