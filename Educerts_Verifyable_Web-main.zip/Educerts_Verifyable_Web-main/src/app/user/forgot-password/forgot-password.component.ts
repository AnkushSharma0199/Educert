
import { Component, OnInit } from '@angular/core';
import { UntypedFormGroup } from '@angular/forms';

import { FormControlValidators } from 'app/app.validator';
// Services
import { UserService } from 'app/service/user.service';
import { NotificationService } from 'app/service/notification.service';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
    selector: 'app-forgot-password',
    templateUrl: './forgot-password.component.html',
    styleUrls: []
})
export class ForgotPasswordComponent {

    public loading = false;
    // Form controls
    passwordForm = new UntypedFormGroup({
        email: FormControlValidators.RequiredEmail
    });

    constructor(
        private matDialogRef: MatDialogRef<ForgotPasswordComponent>,
        private userService: UserService,
        private notificationService: NotificationService) { }

    async forgotPassword(value) {
        this.loading = true;
        try {
            const res = await this.userService.forgotPassword(value.email)
            this.notificationService.successToastNotification('emailSentSuccessfully');
        } catch (e) {
            this.notificationService.errorToastNotification(e?.error?.message);
        }
        finally {
            this.loading = false
            this.matDialogRef.close();
        }
    }

}
