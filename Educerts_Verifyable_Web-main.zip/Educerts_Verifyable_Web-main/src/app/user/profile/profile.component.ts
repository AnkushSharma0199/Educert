import { Component, OnInit, ViewChild } from '@angular/core';
import { UntypedFormArray, UntypedFormBuilder, FormControl, UntypedFormGroup, FormGroupDirective, NgForm, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import * as _ from 'lodash';
import { UserRole } from 'app/app.enum';
import { State, UserData, AdditionalEmailData } from 'app/app.interface';
import { FormControlValidators } from 'app/app.validator';
import { DialogConfirmationComponent } from '../../shared/dialog-confirmation/dialog-confirmation.component';
import { MasterService } from 'app/service/master.service';
import { UserService } from 'app/service/user.service';
import { NotificationService } from 'app/service/notification.service';
import { SessionStoreService } from 'app/service/session-store.service';
import { SharedService } from 'app/service/shared.service';
import { DateAdapter, MatDateFormats, MAT_DATE_FORMATS, NativeDateAdapter } from '@angular/material/core';

// when input is given using date-picker, the APP_Date_Formats gives displayFormat value 'input' to AppDateAdapter to show date format DD/MM/YYYY on input field
// on case input is being selected then default date format of date-picker is used to show date with that format in the date-picker calendar
export class AppDateAdapter extends NativeDateAdapter {
    format(date: Date, displayFormat: Object): string {
        if (displayFormat === 'input') {
        let day: string = date.getDate().toString();
        day = +day < 10 ? '0' + day : day;
        let month: string = (date.getMonth() + 1).toString();
        month = +month < 10 ? '0' + month : month;
        let year = date.getFullYear();
        return `${day}/${month}/${year}`;
      }
      return date.toDateString();
    }
  }

  export const APP_DATE_FORMATS: MatDateFormats = {
    parse: {
      dateInput: { month: 'short', year: 'numeric', day: 'numeric' },
    },
    display: {
      dateInput: 'input',
      monthYearLabel: { year: 'numeric', month: 'numeric' },
      dateA11yLabel: { year: 'numeric', month: 'long', day: 'numeric'
      },
      monthYearA11yLabel: { year: 'numeric', month: 'long' },
    }
  };

@Component({
    selector: 'app-profile',
    templateUrl: './profile.component.html',
    styleUrls: ['./profile.component.css'],
    providers: [
        { provide: DateAdapter, useClass: AppDateAdapter },
        { provide: MAT_DATE_FORMATS, useValue: APP_DATE_FORMATS }
    ],
})
export class ProfileComponent implements OnInit {
    public loading = false;
    stateList: State[] = [];
    @ViewChild('changePasswordRef', { static: true }) changePasswordRef: NgForm;
    public userProfileForm: UntypedFormGroup;
    public deletedEmailsArray = [];
    public displayAdditionalDetails = false;
    public displayAdditionalEmails = false;
    userData: UserData
    showStateField = false;
    userId: string;
    isDocOwner = false;
    maxStringLength = 265;
    fullDescription = '';
    description = ''
    showReadLess = false;
    showReadMore = false;
    maxValidDoB: Date = new Date()
    fullName = '';
    onlyPositiveNumber = SharedService.allowOnlyPositiveNumbers;

    @ViewChild(FormGroupDirective, { static: true }) ngForm: NgForm;
    constructor(
        private fb: UntypedFormBuilder,
        private userService: UserService,
        private notificationService: NotificationService,
        private sessionStoreService: SessionStoreService,
        private sharedService: SharedService,
        private masterService: MasterService,
        public dialog: MatDialog,
    ) {
        this.userProfileForm = fb.group({
            firstName: FormControlValidators.Required,
            middleName: FormControlValidators.None,
            lastName: FormControlValidators.Required,
            email: FormControlValidators.Disabled,
            role: FormControlValidators.Disabled,
            dateOfBirth: FormControlValidators.None,
            state: FormControlValidators.Disabled,
            mobile: FormControlValidators.Phone,
            aadhaarNumber: FormControlValidators.AadharNumber,
            additionalEmails: fb.array([this.newAdditionalEmail()]),
            designation: FormControlValidators.Designation,
            employeeID: FormControlValidators.EmployeeID,
        });
        this.isDocOwner = this.sharedService.isUserDocOwner()
    }

    async ngOnInit() {
        this.userId = this.sessionStoreService.getUserData().id

        await this.getProfileData()
        if (this.userData?.role === UserRole.StateRegulator) {
            this.getStateData()
        }
        this.userProfileForm.patchValue(
            {
                firstName: this.userData.firstName,
                middleName: this.userData.middleName,
                lastName: this.userData.lastName,
                email: this.userData.email,
                role: this.sharedService.getUserRoleName(this.userData.role),
                aadhaarNumber: this.userData.aadhaarNumber,
                mobile: this.userData.mobile,
                dateOfBirth: this.userData.dateOfBirth,
                employeeID: this.userData.employeeID,
                designation: this.userData.designation,
            }
        )
        this.fullName = this.sharedService.getFullName(this.userData.firstName, this.userData.middleName, this.userData.lastName)
        this.patchAdditionalEmailData()
        await this.getProfileDescription()
    }

    patchAdditionalEmailData() {
        const emailControl = <UntypedFormArray>this.userProfileForm.controls['additionalEmails'];
        if (this.userData.additionalEmails?.length && this.userData.additionalEmails?.length !== 0) {
            /*if length is not zero, then first removing all values, so that we can omit out empty input
            box values, and then later on , in next step, add non empty emails */
            emailControl.controls = []
        }
        this.userData.additionalEmails?.forEach((element, i) => {
            const variant = this.newAdditionalEmail(element.emailSecurityCode, element.emailTimestamp, element.isAddedInDB)
            emailControl.push(variant);
            emailControl.at(i).patchValue(element);
        });
    }

    async getProfileData() {
        try {
            this.userData = await this.userService.getUserById(this.userId)
            this.userData.additionalEmails?.forEach(
                x => x.isAddedInDB = true
            )
        } catch (e) {
            this.notificationService.errorToastNotification(e?.error?.message);
        }
    }

    newAdditionalEmail(emailSecurityCode = null, emailTimestamp = null, isAddedInDB: boolean = false, isSendVerificationMail = false): UntypedFormGroup {
        return this.fb.group({
            email: FormControlValidators.Email,
            isVerified: false,
            isAddedInDB: isAddedInDB,
            emailSecurityCode: emailSecurityCode || null,
            emailTimestamp: emailTimestamp || null,
            isSendVerificationMail: isSendVerificationMail
        })
    }

    public removeEmail(deletedEmailObj: AdditionalEmailData, i: number) {
        const emails = this.userProfileForm.get('additionalEmails') as UntypedFormArray
        if (deletedEmailObj.isAddedInDB) {
            this.deletedEmailsArray.push(deletedEmailObj)
        }
        if (emails.length > 1) {
            emails.removeAt(i)
        } else {
            emails.reset()
        }
    }

    createAdditionalEmail() {
        const control = <UntypedFormArray>this.userProfileForm.controls.additionalEmails;
        const emailObj = this.newAdditionalEmail(null, null, false, true)
        control.push(emailObj);
    }

    onchangeEmail(event, ctrl, index) {
        const email = event.target.value
        if (email !== '') {
            let isVerified = false;
            const control = <UntypedFormArray>this.userProfileForm.controls['additionalEmails'];
            this.userData.additionalEmails?.forEach(x => {
                // checking whether reEntered the same Email, after editing, if so, then show the verfication value according to that
                if (x.email === email) {
                    isVerified = x.isVerified
                    control.at(index).patchValue({ isSendVerificationMail: false });
                    return;
                } else {
                    control.at(index).patchValue({ isSendVerificationMail: true });
                }
            })
            control.at(index).patchValue({ isVerified: isVerified });
            this.userProfileForm.controls['additionalEmails'].updateValueAndValidity()
        }
    }

    async getStateData() {
        const res = await this.masterService.getStateList()
        this.stateList = res;
        const stateObject = this.stateList.find((item) => item && item.id === this.userData?.stateId);
        this.userProfileForm.patchValue({ state: stateObject?.name })
        this.showStateField = true
    }

    async resendVerificationEmail(email?: string) {
        try {
            const data: UserData = { id: this.userData.id }
            // additional email verification case
            if (email) {
                data.email = email
            }
            const isEmaiAddedInDB = this.userData.additionalEmails?.find(x => x.email === email)
            if (!isEmaiAddedInDB) {
                this.notificationService.errorToastNotification('pleaseAddYourEmailFirst');
                return
            }
            await this.userService.sendVerificationEmail(data)
            this.notificationService.successToastNotification('verificationEmailSentSuccessfully');
        } catch (e) {
            this.notificationService.errorToastNotification(e?.error?.message);
        }
    }

    updateProfile(value) {
        if (this.deletedEmailsArray.length > 0) {
            const dialogRef = this.dialog.open(DialogConfirmationComponent, {
                panelClass: 'confirmation-popup',
                data: {
                    description: 'Are you sure?',
                    descriptionBold: '',
                    icon: '',
                    note: 'You want to delete existing emails',
                    title: 'Profile'
                },
            });
            dialogRef.afterClosed().subscribe((confirmed: boolean) => {
                if (confirmed) {
                    this.updateData(value)
                } else {
                    return;
                }
            });
        } else {
            this.updateData(value)
        }
    }
    async updateData(value) {
        // removing blank emails
        value.additionalEmails = _.uniqBy(value.additionalEmails, 'email');
        const additionalEmailData: AdditionalEmailData[] = []
        value.additionalEmails.forEach(x => {
            if (x.email !== '') {
                additionalEmailData.push(
                    {
                        email: x.email?.toLowerCase(),
                        isVerified: x.isVerified,
                        emailTimestamp: x.emailTimestamp,
                        emailSecurityCode: x.emailSecurityCode,
                        isAddedInDB: x.isAddedInDB,
                        isSendVerificationMail: x.isSendVerificationMail
                    }
                )
            }
        });

        this.loading = true;
        const profileData = {
            mobile: value.mobile,
            aadhaarNumber: value.aadhaarNumber,
            firstName: value.firstName,
            middleName: value.middleName,
            lastName: value.lastName,
            dateOfBirth: value.dateOfBirth,
            designation: value.designation,
            employeeID: value.employeeID,
            // adding email, because disabled form control values are not included in form
            email: this.userData.email,
            additionalEmails: additionalEmailData
        }
        try {
            const res = await this.userService.updateProfile(profileData)
            this.userData = {
                ...this.userData,
                ...profileData
            }
            this.fullName = this.sharedService.getFullName(this.userData.firstName, this.userData.middleName, this.userData.lastName)
            // updating the form, to remove empty emails boxes
            this.patchAdditionalEmailData()
            // updating user auth data
            const updatedAuthData = {
                ...this.sessionStoreService.getUserData(),
                firstName: this.userData.firstName,
                middleName: this.userData.middleName,
                lastName: this.userData.lastName,
            }
            this.sessionStoreService.setUserData(updatedAuthData);
            this.userService.AuthData = updatedAuthData
            this.notificationService.successToastNotification('successfullyUpdated', 'Profile');
        } catch (e) {
            this.notificationService.errorToastNotification(e?.error?.message);
        }
        finally {
            this.loading = false;
            this.deletedEmailsArray = []
        }
    }

    // convenience getter for easy access to form fields
    get f() { return this.userProfileForm.controls; }

    async getProfileDescription() {
        const role = await this.masterService.getRoleByCode(this.userData.role.toString())
        this.fullDescription = role.description;
        if (this.fullDescription.length > this.maxStringLength) {
            this.showReadMore = true
            this.description = this.fullDescription.substring(0, this.maxStringLength)
        } else {
            this.description = this.fullDescription
        }
    }

    getShortDescription() {
        this.description = this.fullDescription.substring(0, this.maxStringLength)
        this.showReadLess = false
        this.showReadMore = true;
    }

    getLongDescription() {
        this.description = this.fullDescription
        this.showReadMore = false
        this.showReadLess = true
    }

}
