import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { EmailVerificationParams } from 'app/app.interface';
import { UserService } from 'app/service/user.service';

@Component({
    selector: 'app-email-verification',
    templateUrl: './email-verification.component.html',
    styleUrls: ['./email-verification.component.css']
})
export class EmailVerificationComponent implements OnInit {
    queryParamSubscription: Subscription
    verificationLinkParams: any
    loading = true;
    emailVerificationSuccess = false;
    constructor(private activatedRoute: ActivatedRoute,
        private userService: UserService,
        private router: Router) {
        this.queryParamSubscription = this.activatedRoute.queryParams.subscribe(
            query => {
                this.verificationLinkParams = query;
            },
        );
    }

    ngOnInit(): void {
        this.verify()
    }

    getStarted() {
        this.router.navigate(['home'])
    }

    public async verify() {
        const value: EmailVerificationParams = {
            email: this.verificationLinkParams.email,
            emailSecurityCode: this.verificationLinkParams.uuid,
            userId: this.verificationLinkParams.userId,
        }
        try {
            const res = await this.userService.verifyEmailLink(value)
            this.emailVerificationSuccess = true;
        } catch (e) {
            this.emailVerificationSuccess = false;
        }
        finally {
            this.loading = false;
        }
    }
}
