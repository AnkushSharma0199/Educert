import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { UntypedFormGroup, UntypedFormBuilder } from '@angular/forms';
import { Subscription } from 'rxjs';
import { FormControlValidators } from 'app/app.validator';
import { UserService } from 'app/service/user.service';
import { NotificationService } from 'app/service/notification.service';
import { SessionStoreService } from 'app/service/session-store.service';

@Component({
    selector: 'app-first-change-password',
    templateUrl: './first-change-password.component.html',
    styleUrls: ['./first-change-password.component.css']
})
export class FirstChangePasswordComponent implements OnInit, OnDestroy {
    public passwordHidden = true;
    public confirmPasswordHidden = true;
    public firstChangePasswordForm: UntypedFormGroup;
    public queryParamSubscription: Subscription;
    public verificationParams: any;
    public loading = false;
    public email: string;
    public passwordSecurityCode: string;
    constructor(
        private fb: UntypedFormBuilder,
        private userService: UserService,
        private router: Router,
        private notificationService: NotificationService,
        private activatedRoute: ActivatedRoute,
        private sessionStoreService: SessionStoreService
    ) {
        this.email = this.activatedRoute.snapshot.queryParamMap.get('email');
        this.passwordSecurityCode = this.activatedRoute.snapshot.queryParamMap.get('passwordSecurityCode');
    }

    ngOnInit() {
        this.firstChangePasswordForm = this.fb.group(
            {
                password: FormControlValidators.Password,
                confirmPassword: FormControlValidators.None,
            },
            { validator: FormControlValidators.PasswordMatchValidator },
        );
    }

    /* Called on each input in either password field */
    onPasswordInput() {
        if (this.firstChangePasswordForm.hasError('mismatch')) {
            this.firstChangePasswordForm.controls.confirmPassword.setErrors([
                { passwordMismatch: true },
            ]);
        } else {
            this.firstChangePasswordForm.controls.confirmPassword.setErrors(null);
        }
    }

    public async resetPassword(value) {
        this.loading = true;
        try {
            const res = await this.userService.firstPasswordChange(this.email, this.firstChangePasswordForm.get('password').value, this.passwordSecurityCode);
            this.notificationService.successToastNotification('passwordChanged');
            res.isAuthenticated = true;
            this.userService.AuthData = res;
            this.sessionStoreService.setUserData(res);
            this.userService.setAccessToken(res.accessToken);
            this.router.navigate(['home'])
        } catch (e) {
            this.notificationService.errorToastNotification(e?.error?.message);
        }
        finally {
            this.loading = false;
        }
    }

    public signUp() {
        this.router.navigate(['signUp']);
    }

    ngOnDestroy() {
        // Unsubscribe the events
        if (this.queryParamSubscription) {
            this.queryParamSubscription.unsubscribe();
        }
    }

    // convenience getter for easy access to form fields
    get f() { return this.firstChangePasswordForm.controls; }

}
