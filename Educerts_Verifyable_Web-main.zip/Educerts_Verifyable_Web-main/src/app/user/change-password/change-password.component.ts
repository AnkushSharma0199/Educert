import { Component, OnInit, ViewChild } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup, FormGroupDirective, NgForm } from '@angular/forms';
import { Global } from 'app/app.global';
import { FormControlValidators } from 'app/app.validator';
import { MasterService } from 'app/service/master.service';
import { NotificationService } from 'app/service/notification.service';
import { SessionStoreService } from 'app/service/session-store.service';
import { SharedService } from 'app/service/shared.service';
import { UserService } from 'app/service/user.service';

@Component({
    selector: 'app-change-password',
    templateUrl: './change-password.component.html',
    styleUrls: ['./change-password.component.css'],
})
export class ChangePasswordComponent implements OnInit {
    @ViewChild('changePasswordRef', { static: true }) changePasswordRef: NgForm;
    public changePasswordForm: UntypedFormGroup;
    public userDetails: any;
    public loading = false;
    public currPassHidden = true;
    public newPassHidden = true;
    public userRoleName: string;
    isDocOwner = false;

    maxStringLength = 145;
    fullDescription = '';
    description = ''
    showReadLess = false;
    showReadMore = false;

    @ViewChild(FormGroupDirective, { static: true }) ngForm: NgForm;
    constructor(
        fb: UntypedFormBuilder,
        private userService: UserService,
        private notificationService: NotificationService,
        private sessionStoreService: SessionStoreService,
        public sharedService: SharedService,
        private masterService: MasterService
    ) {
        this.changePasswordForm = fb.group({
            currentPassword: FormControlValidators.Password,
            newPassword: FormControlValidators.Password,
        },
        { validator: FormControlValidators.ResetPasswordMatchValidator }
        );
    }

    async ngOnInit() {
        this.userDetails = this.sessionStoreService.getUserData();
        // converting to text value from integer value
        this.userRoleName = this.sharedService.getUserRoleName(this.userDetails.role)
        this.isDocOwner = this.sharedService.isUserDocOwner()
        await this.getProfileDescription();
    }

    async changePassword() {
        this.loading = true;
        try {
            const res = await this.userService.changePassword(this.userDetails.id, this.changePasswordForm.value);
            this.notificationService.successToastNotification('successfullyUpdated', Global.components.password);
            this.resetChangePasswordForm();
        } catch (e) {
            this.notificationService.errorToastNotification(e?.error?.message);
        }
        finally {
            this.loading = false;
        }
    }

    async getProfileDescription() {
        const role = await this.masterService.getRoleByCode(this.userDetails.role.toString())
        this.fullDescription = role.description;
        if (this.fullDescription.length > this.maxStringLength) {
            this.showReadMore = true
            this.description = this.fullDescription.substring(0, this.maxStringLength)
        } else {
            this.description = this.fullDescription
        }
    }

    getShortDescription() {
        this.description = this.fullDescription.substring(0, this.maxStringLength)
        this.showReadLess = false
        this.showReadMore = true;
    }

    getLongDescription() {
        this.description = this.fullDescription
        this.showReadMore = false
        this.showReadLess = true
    }

    resetChangePasswordForm() {
        if (this.changePasswordRef) {
            this.changePasswordRef.resetForm();
        }
    }

}
