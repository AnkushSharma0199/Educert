import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { CoreModule } from 'app/core/core.module';
import { SharedModule } from '../shared/shared.module';
// Components
import { SignUpComponent } from './sign-up/sign-up.component';
import { SignInComponent } from './sign-in/sign-in.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { ResetPasswordComponent } from './reset-password/reset-password.component';
import { ProfileComponent } from './profile/profile.component';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { EmailVerificationComponent } from './email-verification/email-verification.component';
import { FirstChangePasswordComponent } from './first-change-password/first-change-password.component';

@NgModule({
    declarations: [
        SignUpComponent,
        SignInComponent,
        ForgotPasswordComponent,
        ResetPasswordComponent,
        ProfileComponent,
        ChangePasswordComponent,
        EmailVerificationComponent,
        FirstChangePasswordComponent
    ],
    imports: [
        CoreModule,
        SharedModule,
        FormsModule
    ],
})
export class UserModule { }
