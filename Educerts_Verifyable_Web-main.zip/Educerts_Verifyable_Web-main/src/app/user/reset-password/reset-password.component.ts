
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { UntypedFormGroup, UntypedFormBuilder } from '@angular/forms';
import { Subscription } from 'rxjs';
import { UserService } from 'app/service/user.service';
import { FormControlValidators } from 'app/app.validator';
import { NotificationService } from 'app/service/notification.service';
import { SessionStoreService } from 'app/service/session-store.service';

@Component({
    selector: 'app-reset-password',
    templateUrl: './reset-password.component.html',
    styleUrls: [],
})
export class ResetPasswordComponent implements OnInit, OnDestroy {
    public newPasswordHidden = true;
    public confirmPasswordHidden = true;
    public resetPasswordForm: UntypedFormGroup;
    public queryParamSubscription: Subscription;
    public verificationParams: any;
    public loading = false;
    constructor(
        private fb: UntypedFormBuilder,
        private userService: UserService,
        private router: Router,
        private notificationService: NotificationService,
        private activatedRoute: ActivatedRoute,
        private sessionStoreService: SessionStoreService
    ) {
        this.queryParamSubscription = this.activatedRoute.queryParams.subscribe(
            query => {
                this.verificationParams = query;
            },
        );
    }

    ngOnInit() {
        this.resetPasswordForm = this.fb.group(
            {
                password: FormControlValidators.Password,
                confirmPassword: FormControlValidators.None,
                email: FormControlValidators.None,
                emailSecurityCode: FormControlValidators.None,
            },
            { validator: FormControlValidators.PasswordMatchValidator },
        );
        this.resetPasswordForm.patchValue({
            email: this.verificationParams.email,
            emailSecurityCode: this.verificationParams.uuid,
        });
    }

    /* Called on each input in either password field */
    onPasswordInput() {
        if (this.resetPasswordForm.hasError('mismatch')) {
            this.resetPasswordForm.controls.confirmPassword.setErrors([
                { passwordMismatch: true },
            ]);
        } else {
            this.resetPasswordForm.controls.confirmPassword.setErrors(null);
        }
    }

    public async resetPassword(value) {
        this.loading = true;
        try {
            const res = await this.userService.resetPassword(value)
            this.notificationService.successToastNotification('passwordChanged');
            this.afterResetPassword(res);
        } catch (e) {
            this.notificationService.errorToastNotification(e?.error?.message);
        }
        finally {
            this.loading = false;
        }
    }

    public signUp() {
        this.router.navigate(['signUp']);
    }

    private afterResetPassword(res) {
        res.isAuthenticated = true;
        this.userService.AuthData = res;
        this.sessionStoreService.setUserData(res);
        this.userService.setAccessToken(res.accessToken);
        this.router.navigate(['home'])
    }

    ngOnDestroy() {
        // Unsubscribe the events
        if (this.queryParamSubscription) {
            this.queryParamSubscription.unsubscribe();
        }
    }

    // convenience getter for easy access to form fields
    get f() { return this.resetPasswordForm.controls; }

}
