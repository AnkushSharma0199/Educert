import { Component, OnInit, OnDestroy } from '@angular/core';
import { UntypedFormGroup, UntypedFormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from 'app/service/user.service';
import { MatDialog } from '@angular/material/dialog';
import { Subscription } from 'rxjs';
import { environment } from 'environments/environment';
import { ForgotPasswordComponent } from '../forgot-password/forgot-password.component';
import { NotificationService } from 'app/service/notification.service';
import { SessionStoreService } from 'app/service/session-store.service';
import { SignInRequest } from 'app/app.interface';
import { AppType, UserRole } from 'app/app.enum';

@Component({
    templateUrl: './sign-in.component.html',
    styleUrls: ['./sign-in.component.css']
})
export class SignInComponent implements OnInit, OnDestroy {
    loading = false;
    showError = false;
    buildVersion: string;
    public email = '';
    public passwordHidden = true;
    appConfigUpdatedSubscription: Subscription = null;
    appInstance = environment.appInstance;
    signInForm = new UntypedFormGroup({
        email: new UntypedFormControl('', Validators.required),
        password: new UntypedFormControl('', Validators.required),
        staySignIn: new UntypedFormControl(false),
    });

    constructor(private router: Router,
        private userService: UserService,
        private matDialog: MatDialog,
        private sessionStoreService: SessionStoreService,
        private notificationService: NotificationService) {
        // Return to dashboard if token available on signin
        if (this.userService.isSignedIn()) {
            this.router.navigate(['/home'])
        }
    }

    ngOnInit(): void {
        this.buildVersion = environment.appVersion;
        this.email = this.sessionStoreService.getInitConfig()?.email;
        this.appConfigUpdatedSubscription = this.sessionStoreService.appConfigUpdated.subscribe((appConfig) => {
            this.email = appConfig.email
        });
    }

    async signIn() {
        this.loading = true
        try {
            const value: SignInRequest = {
                email: this.signInForm.get('email').value,
                password: this.signInForm.get('password').value,
                appType: AppType.Portal,
            }
            const res = await this.userService.signIn(value)

            if(res.role === UserRole.RegUser || res.role === UserRole.ApprUser){
                if (res.firstPasswordChanges) {
                    res.isAuthenticated = true;
                    this.userService.AuthData = res;
                    this.sessionStoreService.setUserData(res);
                    this.userService.setAccessToken(res.accessToken);
                    this.router.navigate(['home'])
                } else {
                    this.router.navigate(['first-change-password'], {
                        queryParams: {
                            email: res.email,
                            passwordSecurityCode: res.passwordSecurityCode
                        }
                    })
                }
            }else {
                // this.notificationService.errorToastNotification("onlyRegUserCanSignin");
                this.notificationService.errorToastNotification("onlyRegUserApprUserCanSignIn")
            }
        } catch (e) {
            this.showError = true;
            this.notificationService.errorToastNotification(e?.error?.message);
        }
        finally {
            this.loading = false
        }
    }

    // convenience getter for easy access to form fields
    get f() { return this.signInForm.controls; }

    signUp() {
        this.router.navigate(['signUp']);
    }

    public openForgotPasswordDialog() {
        this.matDialog.open(ForgotPasswordComponent, {
            panelClass: 'app-dialog-no-bg-container',
        });
    }

    ngOnDestroy(): void {
        if (this.appConfigUpdatedSubscription) {
            this.appConfigUpdatedSubscription.unsubscribe();
        }

    }

}
