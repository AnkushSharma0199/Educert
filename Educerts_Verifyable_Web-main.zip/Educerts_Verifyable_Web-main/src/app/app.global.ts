const global = {
    regex: {
        stringWithNoSpace: /^\S+$/,
        onlyAlphabets: /^[a-zA-Z ]*$/,
        password: /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9]).{8,20}$/,
        phone: /^\+?[0-9\.\-\(\)\s]+$/,
        number: /^(0|(0*[1-9][0-9]*(\.\d\d?)?)|(0?\.\d\d?))$/,
        removeHtmlTag: /<[^>]*>/g,
        replaceUnderscoreWithSpace: /_/g,
        customEmailField: /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[a-z]{2,4}$/,
        fax: /^\+?[0-9\.\-\(\)\s]+$/,
        fullNumber: /^[0-9]+$/,
        postalCode: /^[1-9][0-9]{5}$/,
        aadharNumber: /^([0-9]){12}$/,
        year: /^\d{4}$/,
        domainName: /(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z0-9][a-z0-9-]{0,61}[a-z0-9]/,
        ipAddress: /^(\*|25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(\*|25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(\*|25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(\*|25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/
    },

    file: {
        mbConversionUnit: 1000000,
        extensions: {
            XLS: 'xls',
            XLSX: 'xlsx',
            DOC: 'doc',
            DOCX: 'docx',
            CSV: 'csv',
            PDF: 'pdf',
        },
    },
    image: {
        chooseImageText: 'For best results, upload logo with white or no background',
        acceptedFileType: 'image/x-png,image/gif,image/jpeg,image/jpg',
    },
    values: {
        none: 'None',
        childTableLeftMargin: '25px'
    },
    components: {
        dashboard: 'Home',
        organization: 'Organization',
        user: 'User',
        password: 'Password',
        documentFlow: 'Document Flow',
    },
    breakPoint: {
        xs: 300,
        sm: 565,
        md: 835,
        lg: 1045,
        xl: 1225,
    },
    entity: {
        fileName: '${ Name }_${ TimeStamp }.${ Extension }',
    },
    fileNames:
    {
        summaryByStateReport: 'Summary_By_State_Report',
        docTypeUploadsByOrgProgrammeReport: 'Uploads_By_Organization_And_Programme_Report',
        docTypeUploadsByOrgMakerReport: 'Uploads_By_Organization_And_Maker_Report',
        makerActivityByDateReport: 'Maker_Activity_By_Date_Report',
    },
    labels:
    {
        appliedFilters: 'Applied Filters: ',
        programName: 'Program Name',
        docType: 'Document Type',
        docSubType: 'Document Sub Type',
        date: 'Date',
        makerEmail: 'Maker Email',
        dotsForTrimmedString: '...',
        salesPartner: 'Sales Partner',
        state: 'State',
        academicYear: 'Academic Year',
        organization: 'Organization',
        rollNumber: 'Roll Number',
        email: 'Email',
        name: 'Name',
        role: 'Role'
    },
    enum: {
        'LastOneMonth': 'Last 1 Month',
        'LastTwoMonths': 'Last 2 Months',
        'LastFourMonths': 'Last 4 Months',
        'LastSixMonths': 'Last 6 Months',
        'LastOneYear': 'Last 1 Year',
    },
    separtors:
    {
        keyValue: ' - ',
        comma: ', ',
        dateFromDateTo: ' - '
    },
    documentColumnsToDisplay: ['FullName', 'RollNo', 'AcademicYear', 'Action']

};

export const Global = Object.freeze(global);
