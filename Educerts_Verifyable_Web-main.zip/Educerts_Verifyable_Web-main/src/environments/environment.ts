export const environment = {
    production: false,
    baseUrl: 'http://localhost:3000/',
    appInstance: '',
    // baseUrl: 'https://api.educerts.net/V2/',
    // baseUrl: 'https://api.layered-security.com/v2/',
    appVersion: '2.2341.2',
    // Auto logout feature related settings
    idleTimeout: {
        timerWillStartInSec: 3600000,
        timerWillWaitInSec: 5
    },
    // config values specific to UI
    uiSettings: {
        // Default value to show on UI when actual value is not available
        defaultValue: 'NA',
        // Pagination settings
        pagination: {
            options: [5, 25, 50, 100],
            rowsPerPage: 5,
        },
        // date format
        dateFormat: 'MMM d, y',
        // Default country value in dropdown
        defaultCountry: { name: 'India', code: 'IN' },
        // Duration for which to show snackbar
        snackBarDurationInSec: 3500
    },
    // Images path
    images: {
        // State regulator dashboard image path
        welcomeImagesPath: 'assets/images/welcome/'
    }
};
