Write-Host -ForegroundColor Yellow "`nQA - Deploying App to S3"

#upload file
aws s3 cp ./release s3://docker-qa-tool/PdfGeneratorApp --recursive --acl public-read --profile DockerQA
write-host -ForegroundColor Yellow "`nQA - App successfully uploaded"

Read-Host -Prompt "`nPress Enter to exit"
