export const AppConfig = {
    production: true,
    environment: 'PROD',
    baseUrl: 'https://api.educerts.net/',
    appVersion: '23.44.8',
    log: {
        // 1 - File
        // 2 - SumoLogic
        // 3 - both
        logLocation: 3,
        sumoLogicHttpUrl: "https://collectors.in.sumologic.com/receiver/v1/http/ZaVnC4dhaV1pgjKFxtYr2r38-0GNDdW1GA-v-jZR6xG7LRb_rFnSCYjULZ1Rb6SMAcx5d2ZlWJmgac9t_syNS5ZAbB6f6caxSI3HLUmre1A1s7TcpFY6mQ=="
    }
};
