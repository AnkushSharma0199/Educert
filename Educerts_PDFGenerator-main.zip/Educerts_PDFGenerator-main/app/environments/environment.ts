export const AppConfig = {
    production: false,
    environment: 'LOCAL',
    baseUrl: 'http://localhost:3000/',
    appVersion: '23.44.8',
    log: {
        // 1 - File
        // 2 - SumoLogic
        // 3 - both
        logLocation: 3,
        sumoLogicHttpUrl: "https://collectors.in.sumologic.com/receiver/v1/http/ZaVnC4dhaV01HAHp2gwxe9V_nM5ff-cTJFLQNeACL34HD_tFgccjbBTqBXZ_vPDo3H0VrLtPDHS0nRUblzr_NV6PUL-qS7aFIfa5FK_dSngyLPZf8zOF_A=="
    }
};
