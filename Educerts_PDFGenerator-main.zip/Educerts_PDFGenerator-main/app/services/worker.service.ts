import { resolve } from 'path';
import Piscina from 'piscina';
import { WorkerInputParam } from '../app.interface';

// This is required to transpile ts to js module file
import * as worker from './worker';

export class WorkerService {
    pool = new Piscina({
        filename: resolve(__dirname, 'worker.js')
    });

    public async processWorkerPool(contents: WorkerInputParam[]) {
        const poolArr = [];
        contents.map((item) => {
            poolArr.push(this.pool.run(item));
        });
        await Promise.all(poolArr);
        return true;
    }
}
