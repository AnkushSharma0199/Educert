import * as csvWriter from 'csv-writer';

export class CsvWriterService {
    csvWriterObj = null;
    
    async setCsvCreatorObject(dataObj): Promise<void> {
        this.csvWriterObj = csvWriter.createObjectCsvWriter({
            path: dataObj.path,
            header: dataObj.header
        })
    }

    async csvWriteRecord(record): Promise<void> {
        await this.csvWriterObj.writeRecords(record);
    }
}
