import { ipcMain } from 'electron';
import * as logger from 'electron-log'
import * as publicIp from 'public-ip'
import * as os from 'os'
import { LogMessage } from '../app.interface';
import { AppConfig } from "../environments/environment";

export class LoggerSetupService {
    constructor() {
        const logLocation = AppConfig.log.logLocation;
        const logClient = 'App - Pdf Generator -' + AppConfig.environment.toLowerCase() + ' - V2';

        switch (logLocation) {
            case 1: // 1 - File
                logger.transports.file.level = "info"
                break;
            case 2: // 2 - SumoLogic
                logger.transports.remote.level = 'error';
                logger.transports.remote.client = { name: logClient };
                logger.transports.remote.url = AppConfig.log.sumoLogicHttpUrl;
                break;
            case 3: // 3 - both
                logger.transports.file.level = "info"
                logger.transports.remote.level = 'error';
                logger.transports.remote.client = { name: logClient };
                logger.transports.remote.url = AppConfig.log.sumoLogicHttpUrl;
                break;
        }

        // monkey patching logger library to add custom message
        const originalInfoFn = logger.info;
        logger.default.info = (...params: any[]): void => {
            this.prepareLogMessage().then(msg => {
                msg.Message = params;
                originalInfoFn(msg);
            })
        }

        logger.default.log = (...params: any[]): void => {
            this.prepareLogMessage().then(msg => {
                msg.Message = params;
                originalInfoFn(msg);
            })
        }

        const originalWarnFn = logger.warn;
        logger.default.warn = (...params: any[]): void => {
            this.prepareLogMessage().then(msg => {
                msg.Message = params;
                originalWarnFn(msg);
            })
        }

        const originalErrorFn = logger.error;
        logger.default.error = (...params: any[]): void => {
            this.prepareLogMessage().then(msg => {
                msg.Message = params;
                originalErrorFn(msg);
            })
        }

        const originalDebugFn = logger.debug;
        logger.default.debug = (...params: any[]): void => {
            this.prepareLogMessage().then(msg => {
                msg.Message = params;
                originalDebugFn(msg);
            })
        }

        const originalSillyFn = logger.silly;
        logger.default.silly = (...params: any[]): void => {
            this.prepareLogMessage().then(msg => {
                msg.Message = params;
                originalSillyFn(msg);
            })
        }

        const originalVerboseFn = logger.verbose;
        logger.default.verbose = (...params: any[]): void => {
            this.prepareLogMessage().then(msg => {
                msg.Message = params;
                originalVerboseFn(msg);
            })
        }

        ipcMain.handle('logger-logInfo', async (event, args) => {
            logger.info(args);
        });

        ipcMain.handle('logger-logError', async (event, args) => {
            logger.error(args);
        });

        // Replace console.log functions with electron-log's
        console.log = logger.info;
    }

    private prepareLogMessage = async (): Promise<LogMessage> => {
        const logMessage = new LogMessage();
        const ipAddress = await publicIp.v4() || '';

        logMessage.BuildNo = AppConfig.appVersion;
        logMessage.Environment = AppConfig.environment;

        logMessage.UserName = '';
        logMessage.UserId = '';

        logMessage.OrganizationName = '';
        logMessage.OrganizationId = '';

        logMessage.IpAddress = ipAddress;

        logMessage.HostName = os.hostname();
        logMessage.OSType = os.type();
        logMessage.OSRelease = os.release();

        logMessage.Timestamp = Date();

        return logMessage;
    }
}
