import { app } from 'electron';
import * as path from 'path';
import * as fs from 'fs';
const FILE_NAME = 'mapping.json';
const JSON_STORE_FOLDER_NAME = 'Json_data'

export class JsonStorageService {
    userDataPath = app.getPath('userData');
    storeFolderPath = path.join(this.userDataPath, JSON_STORE_FOLDER_NAME);
    filePath = path.join(this.userDataPath, JSON_STORE_FOLDER_NAME, FILE_NAME);

    checkFieldMappingExists() {
        return fs.existsSync(this.filePath);
    }

    setFieldMapping(data) {
        if (!fs.existsSync(this.storeFolderPath)) {
            fs.mkdir(this.storeFolderPath, { recursive: true }, (err) => {
                if (err) return
            })
        }

        const filePath = path.join(this.storeFolderPath, FILE_NAME)
        fs.writeFileSync(filePath, data);
    }

    async getFieldMapping() {
        return new Promise((resolve, reject) => {
            fs.readFile(this.filePath, "utf8", (err, jsonString) => {
                if (err) {
                    resolve(false);
                }
                try {
                    resolve(jsonString ? JSON.parse(jsonString) : null)
                } catch (err) {
                    resolve(false)
                }
            });

        })
    }
}
