import fs from 'fs';
import path from 'path';
import { concatTransformationMatrix, ImageAlignment, PDFButton, PDFDocument, PDFHexString, PDFName, PDFString, PDFTextField, popGraphicsState, pushGraphicsState, StandardFonts } from 'pdf-lib';
import fontKit from '@btielen/pdf-lib-fontkit';
import _ from 'lodash';
import { WorkerInputParam } from '../app.interface';
import { AppConfig } from '../environments/environment';

const METADATA_PROPS = ['llx', 'lly', 'urx', 'ury'];

const loadPdfTemplate = async (
    formPdfBytes,
    addWaterMark,
    // waterMarkText = 'SAMPLE'
    waterMarkText = ''
) => {
    const pdfDoc = await PDFDocument.load(formPdfBytes);

    const totalPages = pdfDoc.getPageCount();

    // Adds watermark to all the pages
    if (addWaterMark) {
        for (let i = 0; i < totalPages; i++) {
            const page = pdfDoc.getPage(i);

            // Code to add watermark
            const helveticaFont = await pdfDoc.embedFont(
                StandardFonts.Helvetica
            );
            const text = waterMarkText;
            const textSize = 140;
            const rotation = 45;
            const textWidth = helveticaFont.widthOfTextAtSize(text, textSize);
            const textHeight = helveticaFont.heightAtSize(textSize);

            let originX = page.getWidth() / 2;
            let originY = page.getHeight() / 2;
            let angle = rotation * (Math.PI / 180);

            page.pushOperators(
                pushGraphicsState(),
                concatTransformationMatrix(1, 0, 0, 1, originX, originY),
                concatTransformationMatrix(
                    Math.cos(angle),
                    Math.sin(angle),
                    -Math.sin(angle),
                    Math.cos(angle),
                    0,
                    0
                ),

                concatTransformationMatrix(
                    1,
                    0,
                    0,
                    1,
                    -1 * originX,
                    -1 * originY
                )
            );

            page.drawText(text, {
                x: originX - textWidth / 2,
                y: originY - textHeight / 2,
                size: textSize,
                font: helveticaFont,
                opacity: 0.25,
            });

            page.pushOperators(popGraphicsState());
        }
    }
    return pdfDoc;
};

const fillForm = async (pdfDoc: PDFDocument, record: any, fontBytes: ArrayBuffer, pdfGenerationFormData: any, rollNoMappedField: string) => {
    pdfDoc.registerFontkit(fontKit);

    const form = pdfDoc.getForm();
    const fields = form.getFields();

    const embeddedFont = await pdfDoc.embedFont(StandardFonts.HelveticaBold);

    const imageFolderPath = pdfGenerationFormData.imagePath;

    for (let i = 0; i < fields.length; i++) {
        const fieldName = fields[i].getName();
        // if field is an image form field then we will embed the png in pdf document and then set it to button image widget
        if (fields[i] instanceof PDFButton) {
            const imageFieldName = fieldName;
            const rollNo = record[rollNoMappedField]
            const imagePath = path.join(imageFolderPath, rollNo + '.jpg');

            if (fs.existsSync(imagePath)) {
                try {
                    const buf = await fs.promises.readFile(imagePath);
                    const img = await pdfDoc.embedJpg(buf);
                    const buttonImage = form.getButton(imageFieldName);
                    buttonImage.setImage(img, ImageAlignment.Center);
                } catch (err) {
                    console.log(err);
                }
            } else {
                console.log('Image at ', imagePath , ' not found');
            }
        } else if (fields[i] instanceof PDFTextField) {
            const textFieldName = fieldName;
            if(textFieldName =="enrn" && (record[textFieldName]==null || record[textFieldName]=="")){
                record[textFieldName]=" ";
            }
            if (record[textFieldName]) {
                form.getTextField(textFieldName).setText(record[textFieldName]);
            }
        }
    }

    form.updateFieldAppearances(embeddedFont);
    form.flatten();

    // Here we are generating a copy of original documents which does not contain the attribute causing SRI issue 1146
    const pdfCopy = await pdfDoc.copy();

    // Read from template and Set coordinates metadata to generated PDFs
    METADATA_PROPS.forEach(prop => {
        const val: PDFString = pdfDoc['getInfoDict']().lookup(PDFName.of(prop));
        if (val) pdfCopy['getInfoDict']().set(PDFName.of(prop), PDFHexString.fromText(val.asString()));
    })
    const savedPdfBytes = await pdfCopy.save();
    return savedPdfBytes;
};

module.exports = async (contents: WorkerInputParam) => {
    // const pdfDoc = await loadPdfTemplate(contents.pdfTemplateBuffer, !AppConfig.production);
    const pdfDoc = await loadPdfTemplate(contents.pdfTemplateBuffer, false);

    const pdfBytes = await fillForm(
        pdfDoc,
        contents.record,
        contents.fontBuffer,
        contents.formData,
        contents.rollNoMappedField
    );
    try {
        fs.writeFileSync(contents.pdfFilePath, pdfBytes);
    } catch (err) {
        console.log(err);
    }

    return true;
};
