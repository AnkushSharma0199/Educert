import { app, BrowserWindow, ipcMain, screen, shell, powerSaveBlocker } from 'electron';
import { dialog } from 'electron';
import * as path from 'path';
import * as fs from 'fs';
import { autoUpdater } from "electron-updater"
import * as logger from 'electron-log'
import { minify } from 'jsonminify'
import { JsonStorageService } from './services/jsonStorage.service';
import { LoggerSetupService } from './services/logger-setup.service';
import { CsvWriterService } from './services/csvWriter.service';
import { WorkerService } from './services/worker.service';
import fieldMappings from './field-mapping/mapping.json';

// This is to ensure that one instance of app can run at a time
const gotTheLock = app.requestSingleInstanceLock()

// This service monkey patch electron-logger functions to change message text which it logs
const logSetupService: LoggerSetupService | null = new LoggerSetupService();

// This will catch all the unhandled error messages in the main process
logger.catchErrors({
    showDialog: false, // We are currently not showing any dialog box to user
    onError(error, versions, submitIssue) {
        logger.error(error);
    }
});

// Tells autoUpdates to log its messages through electron-log
autoUpdater.logger = logger;

let win: BrowserWindow = null;
const args = process.argv.slice(1),
    serve = args.some(val => val === '--serve');

function createWindow(): BrowserWindow {

    const size = screen.getPrimaryDisplay().workAreaSize;

    // Create the browser window.
    win = new BrowserWindow({
        x: 0,
        y: 0,
        width: size.width,
        height: size.height,
        minWidth: 1366,
        minHeight: 768,
        webPreferences: {
            nodeIntegration: true,
            allowRunningInsecureContent: (serve),
            contextIsolation: false,  // false if you want to run e2e test with Spectron
        },
    });

    // @electron/remote/main must be initialized in the main process before it can be used from the renderer
    const remote = require('@electron/remote/main');
    remote.initialize();
    remote.enable(win.webContents);

    if (serve) {
        const debug = require('electron-debug');
        debug();

        require('electron-reloader')(module);
        win.loadURL('http://localhost:4500');
    } else {
        // Hide menu bar when not in dev mode
        win.removeMenu();

        // Path when running electron executable
        let pathIndex = './index.html';

        if (fs.existsSync(path.join(__dirname, '../dist/index.html'))) {
            // Path when running electron in local folder
            pathIndex = '../dist/index.html';
        }

        const url = new URL(path.join('file:', __dirname, pathIndex));
        win.loadURL(url.href);
    }

    // Prevent system sleep
    const powerSaveBlockerId = powerSaveBlocker.start('prevent-app-suspension');

    // Emitted when the window is closed.
    win.on('closed', () => {
        // Dereference the window object, usually you would store window
        // in an array if your app supports multi windows, this is the time
        // when you should delete the corresponding element.
        powerSaveBlocker.stop(powerSaveBlockerId);
        win = null;
    });
    autoUpdater.checkForUpdatesAndNotify();

    const jsonStorageService = new JsonStorageService();
    const outputCsvWriter = new CsvWriterService();
    const reportCsvWriter = new CsvWriterService();
    const workerService = new WorkerService();

    ipcMain.handle('set-json-data', (e, data) => {
        jsonStorageService.setFieldMapping(data)
    })

    ipcMain.handle('get-json-data', async (e) => {
        const data = await jsonStorageService.getFieldMapping();
        return data;
    })

    ipcMain.handle('open-dialog', (e, option) => {
        const filesPath = dialog.showOpenDialog(win, option)
        return filesPath
    })

    ipcMain.handle('open-folder', async (e, outputFolderPath) => {
        await shell.openPath(path.normalize(outputFolderPath));
    })

    ipcMain.handle('set-csv-writer', (e, dataObj) => {
        outputCsvWriter.setCsvCreatorObject(dataObj)
    })

    ipcMain.handle('set-csv-record', async (e, record) => {
        outputCsvWriter.csvWriteRecord(record)
    })

    ipcMain.handle('set-report-csv-writer', (e, dataObj) => {
        reportCsvWriter.setCsvCreatorObject(dataObj)
    })

    ipcMain.handle('set-report-csv-record', async (e, record) => {
        reportCsvWriter.csvWriteRecord(record)
    })

    ipcMain.handle('run-worker-service', async (e, content) => {
        const res = await workerService.processWorkerPool(content)
        return res
    })

    // copy config file from assets on first load
    if (true) {
        minify; // just calling it to load lib file
        const minified = JSON['minify'](JSON.stringify(fieldMappings));
        jsonStorageService.setFieldMapping(minified);
    }

    return win;
}

autoUpdater.on('update-downloaded', (ev, info) => {
    logger.info(info);
    autoUpdater.autoInstallOnAppQuit = true;
});

try {
    if (!gotTheLock) {
        app.quit()
    } else {
        app.on('second-instance', (event, commandLine, workingDirectory) => {
            // Someone tried to run a second instance, we should focus our window.
            if (win) {
                if (win.isMinimized()) win.restore()
                win.focus()
            }
        })

        // This method will be called when Electron has finished
        // initialization and is ready to create browser windows.
        // Some APIs can only be used after this event occurs.
        // Added 400 ms to fix the black background issue while using transparent window. More detais at https://github.com/electron/electron/issues/15947
        app.on('ready', () => setTimeout(createWindow, 400));

        // Quit when all windows are closed.
        app.on('window-all-closed', () => {
            // On OS X it is common for applications and their menu bar
            // to stay active until the user quits explicitly with Cmd + Q
            if (process.platform !== 'darwin') {
                app.quit();
            }
        });

        app.on('activate', () => {
            // On OS X it's common to re-create a window in the app when the
            // dock icon is clicked and there are no other windows open.
            if (win === null) {
                createWindow();
            }
        });
    }

} catch (e) {
    // Catch Error
    // throw e;
}
