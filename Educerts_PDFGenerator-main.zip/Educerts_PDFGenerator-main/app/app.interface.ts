export class LogMessage {
    public Message: any[];
    public BuildNo: string;
    public Environment: string;
    public IpAddress: string;
    public OSType: string;
    public OSRelease: string;
    public HostName: string;
    public OrganizationId: string;
    public OrganizationName: string;
    public UserId: string;
    public UserName: string;
    public Timestamp: string;
}

export interface WorkerInputParam {
    pdfTemplateBuffer: Buffer;
    formData: any;
    fontBuffer: Buffer;
    record: any;
    pdfFilePath: string;
    rollNoMappedField: string;
}
