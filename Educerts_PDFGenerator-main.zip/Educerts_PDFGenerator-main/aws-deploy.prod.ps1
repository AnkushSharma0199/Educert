Write-Host -ForegroundColor Yellow "`nProd - Deploying App to S3"

#upload file
aws s3 cp ./release s3://docker-v2-prod-pdfgenerator --recursive --acl public-read --profile Docker
write-host -ForegroundColor Yellow "`nProd - App successfully uploaded"

Read-Host -Prompt "`nPress Enter to exit"
