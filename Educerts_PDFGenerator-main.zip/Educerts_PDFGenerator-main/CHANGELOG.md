## Release Notes 02/02/2024
* Renamed package to append 2023
* Updated center code mappings for 2023
* Updated school code mappings for 2023
* Updated subject code min max marks
* Add new subject codes
* Added 10th 2023 mapping
* Bumped package.json version to `23.44.0`
* Bunped electron prod environment version to `2.2232.0`
* Bumped electron & angular qa, dev, web & local environment version to `2.2344.0`
* Bumped angular prod version to `2.2344.0`
* (WIP) Enrollment number missing would result in corrupted pdf, unable to open using pdf reader, fonts missing when embedding the pdf. 


## Release Notes 05/02/2024
* Added 12th 2023 mapping
* Bumped package.json version to `23.45.0`
* Bunped electron prod environment version to `2.2233.0`
* Bumped electron & angular qa, dev, web & local environment version to `2.2345.0`
* Bumped angular prod version to `2.2345.0`
* (WIP) Enrollment number missing would result in corrupted pdf, unable to open using pdf reader, fonts missing when embedding the pdf. 

## Release Notes 09/02/2024
* Disabled watermark on prod manually (To revisit)

## Release Notes 14/02/2024
* Accomodated changes for additional private regular field values, since it's skipping a few documents in pdf generator