import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SharedModule } from '../shared/shared.module';
import { MatInputModule } from '@angular/material/input';
import { ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSelectModule } from '@angular/material/select';
import { MatIconModule } from '@angular/material/icon';
import { MatChipsModule } from '@angular/material/chips';
import { NgxMatSelectSearchModule } from 'ngx-mat-select-search';
import { GeneratePdfComponent } from './generate-pdf.component';

@NgModule({
    declarations: [GeneratePdfComponent],
    imports: [CommonModule, SharedModule, MatInputModule, ReactiveFormsModule, MatButtonModule, MatCardModule,
        MatProgressSpinnerModule, MatSelectModule, MatIconModule, MatChipsModule, NgxMatSelectSearchModule]
})

export class GeneratePdfModule { }
