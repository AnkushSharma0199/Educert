import { ChangeDetectorRef, Component, OnDestroy, OnInit } from '@angular/core';
import { UntypedFormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { PdfGenerationStatusEnum } from 'app/app.enum';
import { ElectronService } from 'app/core/services';
import { LoggerHelperService } from 'app/service/logger-helper.service';
import { PdfHandlerService } from 'app/service/pdf-handler.service';
import { Subscription } from 'rxjs';

@Component({
    selector: 'app-generate-pdf',
    templateUrl: './generate-pdf.component.html',
    styleUrls: ['./generate-pdf.component.scss']
})
export class GeneratePdfComponent implements OnInit, OnDestroy {
    isFieldMappingError = false;
    isPdfGenerationInProgress = false;
    isValidationError = false;
    validationError = 'Data Validation ';
    pdfGenerationStatus = null;
    pdfGenerationStatusSubscription: Subscription = null;

    constructor(
        private router: Router,
        private fb: UntypedFormBuilder,
        private electronService: ElectronService,
        private pdfHandlerService: PdfHandlerService,
        private cd: ChangeDetectorRef,
        private translateService: TranslateService,
        private loggerHelperService: LoggerHelperService
    ) { }

    ngOnInit(): void {
        this.pdfGenerationStatusSubscription =
            this.pdfHandlerService.pdfGenerationStatus.subscribe((status) => {
                this.isPdfGenerationInProgress =
                    status.state === PdfGenerationStatusEnum.InProgress;
                if (this.isPdfGenerationInProgress) {
                    // this.pdfGeneratorForm.disable();
                } else {
                    // this.pdfGeneratorForm.enable();
                }
                this.pdfGenerationStatus = status;
                this.cd.detectChanges();
            });

        // this.pdfHandlerService.isFieldMappingError.subscribe((isError) => {
        //     this.isFieldMappingError = isError;
        // });
    }

    ngOnDestroy(): void {
        this.pdfGenerationStatusSubscription?.unsubscribe();
    }

    async pdfGenerationFormSubmit() {
        // if (this.getAccessTables().length === 0) {
        //     // This is required when CSV is selected instead of MDB
        //     this.clearFieldValidation('accessDBTable');
        // }

        if (this.pdfHandlerService.checkIfConfigRelevant()) {
            const validationCliPath = this.pdfHandlerService.getPdfGenerationFormData().validationCliPath;
            const publicCertDir = this.pdfHandlerService.getPdfGenerationFormData().publicCertDir;
            const dbPath = this.pdfHandlerService.getPdfGenerationFormData().csvFile.path;
            const tableName = this.pdfHandlerService.getPdfGenerationFormData().accessDBTable;

            this.pdfHandlerService.pdfGenerationStatus.next({
                state: PdfGenerationStatusEnum.InProgress,
                totalDocs: '',
                currentDocs: '',
            });

            const cliInputParams = `${validationCliPath} -d "${dbPath}" -k "${publicCertDir}" -t "${tableName}"`;

            try {
                this.isValidationError = false;
                this.validationError = 'Data Validation ';
                const cliCallResult = this.electronService.childProcess.execSync(cliInputParams, {
                    encoding: 'utf-8'
                });
                this.loggerHelperService.logInfo(cliCallResult);
                await this.pdfHandlerService.generatePdf();
            } catch (err) {
                this.isValidationError = true;
                this.validationError += err.stderr;
                this.loggerHelperService.logError(this.validationError);

                this.pdfHandlerService.pdfGenerationStatus.next({
                    state: PdfGenerationStatusEnum.Errored,
                    totalDocs: '',
                    currentDocs: '',
                });
            }
        }
    }

    resetForm() {
        // formDirective.resetForm();
        // this.formInit();
        // this.setFromData();
        // here we are also clearing data from the PdfHandlerService
        this.pdfHandlerService.resetStoredData();
    }

}
