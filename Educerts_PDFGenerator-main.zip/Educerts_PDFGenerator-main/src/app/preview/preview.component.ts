import { Component, OnInit, ViewChild } from '@angular/core';
import { NgxExtendedPdfViewerComponent, pdfDefaultOptions, NgxExtendedPdfViewerService } from 'ngx-extended-pdf-viewer';
import * as _ from 'lodash';
import { PdfHandlerService } from 'app/service/pdf-handler.service';

@Component({
    selector: 'app-preview',
    templateUrl: './preview.component.html',
    styleUrls: ['./preview.component.scss']
})
export class PreviewComponent {
    @ViewChild("ngxPdfViewer") ngxPdfViewer: NgxExtendedPdfViewerComponent;
    totalCsvRecordsCount = null;
    generatedPdfData = null;
    loading = false;
    currentDocIndex = 0;
    errorInPdf = '';
    isReadyForPreview = false;
    constructor(private pdfHandlerService: PdfHandlerService) { }

    async ngAfterViewInit() {
        this.isReadyForPreview = this.pdfHandlerService.isReadyForPreview;

        if (this.isReadyForPreview) {
            this.totalCsvRecordsCount = this.pdfHandlerService.getTotalCsvRecordsCount;
            this.loadPdfPreview(0); // always load first PDF page
        }
    }

    previousDoc() {
        if (this.currentDocIndex !== 0) {
            this.currentDocIndex = this.currentDocIndex - 1
            this.loadPdfPreview(this.currentDocIndex);
        }
    }

    nextDoc() {
        if (this.currentDocIndex !== this.totalCsvRecordsCount - 1) {
            this.currentDocIndex = this.currentDocIndex + 1;
            this.loadPdfPreview(this.currentDocIndex);
        }
    }

    async loadPdfPreview(pageNo: number) {
        try {
            this.errorInPdf = ''
            this.loading = true;
            // const generatedPdfData = await this.pdfHandlerService.generatePdfPreview(pageNo);
            // this.generatedPdfData = generatedPdfData;
            this.loading = false;
        } catch(err) {
            if (err.message === 'regularPrivateFieldError') {
                this.errorInPdf = err.message;
                this.loading = false
            }
            console.log(err)
        }
    }
}
