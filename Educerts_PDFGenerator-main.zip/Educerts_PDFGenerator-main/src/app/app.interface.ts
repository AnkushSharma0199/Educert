import { AppType, CertificationLevelEnum, DocFlowUserStatusEnum, FieldTypeEnum, StatusEnum, UserRole } from "./app.enum";

export class PdfFormData {
    csvFile: {
        name: string;
        path: string;
        type: string;
    };
    accessDBTable: string;
    classField: string;
    examType: string;
    pdfTemplateFile: PdfTemplateFileData;
    privateRegularField: string;
    validationCliPath: string;
    publicCertDir: string;
    fontFile: {
        name: string;
        path: string;
        type: string;
    };
    outputPath: string;
    imagePath: string;
}

export class PdfTemplateFileData {
        name: string;
        path: string;
        type: string;
}

export interface WorkerInputParam {
    pdfTemplateBuffer: Buffer;
    formData: any;
    fontBuffer: Buffer;
    record: any;
    pdfFilePath: string;
    rollNoMappedField: string;
}


export interface ConfigFileFieldEntry {
    id: string;
    label: string;
    outputCsvHeader: string;
    mappedField: string;
    defaultValue: string;
    isDbSpecificField: boolean;
    isRequiredField: boolean;
    isReadonlyField: boolean;
    isEditableByUser: boolean;
    canHaveDefaultValue: boolean;
    showInOutputCSV: boolean;
    showInReportCSV: boolean;
}

export interface ConfigFileEntry {
    name: string;
    description: string;
    year: number[];
    mainFields: ConfigFileFieldEntry[];
    customFields: ConfigFileFieldEntry[];
    pdfTemplateMappingFields: { [key: string]: any };
    subjectCodes: { [key: string]: any };
    schoolCodeMasterFile: string;
    supplementarySubjects?: [];
}

export interface ConfigFile {
    [key: string]: ConfigFileEntry;
}

export class SignInRequest {
    email?: string;
    password?: string;
    appId: number;
    appType?: AppType;
    appVersion?: string;
}

export class UserData {
    id?: string;
    accountId?: string;
    firstName?: string;
    middleName?: string;
    lastName?: string;
    email?: string;
    accessToken?: string;
    firstPasswordChanges?: boolean;
    role?: UserRole;
    dateOfBirth?: Date;
    mobile?: string;
    aadhaarNumber?: string;
    isEmailVerified?: boolean;
    passwordSecurityCode?: string;
    account?: AccountData;
    usbToken?: any;
    tokenList?: any[];
    certificationLevel?: CertificationLevelEnum;

    // client side property
    fullName?: string;
}

export class AccountData {
    address?: Address;
    organizationName?: string;
    logo?: string;
    salesPartner?: UserData;
    status?: StatusEnum;
    settings?: AccountSettingResponseDto;
}

export class Address {
    public address1: string;
    public address2: string;
    public address3: string;
    public stateId?: string;
    public state: State;
    public city: string;
    public country: string;
    public postalCode: string;
}

export class State {
    code?: string;
    name?: string;
    id?: string;
    welcomeImage?: string;
    logo?: string;
}

export class AccountSettingResponseDto {
    accountId?: string;
    supportedFields?: FieldTypeDto[];
    supportedDocumentTypes?: DocTypeDto[];
    supportedAcademicYears?: SupportedAcademicYearsDto;
    rejectionReasons?: string[];
    docFlow?: ResponseDocFlowType[];
}

export class FieldTypeDto {
    name: string;
    displayName: string;
    type: FieldTypeEnum;
    fieldValue?: string;
    isReadonly: boolean;
    isVisible: boolean;
    isRequired: boolean;
    isVisiblePublic: boolean;
}

export class DocTypeDto {
    code: string;
    name: string;
    docSubTypes?: {
        code: string;
        name: string;
    }[];
}

export class ResponseDocFlowType {
    public docTypeId?: string;
    public level?: number;
    public userId?: string;
    public roleId?: number;
    public status?: DocFlowUserStatusEnum;
}

export class SupportedAcademicYearsDto {
    public uploading?: number[];
    public signing?: number[];
    public generation?: number[];
}