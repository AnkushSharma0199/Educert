import { Component, OnInit, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { FormControl, FormGroup, UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import * as _ from 'lodash';
import { ElectronService } from 'app/core/services';
import { PdfHandlerService } from 'app/service/pdf-handler.service';
import { TranslateService } from '@ngx-translate/core';
import { SessionStoreService } from 'app/service/session-store.service';

@Component({
    selector: 'app-home',
    templateUrl: './home.component.html',
    styleUrls: ['./home.component.scss'],
})
export class HomeComponent implements OnInit {
    pdfGeneratorForm: UntypedFormGroup = null;
    isPdfGenerationInProgress = false;
    lodash = _; // This is to expose _ to html template
    constructor(
        private router: Router,
        private fb: UntypedFormBuilder,
        private electronService: ElectronService,
        private pdfHandlerService: PdfHandlerService,
        private translateService: TranslateService,
        private sessionStoreService: SessionStoreService,
    ) {
        this.formInit();
    }

    private configYears = [2018, 2019, 2020, 2021, 2022, 2023];

    formInit() {
        this.pdfGeneratorForm = this.fb.group({
            csvFile: new FormGroup({
                name: new FormControl('', Validators.required),
                path: new FormControl('', Validators.required),
                type: new FormControl(''),
            }),
            accessDBTable: new FormControl('', Validators.required),
            // classField: new FormControl('', Validators.required),
            // examType: new FormControl('', Validators.required),
            pdfTemplateFile: new FormGroup({
                name: new FormControl('', Validators.required),
                path: new FormControl('', Validators.required),
                type: new FormControl(''),
            }),
            fontFile: new FormGroup({
                name: new FormControl('', Validators.required),
                path: new FormControl('', Validators.required),
                type: new FormControl(''),
            }),
            outputPath: new FormControl('', Validators.required),
            imagePath: new FormControl(''),

            filterOptions: new FormControl(''),
            validationCliPath: new FormControl('', Validators.required),
            publicCertDir: new FormControl('', Validators.required),
            configYear: new FormControl('', Validators.required),
        });
    }

    ngOnInit(): void {
        const formData = this.pdfHandlerService.getPdfGenerationFormData();
        if (formData) {
            this.pdfGeneratorForm.patchValue(formData);
        }
    }

    async inputCSVSelected(e) {
        // reset these controls as they are dependent on the selected CSV
        this.pdfGeneratorForm.controls['accessDBTable'].patchValue('');

        const file = e.target.files[0];
        this.pdfGeneratorForm.controls['csvFile'].setErrors(null);
        const data = {
            name: file.name,
            path: file.path,
            type: file.type || '',
        };
        this.f.csvFile.setValue(data);
        await this.pdfHandlerService.setImportedCsvOrAccessDbFile(data.path, data.type);
        this.setFromData();
        e.target.value = '';

        // make accessDBtable field required or optional based on CSV Form Field
        if (this.getAccessTables().length > 0) {
            this.pdfGeneratorForm
                .get('accessDBTable')
                .setValidators(Validators.required);
        } else {
            this.pdfGeneratorForm.get('accessDBTable').setErrors(null);
            this.pdfGeneratorForm.get('accessDBTable').clearValidators();
        }
    }

    getCsvColumns(): string[] {
        return this.pdfHandlerService.getDbColumns();
    }

    async selectedAccessTable(e) {
        this.setFromData();
        await this.pdfHandlerService.setAccessDbTableData(e.value);
    }

    async selectedConfigYear(e) {
        this.setFromData();
        await this.pdfHandlerService.setConfigMappingYear(e.value);
    }

    pdfTemplateSelected(e) {
        const file = e.target.files[0];
        if (file.type === 'application/pdf') {
            const data = {
                name: file.name,
                path: file.path,
                type: file.type || ''
            }
            this.pdfGeneratorForm.controls['pdfTemplateFile'].setErrors(null);
            this.f.pdfTemplateFile.patchValue(data)
            this.setFromData();
        } else {
            this.pdfGeneratorForm.get('pdfTemplateFile.name').setErrors({ notPdfFile: true })
        }
        e.target.value = '';
    }

    fontFileSelected(e) {
        const file = e.target.files[0];
        const data = {
            name: file.name,
            path: file.path,
            type: file.type || '',
        };
        this.f.fontFile.patchValue(data);
        this.setFromData();
        e.target.value = '';
    }

    selectValidationCli(e) {
        const file = e.target.files[0];
        this.f.validationCliPath.patchValue(file.path);
        this.setFromData();
        e.target.value = '';
    }

    async selectCertsFolder() {
        const options = {
            title: '',
            buttonLabel: '',
            properties: ['openDirectory'],
        };
        this.translateService
            .get(['label.selectPublicKeyDirectory', 'label.selectDirectory'])
            .subscribe((translations: string) => {
                options.title = translations['label.selectPublicKeyDirectory'];
                options.buttonLabel = translations['label.selectDirectory'];
            });

        const result = await this.electronService.ipcRenderer.invoke(
            'open-dialog',
            options
        );

        if (!result.canceled) {
            this.f.publicCertDir.patchValue(result.filePaths[0]);
            this.setFromData();
        }
    }

    async selectOutputFolder() {
        const options = {
            title: '',
            buttonLabel: '',
            properties: ['openDirectory'],
        };
        this.translateService
            .get(['label.selectOutputDirectory', 'label.selectDirectory'])
            .subscribe((translations: string) => {
                options.title = translations['label.selectOutputDirectory'];
                options.buttonLabel = translations['label.selectDirectory'];
            });

        const result = await this.electronService.ipcRenderer.invoke(
            'open-dialog',
            options
        );

        if (!result.canceled) {
            this.f.outputPath.patchValue(result.filePaths[0]);
            this.setFromData();
        }
    }

    async selectImageFolder() {
        const options = {
            title: '',
            buttonLabel: '',
            properties: ['openDirectory'],
        };
        this.translateService
            .get(['label.selectOutputDirectory', 'label.selectDirectory'])
            .subscribe((translations: string) => {
                options.title = translations['label.selectOutputDirectory'];
                options.buttonLabel = translations['label.selectDirectory'];
            });

        const result = await this.electronService.ipcRenderer.invoke(
            'open-dialog',
            options
        );

        if (!result.canceled) {
            this.f.imagePath.patchValue(result.filePaths[0]);
            this.setFromData();
        }
    }

    getAccessTables() {
        return this.pdfHandlerService.getAccessDbTables();
    }

    getConfigYears() {
        //return this.configYears;
        return this.sessionStoreService.getAccountData()?.settings?.supportedAcademicYears.generation;
    }

   

    // handles blur event for DocType and DocSubType
    setFromData() {
        this.pdfHandlerService.setPdfGenerationFormData(
            this.pdfGeneratorForm.value
        );
    }

    clearFieldValidation(field) {
        this.f[field].setErrors(null);
        this.f[field].clearValidators()
    }

    next() {
        this.pdfGeneratorForm.markAllAsTouched();
        this.pdfGeneratorForm.markAsDirty();
        if (this.pdfGeneratorForm.valid) {
            this.router.navigate(['/app-frame/fields-mapping']);
        }
    }

    get f() {
        return this.pdfGeneratorForm.controls;
    }
}
