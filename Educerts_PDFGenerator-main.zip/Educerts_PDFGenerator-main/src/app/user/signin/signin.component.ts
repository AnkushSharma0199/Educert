/* eslint-disable @typescript-eslint/unbound-method */
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { SessionStoreService } from 'app/service/session-store.service';

import { AppConfig } from "environments/environment";
import { MatDialog } from '@angular/material/dialog';
// import { ForgotPasswordComponent } from '../forgot-password/forgot-password.component'
// import { AppType } from 'app/app.enum';
// import { SignInRequest } from 'app/app.interface';
// import { AccountService } from 'app/service/account.service';
// import { InitService } from 'app/service/init.service';
// import { UsbTokenService } from 'app/service/usbToken.service';
import { NotificationService } from 'app/service/notification.service';
import { ElectronService } from 'app/core/services';
import { UserService } from 'app/service/user.service';
import { AppType } from 'app/app.enum';
import { SignInRequest } from 'app/app.interface';
import { AccountService } from 'app/service/account.service';
// import { StatusBarService } from 'app/service/statusbar.service';

@Component({
    selector: 'app-signin',
    templateUrl: './signin.component.html',
    styleUrls: ['./signin.component.scss']
})
export class SigninComponent implements OnInit {
    loading = false;
    loggedIn = false;
    submitted = false;
    showError = false;
    passwordHidden = true;
    showInternalServerError = false;
    buildVersion: string;
    supportEmail: string;
    copyrightMsg: string;

    loginForm = new FormGroup({
        username: new FormControl('', Validators.required),
        password: new FormControl('', Validators.required),
    });

    constructor(
        private router: Router,
        private userService: UserService,
        private accountService: AccountService,
        private matDialog: MatDialog,
        private sessionStoreService: SessionStoreService,
        private notificationService: NotificationService,
    ) { }

    async ngOnInit(): Promise<void> {
        // await this.getInitConfig();
    }

    // eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
    async signin(): Promise<void> {
        const value: SignInRequest = {
            email: this.loginForm.get('username').value,
            password: this.loginForm.get('password').value,
            appType: AppType.RegUser,
            appId: 2,
            appVersion: AppConfig.appVersion
        }
        try {
            this.showError = false;
            this.showInternalServerError = false;
            this.loading = true;

            const res = await this.userService.signin(value);
            if (res) {
                this.sessionStoreService.setUserData(res);

                const accountRes = await this.accountService.getAccountById(res.accountId);
                this.sessionStoreService.setAccountData(accountRes);

                // for now, we are not considering "res.firstPasswordChanges"
                this.router.navigate(['app-frame/home'])
            } else {
                this.showError = true;
            }
        } catch (err) {
            this.notificationService.errorToastNotification(err.error.message)
        } finally {
            this.loading = false;
        }
    }

    // async getInitConfig(): Promise<void> {
    //     await this.initService.getInitConfig().then((config) => {
    //         this.sessionStoreService.setInitConfig(config);
    //         this.supportEmail = config?.email;

    //         this.buildVersion = AppConfig.appVersion;
    //         this.copyrightMsg = config?.copyrightMsg;
    //     })
    // }

    // convenience getter for easy access to form fields
    get f() { return this.loginForm.controls; }

    // public openForgotPasswordDialog(): void {
    //     this.matDialog.open(ForgotPasswordComponent, {
    //         panelClass: 'forgot-password-dialog',
    //     });
    // }
}
