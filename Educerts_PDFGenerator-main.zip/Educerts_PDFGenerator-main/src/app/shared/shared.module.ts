import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TranslateModule } from '@ngx-translate/core';

import { WebviewDirective } from './directives/';
import { FormsModule } from '@angular/forms';
import { LoadingSpinnerComponent } from './loading-spinner/loading-spinner.component';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';

@NgModule({
    declarations: [WebviewDirective, LoadingSpinnerComponent],
    imports: [CommonModule, TranslateModule, FormsModule, MatIconModule, MatProgressSpinnerModule],
    exports: [TranslateModule, WebviewDirective, FormsModule, LoadingSpinnerComponent]
})
export class SharedModule { }
