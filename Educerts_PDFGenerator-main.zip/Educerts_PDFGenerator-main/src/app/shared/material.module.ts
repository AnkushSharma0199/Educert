import { NgModule } from '@angular/core';
import { MatTabsModule } from '@angular/material/tabs';
import { MatStepperModule } from '@angular/material/stepper';
import { MatButtonModule } from '@angular/material/button';
import { MatRippleModule } from '@angular/material/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatDialogModule } from '@angular/material/dialog';
import { MatToolbarModule } from '@angular/material/toolbar'
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon'
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatMenuModule } from '@angular/material/menu';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSortModule } from '@angular/material/sort';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatRadioModule } from '@angular/material/radio';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatListModule } from '@angular/material/list';

@NgModule({
    imports: [
        MatRippleModule, MatFormFieldModule, MatTooltipModule, MatCheckboxModule, MatToolbarModule, MatCardModule, MatDatepickerModule, MatExpansionModule, MatPaginatorModule, MatSortModule, MatButtonModule, MatNativeDateModule,
        MatIconModule, MatInputModule, MatTableModule, MatTabsModule, MatMenuModule, MatSnackBarModule, MatDialogModule, MatStepperModule, MatProgressSpinnerModule, MatSelectModule, MatRadioModule, MatSidenavModule, MatListModule],
    exports: [MatButtonModule, MatIconModule, MatInputModule, MatTableModule, MatTabsModule, MatMenuModule, MatSnackBarModule, MatDialogModule, MatStepperModule, MatProgressSpinnerModule, MatSelectModule,
        MatRippleModule, MatFormFieldModule, MatTooltipModule, MatCheckboxModule, MatToolbarModule, MatCardModule, MatDatepickerModule, MatExpansionModule, MatPaginatorModule, MatSortModule, MatNativeDateModule, MatRadioModule, MatSidenavModule, MatListModule]
})
export class MaterialModule { }
