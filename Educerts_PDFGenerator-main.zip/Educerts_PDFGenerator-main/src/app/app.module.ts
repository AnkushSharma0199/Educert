import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule, HttpClient, HTTP_INTERCEPTORS } from '@angular/common/http';
import { CoreModule } from './core/core.module';
import { SharedModule } from './shared/shared.module';
import {MatInputModule} from '@angular/material/input'

import { AppRoutingModule } from './app-routing.module';

// NG Translate
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';

import { HomeModule } from './home/home.module';
import { PreviewModule } from './preview/preview.module';
import { GeneratePdfModule } from './generate-pdf/generate-pdf.module';

import { AppComponent } from './app.component';
import { AppFrameModule } from './app-frame/app-frame.module';
import { FieldsMappingModule } from './fields-mapping/fields-mapping.module';
import { MatFormFieldModule } from '@angular/material/form-field';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ReactiveFormsModule } from '@angular/forms';
import { LoadingSpinnerComponent } from './shared/loading-spinner/loading-spinner.component';
import { NgxExtendedPdfViewerModule } from 'ngx-extended-pdf-viewer'
import { CommonModule } from '@angular/common';
import { SigninComponent } from './user/signin/signin.component';
import { HttpInterceptorService } from './core/http-interceptor.service';
// AoT requires an exported function for factories
const httpLoaderFactory = (http: HttpClient): TranslateHttpLoader => new TranslateHttpLoader(http, './assets/i18n/', '.json');

@NgModule({
    declarations: [AppComponent, SigninComponent],
    imports: [
        BrowserModule,
        FormsModule,
        CommonModule,
        BrowserAnimationsModule,
        HttpClientModule,
        MatInputModule,
        FieldsMappingModule,
        PreviewModule,
        FormsModule,
        MatFormFieldModule,
        ReactiveFormsModule,
        CoreModule,
        SharedModule,
        AppFrameModule,
        HomeModule,
        AppRoutingModule,
        GeneratePdfModule,
        TranslateModule.forRoot({
            loader: {
                provide: TranslateLoader,
                useFactory: httpLoaderFactory,
                deps: [HttpClient]
            }
        }),
        NgxExtendedPdfViewerModule
    ],
    exports: [MatInputModule],
    providers: [{
        provide: HTTP_INTERCEPTORS,
        useClass: HttpInterceptorService,
        multi: true,
    },],
    bootstrap: [AppComponent]
})
export class AppModule { }
