import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { from, Observable } from 'rxjs';
import * as publicIp from 'public-ip'
import { SessionStoreService } from '../service/session-store.service';

@Injectable({
    providedIn: 'root',
})
export class HttpInterceptorService implements HttpInterceptor {
    constructor(private sessionStorageService: SessionStoreService) { }

    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        // convert promise to observable using 'from' operator
        return from(this.handle(req, next))
    }

    async handle(req: HttpRequest<any>, next: HttpHandler): Promise<HttpEvent<any>> {
        let headers = req.headers

        // getting current public IP
        const ipAddress = await publicIp.v4();
        headers = headers.set('Public-Ip', ipAddress);

        // Get the user data from the service.
        const authData = this.sessionStorageService.getUserData();
        if (authData && authData.id) {
            headers = headers.set('Authorization', 'Bearer ' + authData.accessToken);
        }

        return next.handle(req.clone({ headers })).toPromise();
    }
}
