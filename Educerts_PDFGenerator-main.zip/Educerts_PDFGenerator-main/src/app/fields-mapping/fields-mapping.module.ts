import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SharedModule } from '../shared/shared.module';
import { FieldsMappingComponent } from './fields-mapping.component';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { ReactiveFormsModule } from '@angular/forms';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { NgxMatSelectSearchModule } from 'ngx-mat-select-search';
import { MatCardModule } from '@angular/material/card';
import { MatGridListModule } from '@angular/material/grid-list';

@NgModule({
    declarations: [FieldsMappingComponent],
    imports: [CommonModule, MatCardModule , MatSelectModule , MatIconModule, SharedModule, MatButtonModule, MatInputModule, ReactiveFormsModule, MatButtonModule, NgxMatSelectSearchModule, MatGridListModule]
})
export class FieldsMappingModule { }
