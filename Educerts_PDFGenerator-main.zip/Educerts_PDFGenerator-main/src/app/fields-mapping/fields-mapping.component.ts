import { Component, OnInit } from '@angular/core';
import * as _ from 'lodash';
import { AppConfig } from 'environments/environment';
import { PdfHandlerService } from 'app/service/pdf-handler.service';
import { ConfigFileFieldEntry } from 'app/app.interface';
import { Router } from '@angular/router';

@Component({
    selector: 'app-fields-mapping',
    templateUrl: './fields-mapping.component.html',
    styleUrls: ['./fields-mapping.component.scss']
})
export class FieldsMappingComponent implements OnInit {
    lodash = _; // This is to expose _ to html template
    customFieldAllowedCount = AppConfig.customFields.allowedCount;
    selectedConfigFileName = '';
    dbColumns: string[] = [];
    searchingField = '';
    filterOptions = '';
    selectedSubjectCodeMappingFileName = '';
    selectedSchoolCenterCodeMappingFileName = '';
    subjectCodeMappingCsvColumns = [];
    subjectCodeMappingCsvColumnErrors = [];
    schoolCenterCodeMappingCsvColumns = [];
    schoolCenterCodeMappingCsvColumnErrors = [];

    constructor(
        public pdfHandlerService: PdfHandlerService,
        private router: Router,
    ) { }

    async ngOnInit() {
        this.dbColumns = this.pdfHandlerService.getDbColumns();
    }

    getFieldMappingConfig() {
        let configYear = this.pdfHandlerService.getConfigMappingYear();
        let configFileNames = this.pdfHandlerService.configFileNames;
        let filteredConfigFileNames = {};
        if (configYear) {
            for (let i=0; i<Object.keys(configFileNames).length; i++) {
                let configName = Object.keys(configFileNames)[i];
                let config = this.pdfHandlerService.getConfigByName(configName);
                let configYears = config.year;
                if (configYears.indexOf(configYear) !== -1) {
                    filteredConfigFileNames[configName] = configFileNames[configName];
                }
            }
            return filteredConfigFileNames;
        } else {
            return configFileNames;
        }
    }

    getDbSpecificFields(): ConfigFileFieldEntry[] {
        return this.pdfHandlerService.selectedConfig?.mainFields.filter(x => x.isDbSpecificField);
    }

    getNonDbSpecificFields(): ConfigFileFieldEntry[] {
        return this.pdfHandlerService.selectedConfig?.mainFields.filter(x => !x.isDbSpecificField);
    }

    onFieldMappingConfigChange($event) {
        this.pdfHandlerService.selectedConfigFileName = $event.value;
        this.pdfHandlerService.selectedConfig = this.pdfHandlerService.getConfigByName($event.value);
    }

    searchDbField(field) {
        if(field !== this.searchingField) {
            return this.dbColumns
        }
        const reg = new RegExp(this.filterOptions, 'i')
        const getFilteredList = this.dbColumns.filter((item) => item.match(reg));
        return getFilteredList;
    }

    async subjectCodeInputCSVSelected(e) {
        // reset these controls as they are dependent on the selected CSV
        this.subjectCodeMappingCsvColumns = [];

        const file = e.target.files[0];
        this.subjectCodeMappingCsvColumnErrors = [];
        const data = {
            name: file.name,
            path: file.path,
            type: file.type || '',
        };
        this.pdfHandlerService.selectedSubjectCodeMappingFileName = data.name;
        await this.pdfHandlerService.setImportedCsvSubjectCodeMappingFile(data.path, data.type);
        e.target.value = '';
    }

    async schoolCenterCodeInputCSVSelected(e) {
        // reset these controls as they are dependent on the selected CSV
        this.schoolCenterCodeMappingCsvColumns = [];

        const file = e.target.files[0];
        this.schoolCenterCodeMappingCsvColumnErrors = [];
        const data = {
            name: file.name,
            path: file.path,
            type: file.type || '',
        };
        this.pdfHandlerService.selectedSchoolCenterCodeMappingFileName = data.name;
        await this.pdfHandlerService.setImportedCsvSchoolCenterCodeMappingFile(data.path, data.type);
        e.target.value = '';
    }

    compareFn(str1: string, str2: string) { return str1 && str2 ? str1 === str2 : false; }

    next() {
        if (this.pdfHandlerService.checkIfConfigRelevant()) {
            this.router.navigate(['/app-frame/generate-pdf']);
        }
    }
}
