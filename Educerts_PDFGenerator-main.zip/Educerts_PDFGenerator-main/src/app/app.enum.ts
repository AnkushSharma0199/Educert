
export enum NotificationTypeEnum {
    Default = "default",
    Info = "info",
    Danger = "danger",
    Warning = "warning",
    Success = "success",
    Rose = "rose",
}

export enum PdfGenerationStatusEnum {
    Initial = 1,
    InProgress = 2,
    Completed = 3,
    Errored = 4
}

export enum PdfTemplateTypesName {
    regular = "_regular",
    private = "_private"
}

export enum AppType {
    Portal,
    App,
    RegUser
}

export enum UserRole {
    Admin = 1,
    SalesPartner = 2,
    Maker = 3,
    NationalRegulator = 4,
    StateRegulator = 5,
    DocOwner = 6,
    Checker = 7,
    Approver = 8,
    Publisher = 9,
    OrgAdmin = 10,
    Uploader = 11,
    RegUser = 12
}

export enum FieldTypeEnum {
    Number,
    String,
    Date,
    Email,
    Year,
    Dropdown,
}

export enum DocFlowUserStatusEnum {
    Disabled,
    Enabled,
}

export enum StatusEnum {
    Disabled,
    Enabled,
}

// Ref https://api.itextpdf.com/iText5/java/5.5.9/com/itextpdf/text/pdf/PdfSignatureAppearance.html
export enum CertificationLevelEnum {
    NotCertified = 0, // Approval signature
    CertifiedFormFilling = 2 // Author signature, form filling allowed
}
