import { Injectable } from '@angular/core';
import { UserRole } from 'app/app.enum';

@Injectable({
    providedIn: 'root'
})
export class SharedService {
    /**
     * Parse the provided string return Integer
     * @param: id String to Parse
     */
    public parseInt(id: any) {
        const res = id || id === 0 ? parseInt(id.toString(), 10) : null;

        return res;
    }

    /**
     * Convert enum to object of type { name: string; value: string }[]
     * @param enumVar Enum
     */
    public enumToObjectArray(enumVar: any): { name: string; value: string }[] {
        const objectArray: { name: string; value: string }[] = [];

        for (const n in enumVar) {
            if (enumVar.hasOwnProperty(n) && isNaN(this.parseInt(n))) {
                objectArray.push({
                    name: n,
                    value: enumVar[n] as any,
                });
            }
        }
        return objectArray;
    }

    getFullName(firstName: string, middleName: string, lastName: string): string {
        let fullName = firstName;
        if (middleName) {
            fullName = fullName + ' ' + middleName;
        }
        if (lastName) {
            fullName = fullName + ' ' + lastName;
        }
        return fullName;
    }

    public getUserRoleName(enumId: number) {
        const userRole = this.enumToObjectArray(UserRole).find(
            (x) => this.parseInt(x.value) === enumId
        );
        return userRole ? userRole.name : '';
    }

    getDDMMYYFormatDate(inputDate: Date) {
        const date = inputDate.getDate().toString().padStart(2, '0');
        const month = (inputDate.getMonth() + 1).toString().padStart(2, '0');
        const year = inputDate.getFullYear();

        return `${year}${month}${date}`;
    }

    monthToWord(month: string): string {
        switch (month) {
            case '01':
                return 'January';
            case '02':
                return 'February';
            case '03':
                return 'March';
            case '04':
                return 'April';
            case '05':
                return 'May';
            case '06':
                return 'June';
            case '07':
                return 'July';
            case '08':
                return 'August';
            case '09':
                return 'September';
            case '10':
                return 'October';
            case '11':
                return 'November';
            case '12':
                return 'December';
        }
    }

    dateToWord(date: string): string {
        switch (date) {
            case '01':
                return 'First';
            case '02':
                return 'Second';
            case '03':
                return 'Third';
            case '04':
                return 'Forth';
            case '05':
                return 'Fifth';
            case '06':
                return 'Sixth';
            case '07':
                return 'Seventh';
            case '08':
                return 'Eighth';
            case '09':
                return 'Ninth';
            case '10':
                return 'Tenth';
            case '11':
                return 'Eleventh';
            case '12':
                return 'Twelfth';
            case '13':
                return 'Thirteenth';
            case '14':
                return 'Fourteenth';
            case '15':
                return 'Fifteenth';
            case '16':
                return 'Sixteenth';
            case '17':
                return 'Seventeenth';
            case '18':
                return 'Eighteenth';
            case '19':
                return 'Nineteenth';
            case '20':
                return 'Twentieth';
            case '21':
                return 'TwentyFirst';
            case '22':
                return 'TwentySecond';
            case '23':
                return 'TwentyThird';
            case '24':
                return 'TwentyFourth';
            case '25':
                return 'TwentyFifth';
            case '26':
                return 'TwentySixth';
            case '27':
                return 'TwentySeventh';
            case '28':
                return 'TwentyEighth';
            case '29':
                return 'TwentyNinth';
            case '30':
                return 'Thirtieth';
            case '31':
                return 'ThirtyFirst';
        }
    }
}
