import { Component, Inject, Injectable, Optional } from '@angular/core';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarRef, MatSnackBarVerticalPosition, MAT_SNACK_BAR_DATA, } from '@angular/material/snack-bar';
import { TranslateService } from '@ngx-translate/core';
import { NotificationTypeEnum } from 'app/app.enum';
import { AppConfig } from 'environments/environment';

interface NotificationData {
    type: NotificationTypeEnum;
    finalMessage: string;
}

@Component({
    template: `<div class="row flex-nowrap custom-alert custom-alert-{{ notificationData?.type }}">
            <span>{{ notificationData?.finalMessage }} </span>
            <span class="ml-auto cursor-pointer">
                <i class="material-icons white-color-icon" (click)="snackBarRef.dismiss()">close</i>
            </span>
         </div>`
})
export class NotificationComponent {
    constructor(
        @Inject(MAT_SNACK_BAR_DATA)
        @Optional()
        public notificationData: NotificationData,
        public snackBarRef: MatSnackBarRef<NotificationComponent>,
    ) { }
}

@Injectable({
    providedIn: 'root'
})
export class NotificationService {
    horizontalPosition: MatSnackBarHorizontalPosition = 'end';
    verticalPosition: MatSnackBarVerticalPosition = 'top';

    constructor(
        private snackBar: MatSnackBar,
        private translateService: TranslateService
    ) { }

    openSnackBar(message: string): void {
        this.snackBar.open(message, '', {
            duration: 1500,
            horizontalPosition: this.horizontalPosition,
            verticalPosition: this.verticalPosition,
        });
    }
    public notify(
        message: string,
        type: NotificationTypeEnum,
        componentName?: string,
        substitueValue: string = null
    ): void {
        const duration = AppConfig.uiSettings.snackBarDurationInSec;
        this.translateService.get('message.' + message).subscribe((msg: string) => {
            let finalMessage = componentName ? componentName + ' ' + msg : msg;
            // if substitute value is give then we will substitute the value with placeholder in the translated message
            if(substitueValue) {
                finalMessage = finalMessage.replace('{{placeHolder}}', substitueValue)
            }
            this.snackBar.openFromComponent(NotificationComponent, {
                panelClass: 'app-snack-bar-no-bg-container',
                data: {
                    type,
                    finalMessage,
                },
                duration: duration,
                horizontalPosition: this.horizontalPosition,
                verticalPosition: this.verticalPosition,
            });
        });
    }

    public errorToastNotification(message: string): void{
        if (!message) {
            message = 'internalError';
        }
        this.notify(message, NotificationTypeEnum.Danger);
    }

    public successToastNotification(msg: string, substitueValue: string = null, componentName?: string): void{
        this.notify(msg, NotificationTypeEnum.Success, componentName, substitueValue);
    }

    public infoToastNotification(msg: string, componentName?: string): void {
        this.notify(msg, NotificationTypeEnum.Info, componentName);
    }

}
