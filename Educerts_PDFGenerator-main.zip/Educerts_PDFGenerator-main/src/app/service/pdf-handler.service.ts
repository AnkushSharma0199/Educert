import { Injectable, NgZone } from '@angular/core';
import { BehaviorSubject, Subject } from 'rxjs';
import { ElectronService } from 'app/core/services';
import { Papa, ParseResult } from 'ngx-papaparse';
import * as check from 'closest-match';
import * as _ from 'lodash';
import { ConfigFile, ConfigFileEntry, ConfigFileFieldEntry, PdfFormData, WorkerInputParam } from 'app/app.interface';
import { AppConfig } from 'environments/environment';
import { NotificationTypeEnum, PdfGenerationStatusEnum, PdfTemplateTypesName } from 'app/app.enum';
import { SharedService } from './shared.service';
import { NotificationService } from './notification.service';
import MDBReader from 'mdb-reader';
import subjectData from '../../assets/SubData/SubData.json';
import SchoolCodeMaster_10th12th from '../../assets/SchoolData/SchoolCodeMaster_10th12th.json';
import SchoolCodeMaster_DLED from '../../assets/SchoolData/SchoolCodeMaster_DLED.json';
import { ToWords } from 'to-words';
import moment from 'moment';
import { Global } from 'app/app.global';
import { transliterate } from 'transliteration';

const SCHOOL_CODE_PDF_FIELD = 'schoolCodePdfField'
const CENTER_CODE_PDF_FIELD = 'centerCodePdfField'
const SCHOOL_NAME_PDF_TEMPLATE_FIELD = 'schoolNamePdfField'
const RPDIS_PDF_TEMPLATE_FIELD = 'RPDIS';
const EXAM_TYPE_FIELD = 'examType';
const REPORT_CSV_STATUS_FIELD = 'status_code';
const REPORT_CSV_MEG_FIELD = 'status_msg';

const RESULTS_IN_WORDS = 'resultsInWords';
const TOTAL_MARK_FIELD = 'totalMarks';

const DOB = 'DOB';
const RESULT_ON_FIELD = 'resultOnField';
const RESULT_ON_FIELD_FORMAT = 'resultOnFieldFormat';
const RESULT_ON_FIELD_PRINT_FORMAT = 'resultOnFieldPrintFormat';
const SCHOOL_CODE_MASTER_FILE = 'schoolCodeMasterFile';

const DOB_DATE_FORMAT = 'DD.MM.YYYY'
const RESULTON_DATE_FORMAT = 'DD-MM-YYYY'
@Injectable({
    providedIn: 'root'
})
export class PdfHandlerService {
    public pdfGenerationStatus = new BehaviorSubject({
        state: PdfGenerationStatusEnum.Initial,
        totalDocs: null,
        currentDocs: null
    });
    private dbColumns: string[] = [];
    private pdfGenerationFormData: PdfFormData = null;
    private subjectCodeMappingData = {};
    private schoolCenterCodeMappingData = {};
    private recordsToProcess: any[] = null;
    private accessDbTables: string[] = [];
    private fontBuffer: Buffer = null;
    private outputCsvHeaders = [];
    public isFieldMappingError = new BehaviorSubject(false);
    private configMappingYear = null;

    pdfTemplateBuffer: Buffer;
    inputDataChunks = [];
    configFile: ConfigFile;
    configFileNames: { [key: string]: string } = {};
    configFileYears: { [key: string]: string } = {};
    selectedConfig: ConfigFileEntry;
    selectedConfigFileName: string;
    subjectCodeMappingFile;
    schoolCenterCodeMappingFile;
    selectedSubjectCodeMappingFileName: string = '';
    selectedSchoolCenterCodeMappingFileName: string = '';


    constructor(
        private electronService: ElectronService,
        private sharedService: SharedService,
        private notificationService: NotificationService,
        private papaParser: Papa,
        private ngZone: NgZone,
    ) {
        this.electronService.ipcRenderer.invoke('get-json-data').then((configFile) => {
            this.configFile = configFile;

            const keys = Object.keys(this.configFile);
            _.each(keys, (key: string) => {
                this.configFileNames[key] = this.configFile[key].name;
                this.configFileYears[key] = `${this.configFile[key].year}`;
            });

        }, (err) => {
            console.log('Error loading config file ', err);
        });
    }

    public getConfigByName(configName: string): ConfigFileEntry {
        return this.configFile[configName];
    }

    public async setImportedCsvOrAccessDbFile(path: string, type: string) {
        if (!path) {
            return
        }

        if (type !== 'text/csv' && type !== 'application/msaccess') {
            return
        }

        this.recordsToProcess = [];
        this.dbColumns = [];

        switch (type) {
            case 'text/csv': {
                const fileData = this.electronService.fs.readFileSync(path, { encoding: 'utf8' });
                this.accessDbTables = [];
                this.papaParser.parse(fileData, {
                    skipEmptyLines: true,
                    header: true,
                    step: (results, parser) => {
                        this.dbColumns = Object.keys(results.data);
                        parser.abort();
                    },
                })
                break;
            }
            case 'application/msaccess': {
                const fileData = this.electronService.fs.readFileSync(path);
                const reader = new MDBReader(fileData);
                this.accessDbTables = reader.getTableNames()
                break;
            }
        }

        if (this.accessDbTables.length === 0) {
            // this.handleInputCsvData()
        }
    }

    public async setImportedCsvSubjectCodeMappingFile(path: string, type: string) {
        if (!path) {
            return
        }

        if (type !== 'text/csv') {
            return
        }

        this.subjectCodeMappingData = {};
        
        const fileData = this.electronService.fs.readFileSync(path, { encoding: 'utf8' });
        this.papaParser.parse(fileData, {
            skipEmptyLines: true,
            header: true,
            step: (row /*, parser */) => {
                const { 
                    SUBJECT_NAME, 
                    SUBJECT_CODE, 
                    MAX_INP_S, 
                    MIN_INP_S, 
                    MAX_TH_S, 
                    MIN_TH_S, 
                    MAX_TOTAL_S,
                    PRIVATE_OR_REGULAR
                } = row.data;
                //console.log(row.data);

                const categories = PRIVATE_OR_REGULAR.split('/');

                categories.forEach(category => {
                    const paddedSubjectCode = `${SUBJECT_CODE}`.padStart(3, '0') + "_" + category.toUpperCase();
                
                this.subjectCodeMappingData[paddedSubjectCode] = {
                    SUBJECT_NAME,
                    MAX_TOTAL_S,
                    MAX_TH_S,
                    MIN_TH_S,
                    MAX_INP_S,
                    MIN_INP_S
                    };
                });
                
                // parser.abort();
            },
        });
    }

    public async setImportedCsvSchoolCenterCodeMappingFile(path: string, type: string) {
        if (!path) {
            return
        }

        if (type !== 'text/csv') {
            return
        }

        this.schoolCenterCodeMappingData = {
            CENTER_CODE: {},
            SCHOOL_CODE: {}
        };
        const fileData = this.electronService.fs.readFileSync(path, { encoding: 'utf8' });
        this.papaParser.parse(fileData, {
            skipEmptyLines: true,
            header: true,
            step: (row /*, parser */) => {
                const { 
                    CENTER_CODE, 
                    SCHOOL_CODE, 
                    CENTER_NAME, 
                    SCHOOL_NAME
                } = row.data;
                if (this.schoolCenterCodeMappingData["CENTER_CODE"] && !this.schoolCenterCodeMappingData["CENTER_CODE"][CENTER_CODE]) {
                    this.schoolCenterCodeMappingData["CENTER_CODE"][CENTER_CODE] = CENTER_NAME;
                }
                if (this.schoolCenterCodeMappingData["SCHOOL_CODE"] && !this.schoolCenterCodeMappingData["SCHOOL_CODE"][SCHOOL_CODE]) {
                    this.schoolCenterCodeMappingData["SCHOOL_CODE"][SCHOOL_CODE] = SCHOOL_NAME;
                }
            },
        });
    }

    public getAccessDbTables() {
        return this.accessDbTables
    }

    public async setAccessDbTableData(tableName) {
        this.recordsToProcess = [];
        const fileData = this.electronService.fs.readFileSync(this.pdfGenerationFormData.csvFile.path);
        const reader = new MDBReader(fileData);
        const table = reader.getTable(tableName);
        this.dbColumns = table.getColumns()?.map((item) => item.name);
        // this.handleInputCsvData();
    }

    public getDbColumns() {
        return this.dbColumns;
    }

    public get getTotalCsvRecordsCount(): number {
        return this.recordsToProcess?.length || 0;
    }

    public setPdfGenerationFormData(data: PdfFormData) {
        this.pdfGenerationFormData = data;
    }

    public getPdfGenerationFormData(): PdfFormData {
        return this.pdfGenerationFormData
    }

    public setSubjectCodeMappingData(data) {
        this.subjectCodeMappingData = data;
    }

    public getSubjectCodeMappingData() {
        return this.subjectCodeMappingData;
    }

    public setConfigMappingYear(year) {
        this.configMappingYear = year;
    }

    public getConfigMappingYear() {
        return this.configMappingYear;
    }

    public setSchoolCenterCodeMappingData(data) {
        this.schoolCenterCodeMappingData = data;
    }

    public getSchoolCenterCodeMappingData() {
        return this.schoolCenterCodeMappingData;
    }

    public get isReadyForPreview(): boolean {
        let isReadyForPreview = true
        if (
            !(this.pdfGenerationFormData &&
                this.pdfGenerationFormData?.csvFile?.path &&
                this.pdfGenerationFormData?.pdfTemplateFile?.path &&
                this.pdfGenerationFormData?.fontFile?.path &&
                this.pdfGenerationFormData?.privateRegularField
            )
        ) { isReadyForPreview = false }

        if (this.accessDbTables.length > 0 && !this.pdfGenerationFormData.accessDBTable) { isReadyForPreview = false }

        return isReadyForPreview;
    }

    public async generatePdf(): Promise<void> {
        try {
            if ((!this.checkIfConfigRelevant())) {
                this.isFieldMappingError.next(true)
                this.pdfGenerationStatus.next({
                    state: PdfGenerationStatusEnum.Errored,
                    totalDocs: null,
                    currentDocs: null
                });
                return;
            }
            this.isFieldMappingError.next(false)

            const folderContent = await this.electronService.fs.promises.readdir(this.pdfGenerationFormData?.outputPath)

            // check if output folder is empty or not
            if (folderContent.length !== 0) {
                this.notificationService.notify('folderNotEmpty', NotificationTypeEnum.Danger)
                this.pdfGenerationStatus.next({
                    state: PdfGenerationStatusEnum.Errored,
                    totalDocs: null,
                    currentDocs: null
                });
                return;
            }

            // Load font file
            this.fontBuffer = this.electronService.fs.readFileSync(this.pdfGenerationFormData?.fontFile.path);

            // Load Pdf template
            this.pdfTemplateBuffer = this.electronService.fs.readFileSync(this.pdfGenerationFormData?.pdfTemplateFile?.path);

            if (true) {
                const promise = new Promise((resolve, reject) => {
                    setTimeout(async () => {
                        await this.readCsvOrAccessDbTable();
                        resolve(true)
                    }, 1000)
                })
                await promise;
            }

            // Adding Regular/private column to each record
            const privateRegularField = this.getConfigFileEntry('candidateType');
            if (privateRegularField) {
                this.recordsToProcess.forEach(x => {
                    const value = x[privateRegularField.mappedField];
                    switch (value?.toLowerCase()) {
                        case '1':
                        case '5':
                        case '7':
                            x[privateRegularField.mappedField] = 'regular';
                            x[RPDIS_PDF_TEMPLATE_FIELD] = 'REGULAR';
                            break;
                        case '2':
                        case '4':
                        case '6':
                        case '8':
                            x[privateRegularField.mappedField] = 'private'
                            x[RPDIS_PDF_TEMPLATE_FIELD] = 'PRIVATE';
                            break;
                        case 'regular':
                            x[RPDIS_PDF_TEMPLATE_FIELD] = 'REGULAR';
                            break;
                        case 'private':
                            x[RPDIS_PDF_TEMPLATE_FIELD] = 'PRIVATE';
                            break;
                    }
                });

                // Check to ensure that private/regular values exists in records based on user's selected column
                if (!['private', 'regular'].includes(this.recordsToProcess[0][privateRegularField.mappedField])) {
                    this.notificationService.notify('privateRegularDataError', NotificationTypeEnum.Danger);
                    this.pdfGenerationStatus.next({
                        state: PdfGenerationStatusEnum.Errored,
                        totalDocs: null,
                        currentDocs: null
                    });
                    return;
                }
            }

            // Update status to InProgress
            this.pdfGenerationStatus.next({
                state: PdfGenerationStatusEnum.InProgress,
                totalDocs: '-',
                currentDocs: 0,
            });

            // Split data in chunks of 4 records each
            this.inputDataChunks = _.chunk(this.recordsToProcess, 4);

            // Get Header to write in Csv file
            this.outputCsvHeaders = this.getHeadersForOutputCsv();

            this.createPdfAndCsv(0);
        } catch (err) {
            this.pdfGenerationStatus.next({
                state: PdfGenerationStatusEnum.Errored,
                totalDocs: null,
                currentDocs: null
            });
            console.log(err);
        }
    }

    // This func is called recursively for each data chunk
    private async createPdfAndCsv(index, outputFolder = '') {
        // if all input data chunks processed then we will stop the execution
        if (index >= this.inputDataChunks.length) {
            // Reset status to Initial
            this.pdfGenerationStatus.next({
                state: PdfGenerationStatusEnum.Initial,
                totalDocs: null,
                currentDocs: null,
            });

            // here ngZone.run is required as due to some reason Notification message doesn't gets displayed properly.
            // it gets aligned to left side and spinner animation on Generate PDF button doesn't stops
            this.ngZone.run(() => {
                this.notificationService.successToastNotification(
                    'pdfGenerationSuccessful',
                    `${this.pdfGenerationFormData.outputPath}`
                );
            });

            // After process completion we are opening the output location folder after 1s delay
            const timeoutVar = setTimeout(() => {
                clearTimeout(timeoutVar);
                this.electronService.ipcRenderer.invoke(
                    'open-folder',
                    this.pdfGenerationFormData.outputPath
                );
            }, 1000);

            return;
        }

        // send the pdf processing information for the UI
        this.pdfGenerationStatus.next({
            state: PdfGenerationStatusEnum.InProgress,
            totalDocs: this.recordsToProcess.length,
            currentDocs: this.pdfGenerationStatus.value.currentDocs + 4,
        });

        // folderName on which the pdf need to be created
        const rollNoMappedField = this.getConfigFileEntry('rollNo').mappedField;
        let folderName = outputFolder

        // Create folder for each batch of 1000 records along with a CSV file for each folder
        if (index % 250 === 0) {
            // folderName format is {index}.{rollno}
            folderName = `${(index * 4 + 1)}.${this.inputDataChunks[index][0][rollNoMappedField]}`;
            const folderPath = this.electronService.path.join(this.pdfGenerationFormData.outputPath, folderName);
            this.electronService.fs.mkdirSync(folderPath);
            this.electronService.ipcRenderer.invoke('set-csv-writer', {
                path: this.electronService.path.join(folderPath, AppConfig.csv.outputCsvName),
                header: this.outputCsvHeaders,
            });

            const reportDate = this.sharedService.getDDMMYYFormatDate(new Date());
            const reportName = `${AppConfig.csv.reportCsvNamePrefix}${reportDate}.csv`;
            this.electronService.ipcRenderer.invoke('set-report-csv-writer', {
                path: this.electronService.path.join(folderPath, reportName),
                header: this.getHeadersForReportCsv(),
            });
        }

        // Start PDF generation
        const context = this.writeCsvAndGetProcessData(this.inputDataChunks[index], folderName);
        context.forEach(x => x.rollNoMappedField = rollNoMappedField);
        await this.electronService.ipcRenderer.invoke('run-worker-service', context);

        // Call this function again with next index
        await this.createPdfAndCsv(index + 1, folderName);
    }

    private writeCsvAndGetProcessData(inputCsvChunkData: any[], outputFolderName: string): WorkerInputParam[] {
        const imageFolderPath = this.pdfGenerationFormData.imagePath;
        const dataToProcessByWorker = [];
        const outputCsvRecs = [];
        const reportCsvRecs = [];

        inputCsvChunkData.map((record, index) => {
            const reportStatusMsgField = [];
            const reportCsvRec = {};
            let reportStatusCodeField = 'Success';

            const firstNameFieldConfig = this.getConfigFileEntry('firstName');
            if (!!record[firstNameFieldConfig.mappedField]) {
                reportCsvRec[firstNameFieldConfig.id] = record[firstNameFieldConfig.mappedField];
            } else {
                reportStatusCodeField = 'Warning';
                reportStatusMsgField.push('Name field missing');
            }

            const middleNameFieldConfig = this.getConfigFileEntry('middleName');
            const lastNameFieldConfig = this.getConfigFileEntry('lastName');

            const nameObj = {
                firstName: '',
                middleName: '',
                lastName: '',
            }
            const nameArr = record[this.getConfigFileEntry('firstName')?.mappedField]?.toString().replace(/\s+/g, ' ')?.split(' ')?.map((x:string) => x?.trim()) || [];

            this.setNameInfo(nameArr, nameObj);

            reportCsvRec[firstNameFieldConfig.id] = nameObj.firstName;
            reportCsvRec[middleNameFieldConfig.id] = nameObj.middleName;
            reportCsvRec[lastNameFieldConfig.id] = nameObj.lastName;

            const dobFieldConfig = this.getConfigFileEntry('dob');
            if (dobFieldConfig.isRequiredField && !record[dobFieldConfig.mappedField]) {
                reportStatusCodeField = 'Warning';
                reportStatusMsgField.push('DoB field missing');
            }

            const enrollNoFieldConfig = this.getConfigFileEntry('enrollNo');
            if (enrollNoFieldConfig.isRequiredField && !record[enrollNoFieldConfig.mappedField]) {
                reportStatusCodeField = 'Warning';
                reportStatusMsgField.push('Enrollment no field missing');
            }

            if (enrollNoFieldConfig.mappedField) {
                if (enrollNoFieldConfig.showInReportCSV) {
                    reportCsvRec[enrollNoFieldConfig.id] = record[enrollNoFieldConfig.mappedField];
                }
            }

            const academicYearFieldConfig = this.getConfigFileEntry('academicYear');
            if (!!record[academicYearFieldConfig.mappedField]) {
                reportCsvRec[academicYearFieldConfig.id] = record[academicYearFieldConfig.mappedField];
            } else if (academicYearFieldConfig.defaultValue) {
                reportCsvRec[academicYearFieldConfig.id] = academicYearFieldConfig.defaultValue;
            }
            else {
                reportStatusCodeField = 'Warning';
                reportStatusMsgField.push('Academic year field is missing');
            }

            const chanceFieldConfig = this.getConfigFileEntry('chance');
            if (chanceFieldConfig) {
                reportCsvRec[chanceFieldConfig.id] = chanceFieldConfig.defaultValue;
            }

            const classTypeFieldConfig = this.getConfigFileEntry('classType');
            reportCsvRec[classTypeFieldConfig.id] = classTypeFieldConfig.defaultValue;

            const candidateTypeFieldConfig = this.getConfigFileEntry('candidateType');
            reportCsvRec[candidateTypeFieldConfig.id] = record[candidateTypeFieldConfig.mappedField];

            const rollNoFieldConfig = this.getConfigFileEntry('rollNo');
            const rollNo = record[rollNoFieldConfig.mappedField];
            const imagePath = this.electronService.path.join(imageFolderPath, rollNo + '.jpg');
            if (!this.electronService.fs.existsSync(imagePath)) {
                reportStatusCodeField = 'Warning';
                reportStatusMsgField.push('Student image is missing');
            }

            const resultInNumber = record[this.selectedConfig.pdfTemplateMappingFields[TOTAL_MARK_FIELD]];
            const toWords = new ToWords();
            record[this.selectedConfig.pdfTemplateMappingFields[RESULTS_IN_WORDS]] =
                resultInNumber && toWords.convert(resultInNumber)?.toUpperCase() || '';

            // Setting formatted DoB
            const dobch = (record[dobFieldConfig.mappedField] || '').trim();
            let csvDobField = '';
            if (dobch) {
                const parsedDate = moment(dobch.padStart(6, 0), 'DDMMYY');
                if (parsedDate.isValid()) {
                    csvDobField = parsedDate.format(RESULTON_DATE_FORMAT)
                    let dateStr = parsedDate.format(DOB_DATE_FORMAT) + '  ';
                    const dateArr = dateStr.split('.');
                    dateStr += this.sharedService.dateToWord(dateArr[0]) + ' '; // date to word
                    dateStr += this.sharedService.monthToWord(dateArr[1]) + '-'; // month to word
                    dateStr += toWords.convert(+dateArr[2]); // year to word
                    record[DOB] = dateStr.toUpperCase();
                    if (dobFieldConfig.showInOutputCSV) {
                        reportCsvRec[dobFieldConfig.id] = csvDobField;
                    }
                } else {
                    reportStatusCodeField = 'Warning';
                    reportStatusMsgField.push('Dob is in invalid format');
                }
            }

            if (!!rollNo) {
                reportCsvRec[rollNoFieldConfig.id] = rollNo;
            } else {
                reportStatusCodeField = 'Error';
                reportStatusMsgField.push('RollNo field is required');
            }

            const fullName = this.sharedService.getFullName(
                record[firstNameFieldConfig.mappedField]?.replace(Global.regex.specialCharacters, '')?.replace(Global.regex.extraSpaces, ' ')?.trim(),
                record[middleNameFieldConfig.mappedField]?.replace(Global.regex.specialCharacters, '')?.replace(Global.regex.extraSpaces, ' ')?.trim(),
                record[lastNameFieldConfig.mappedField]?.replace(Global.regex.specialCharacters, '')?.replace(Global.regex.extraSpaces, ' ')?.trim()
            ) ?? 'No_Name';

            const roleNumberField = rollNo ?? '';
            const pdfName = `${fullName}_${roleNumberField}.pdf`;
            const pdfFilePath = this.electronService.path.join(this.pdfGenerationFormData.outputPath, outputFolderName, pdfName);

            const candidateType = this.getConfigFileEntry('candidateType').mappedField;
            const privateRegularField = record[candidateType].toLowerCase();
           
           
            //mapping SCHOOL_NAME_PDF_TEMPLATE_FIELD depending on privateRegularField
            var schoolOrCenterName=" ";
            //For private students Center name will be used and for regular school name will be used
            if(privateRegularField == "private"){
                const centerCode = record[this.selectedConfig.pdfTemplateMappingFields[CENTER_CODE_PDF_FIELD]];
                schoolOrCenterName = this.schoolCenterCodeMappingData["CENTER_CODE"][centerCode];
            }
            else{
            // School code to School name mapping
                const schoolCode = record[this.selectedConfig.pdfTemplateMappingFields[SCHOOL_CODE_PDF_FIELD]];
                schoolOrCenterName = this.schoolCenterCodeMappingData["SCHOOL_CODE"][schoolCode];
            }
            //removing any non-ASCII character as it'll cause error in pdf generation
            const asciiSchoolOrCenterName = transliterate(schoolOrCenterName, {
                unknown: ' ' // Replace unknown characters with a space
            });
            
            //if any non-ASCII character found, pushing a warning into the generation Report
            if (asciiSchoolOrCenterName !== schoolOrCenterName) {
                reportStatusCodeField = 'Warning';
                reportStatusMsgField.push('Unsupported characters in school name or center name: ' + schoolOrCenterName);
                schoolOrCenterName = asciiSchoolOrCenterName.replace(/ {2,}/g, ' '); // Replace consecutive spaces with a single space
            }
            record[this.selectedConfig.pdfTemplateMappingFields[SCHOOL_NAME_PDF_TEMPLATE_FIELD]] = schoolOrCenterName;
            // const schoolCodeMasterFileName = this.selectedConfig.schoolCodeMasterFile;
            // switch (schoolCodeMasterFileName) {
            //     case 'SchoolCodeMaster_DLED.json':
            //         schoolCode = SchoolCodeMaster_DLED[centerCode];
            //         record[this.selectedConfig.pdfTemplateMappingFields[SCHOOL_NAME_PDF_TEMPLATE_FIELD]] = schoolCode;
            //         break;
            //     case 'SchoolCodeMaster_10th12th.json':
            //         schoolCode = SchoolCodeMaster_10th12th[centerCode];
            //         record[this.selectedConfig.pdfTemplateMappingFields[SCHOOL_NAME_PDF_TEMPLATE_FIELD]] = schoolCode;
            //         break;
            // }

            // Prepare output CSV record entry
            const outputCsvRec = {};
            _.forEach(this.getHeadersForOutputCsv(), (config) => {
                const key = config.id;
                if (key === 'fileName') {
                    outputCsvRec[key] = pdfName;
                } else if (nameObj[key]) {
                    outputCsvRec[key] = nameObj[key];
                } else if (key === EXAM_TYPE_FIELD) {
                    const examType = this.getConfigFileEntry(EXAM_TYPE_FIELD).defaultValue;
                    outputCsvRec[EXAM_TYPE_FIELD] = examType;
                    reportCsvRec[EXAM_TYPE_FIELD] = examType;
                } else if (key === dobFieldConfig.mappedField) {
                    outputCsvRec[key] = csvDobField;
                }
                else {
                    if (record[this.getConfigFileEntry(key)?.mappedField]) {
                        outputCsvRec[key] = record[this.getConfigFileEntry(key).mappedField];
                    } else {
                        outputCsvRec[key] = this.getConfigFileEntry(key)?.defaultValue;
                    }
                }
            })


            // ----------------- DB Specific fields handling -----------------//

            const resultOnField = record[this.selectedConfig.pdfTemplateMappingFields[RESULT_ON_FIELD]];
            const resultOnFieldFormat = this.selectedConfig.pdfTemplateMappingFields[RESULT_ON_FIELD_FORMAT];
            const resultOnFieldPrintFormat = this.selectedConfig.pdfTemplateMappingFields[RESULT_ON_FIELD_PRINT_FORMAT];

            if (resultOnField) { // Change format if this field exists
                const currentDate = resultOnField;
                record[this.selectedConfig.pdfTemplateMappingFields[RESULT_ON_FIELD]] =
                    moment(currentDate, resultOnFieldFormat).format(resultOnFieldPrintFormat).toString();
            }

            // do not write in csv and create pdf if the csv field selected does not contain private and regular in them
            // const candidateType = this.getConfigFileEntry('candidateType').mappedField;
            // const privateRegularField = record[candidateType].toLowerCase();
            const classField = classTypeFieldConfig.defaultValue;

            const supplementarySubject = this.selectedConfig?.supplementarySubjects;
            var supplementarySubjectCode = supplementarySubject?.map((spc) => record[spc]);

            //console.log(this.subjectCodeMappingData);
            const subjectCodes = this.selectedConfig.subjectCodes; 
            if (['regular', 'private'].includes(record[candidateType].toLowerCase())) {
                let obj = {}
                Object.keys(subjectCodes).forEach((subjectName, i) => {
                    const subjectCode = record[subjectName];
                    if (subjectCode) {
                        if(supplementarySubjectCode?.includes(subjectCode)){
                            record['bq'+(i+1)] = record['bq'+ (i+1)] ? ('* '+ record['bq'+ (i+1)]) : '*';
                        }
                        // const marksObj = subjectData.marks[classField][privateRegularField][subjectCode];
                        const marksObj = this.subjectCodeMappingData[subjectCode+"_"+privateRegularField.toUpperCase()];
                        if (marksObj) {
                            obj = { ...obj, ..._.mapKeys(marksObj, (val, key) => key + (i + 1)) }
                            //console.log(obj)
                            obj = _.mapValues(obj, val => {
                                if (val === 0 || (val+"").trim() === "0" || (val+"").trim() === "-") {
                                    return '-'
                                } else {
                                    return _.padStart(val, 3, '0')
                                }
                            }); // This changes marks from, for instance, 33 => 033
                            //console.log(obj)


                        }
                    }
                })
                // console.log(subjectCodes);
                // console.log(obj);
                // console.log(record);

                record = { ...record, ...obj }

                // Replace empty practical values with "-", manual override (TO REVISIT)
                _.forEach(record, (val, key) => {
                    if (classField === "10th" || classField === "12th") {
                        if (key.startsWith("Prac") || (key.startsWith("mark") && key.endsWith("3"))) {
                            let v = val;
                            let p = key.charAt(4);
                            let ref = record[`MAX_INP_S${p}`];
                            if (ref !== undefined && ref?.trim().length && !v?.trim().length) {
                                record[key] = "-";
                            }
                        }
                    }
                });

                //sanity check for obtained marks
                const failedAt: string[] = [];
                const theoryMarks: { subNo: number; percentage: number; pracMarks: number }[] = [];
                var totalSubjects = 7;
                const fieldPrefixes = {
                    maxTheory: "MAX_TH_S#",
                    maxPrac: "MAX_INP_S#",
                    maxTotal: "MAX_TOTAL_S#",
                    obtainedTheory: "mark#",
                    obtainedPrac: "Prac#",
                    obtainedTotal: "Tot#",
                };

                // If classField is identified as 12th grade
                if (classField === "12th") {
                    totalSubjects = 6;
                    fieldPrefixes.obtainedTheory = "mark#1";
                    fieldPrefixes.obtainedPrac = "mark#3";
                }

                if (classField === "10th" || classField === "12th") {
                    for (var i = 1; i <= totalSubjects; i++) {
                        const subNo = i.toString();
                        const maxTheoryMarks = parseFloat(record[fieldPrefixes.maxTheory.replace('#', subNo)]) || 0;
                        const obtainedTheoryMarks = parseFloat(record[fieldPrefixes.obtainedTheory.replace('#', subNo)]) || 0;
                        const maxPracMarks = parseFloat(record[fieldPrefixes.maxPrac.replace('#', subNo)]) || 0;
                        const obtainedPracFieldName = (classField === "10th" && subNo === "5") ? fieldPrefixes.obtainedTheory.replace('#', "p") : fieldPrefixes.obtainedPrac.replace('#', subNo);
                        const obtainedPracMarks = parseFloat(record[obtainedPracFieldName]) || 0;
                        const maxTotalMarks =  parseFloat(record[fieldPrefixes.maxTotal.replace('#', subNo)]) || 0;
                        
                        if (obtainedTheoryMarks > maxTheoryMarks) {
                            failedAt.push(`${fieldPrefixes.obtainedTheory}${subNo} ${obtainedTheoryMarks}/${maxTheoryMarks}`);
                        }

                        if (obtainedPracMarks > maxPracMarks) {
                            failedAt.push(`${fieldPrefixes.obtainedPrac}${subNo} ${obtainedPracMarks}/${maxPracMarks}`);
                        }

                        const calculatedTotalMarks = obtainedTheoryMarks + obtainedPracMarks;
                        if (parseFloat(record[fieldPrefixes.obtainedTotal.toLowerCase().replace('#', subNo)])) {
                            record[fieldPrefixes.obtainedTotal.replace('#', subNo)] = record[fieldPrefixes.obtainedTotal.toLowerCase().replace('#', subNo)];
                        }
                        const obtainedTotalMarks = parseFloat(record[fieldPrefixes.obtainedTotal.replace('#', subNo)]) || 0;
                        
                        if (calculatedTotalMarks !== obtainedTotalMarks) {
                            failedAt.push(`${fieldPrefixes.obtainedTotal}${subNo} ${obtainedTotalMarks}/${calculatedTotalMarks}`);
                        }

                        const theoryPercentage = (obtainedTotalMarks / maxTotalMarks) * 100;

                        theoryMarks.push({ subNo: i, percentage: theoryPercentage, pracMarks: obtainedPracMarks });

                    }
                }

                //console.log(theoryMarks)
                // Select best five based on theory percentage, and if same percentage, choose higher practical marks
                const sortedMarks = theoryMarks.sort((a, b) => {
                    if (a.percentage === b.percentage) {
                        return b.pracMarks - a.pracMarks; // Sort by practical marks in descending order
                    } else {
                        return b.percentage - a.percentage; // Sort by theory percentage in descending order
                    }
                });
                const bestFive = sortedMarks.slice(0, 5);

                // Calculate total marks of best five
                const bestOfFiveTotalMarks = bestFive.reduce((sum, mark) => {
                    const obtainedTheoryMarks = parseFloat(record[fieldPrefixes.obtainedTheory.replace('#', mark.subNo.toString())]) || 0;
                    const obtainedPracFieldName = (classField === "10th" && mark.subNo === 5) ? fieldPrefixes.obtainedTheory.replace('#', "p") : fieldPrefixes.obtainedPrac.replace('#', mark.subNo.toString());
                    const obtainedPracMarks = parseFloat(record[obtainedPracFieldName]) || 0;
                    return sum + obtainedTheoryMarks + obtainedPracMarks;
                }, 0);

                // Compare best of 5 total marks with "total_mark" field
                const totalMarkField = parseFloat(record["total_mark"]) || 0;
                if (bestOfFiveTotalMarks !== totalMarkField) {
                    //failedAt.push(`total_mark ${bestOfFiveTotalMarks} ${totalMarkField}`);
                    // reportStatusCodeField = 'Warning';
                    // reportStatusMsgField.push(`total_mark: ${bestOfFiveTotalMarks}(best of five) != ${totalMarkField}(total in db)`);
                }

                // Process failed validations
                if (failedAt.length > 0) {
                    reportStatusCodeField = 'Error';
                    reportStatusMsgField.push('Marks validation failed at:');
                    failedAt.forEach(field => {
                        reportStatusMsgField.push(`${field}`);
                    });
                }

                // Replacing subject code with name

                _.forEach(subjectCodes, (val, key) => {
                    record[key] = record[val];
                })

                reportCsvRec[REPORT_CSV_MEG_FIELD] = reportStatusMsgField.join(', ');
                reportCsvRec[REPORT_CSV_STATUS_FIELD] = reportStatusCodeField;

                reportCsvRecs.push(reportCsvRec);

                if (reportStatusCodeField !== 'Error') {
                    outputCsvRecs.push(outputCsvRec);
                    dataToProcessByWorker.push({
                        pdfTemplateBuffer: this.pdfTemplateBuffer,
                        formData: this.pdfGenerationFormData,
                        fontBuffer: this.fontBuffer,
                        record,
                        pdfFilePath
                    })
                }
            }
        })

        // write records in CSV by invoking set-csv-record for Node process
        if (outputCsvRecs.length > 0) {
            this.electronService.ipcRenderer.invoke('set-csv-record', outputCsvRecs)
        }

        this.electronService.ipcRenderer.invoke('set-report-csv-record', reportCsvRecs)
        //console.log(dataToProcessByWorker)
        return dataToProcessByWorker
    }

    setNameInfo(nameArr, nameObj){
    
        switch (nameArr.length) 
        {
        case 1:
            nameObj['firstName'] = nameArr[0] || '';
            nameObj['middleName'] = '';
            nameObj['lastName'] = '';
            break;
        case 2:
            nameObj['firstName'] = nameArr[0] || '';
            nameObj['middleName'] = '';
            nameObj['lastName'] = nameArr[1] || '';
            break;
        case 3:
            nameObj['firstName'] = nameArr[0] || '';
            nameObj['middleName'] = nameArr[1] || '';
            nameObj['lastName'] = nameArr[2] || '';
            break;
        default:
            const n = nameArr.length;
            nameObj['firstName'] = nameArr[0] || '';
            nameObj['middleName'] = nameArr[1] || '';
            nameObj['lastName'] = (nameArr.slice(2,n)).join(' ') || '';
        }
    }

    private async readCsvOrAccessDbTable() {
        if (this.accessDbTables.length === 0) {
            const fileData = this.electronService.fs.readFileSync(this.pdfGenerationFormData?.csvFile?.path, { encoding: 'utf8' });
            this.papaParser.parse(fileData, {
                skipEmptyLines: true,
                header: true,
                complete: async (csvRecords: ParseResult) => {
                    if (csvRecords?.data && csvRecords?.data?.length > 0) {
                        this.recordsToProcess = csvRecords.data;
                    }
                }
            })
        } else {
            const fileData = this.electronService.fs.readFileSync(this.pdfGenerationFormData.csvFile.path);
            const reader = new MDBReader(fileData);
            const table = reader.getTable(this.pdfGenerationFormData?.accessDBTable);
            const data = table.getData();
            if (data && data.length > 0) {
                this.recordsToProcess = data;
            }
        }
    }

    public isConfigFileSelected() {
        return !!this.selectedConfig;
    }

    public isDbSelected() {
        return this.dbColumns.length > 0;
    }

    public checkIfConfigRelevant(showErrorMessage = true) {
        if (!this.isConfigFileSelected()) {
            return false;
        }

        const isRelevantConfig = _.filter(this.selectedConfig.mainFields, (x) => x.isRequiredField).every((value) => {
            if (value.defaultValue) {
                return true;
            } else if (value.mappedField) {
                return this.getDbColumns()?.includes(value.mappedField) || false;
            }
            return true;
        });

        if (showErrorMessage && !isRelevantConfig) {
            this.notificationService.notify('invalidConfigFileSelected', NotificationTypeEnum.Danger);
        }

        return isRelevantConfig;
    }

    private getHeadersForReportCsv() {
        let headers = this.selectedConfig?.mainFields.filter(x => x.showInReportCSV).map(x => ({ id: x.id, title: x.label }));
        headers = [...headers, { id: 'status_code', title: 'Status' }, { id: 'status_msg', title: 'Message' }];
        return headers;
    }

    private getHeadersForOutputCsv() {
        let headers = this.selectedConfig?.mainFields.filter(x => x.showInOutputCSV).map(x => ({ id: x.id, title: x.outputCsvHeader }));
        headers = [...headers, { id: 'fileName', title: 'File Name' }];
        return headers;
    }

    private getConfigFileEntry(id: string): ConfigFileFieldEntry | null {
        return this.selectedConfig?.mainFields.find(x => x.id === id) || null;
    }

    // It is being used to reset all stored data inside this service
    public resetStoredData() {
        this.dbColumns = [];
        this.pdfGenerationFormData = null;
        this.recordsToProcess = null;
        this.pdfTemplateBuffer = null;
        this.fontBuffer = null;
        this.accessDbTables = []
        this.selectedConfig = null;
        this.selectedConfigFileName = '';
        this.selectedSubjectCodeMappingFileName = '';
        this.selectedSchoolCenterCodeMappingFileName = '';
        this.subjectCodeMappingData = {};
        this.schoolCenterCodeMappingData = {};
    }
}
