import { Injectable } from '@angular/core';
import { ElectronService } from 'app/core/services';

@Injectable({
    providedIn: 'root'
})
export class ConfigHandlerService {

    constructor(private electronService: ElectronService) { }

    loadConfigFile() {
        this.electronService.fs()
    }
}
