import { Injectable } from '@angular/core';
import { ElectronService } from '../core/services/electron/electron.service'

@Injectable({
    providedIn: 'root'
})
export class LoggerHelperService {
    constructor(private electronService: ElectronService) { }

    async logInfo(...params: any[]): Promise<void> {
        return await this.electronService.ipcRenderer.invoke('logger-logInfo', params)
    }

    async logError(...params: any[]): Promise<void> {
        return await this.electronService.ipcRenderer.invoke('logger-logError', params)
    }
}
