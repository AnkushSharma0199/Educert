import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import * as publicIp from 'public-ip'
import { SignInRequest, UserData } from 'app/app.interface';
import { AppConfig } from 'environments/environment';
import { SessionStoreService } from './session-store.service';
import { ElectronService } from 'app/core/services';

@Injectable({
  providedIn: 'root'
})
export class UserService {
    signinUrl = AppConfig.baseUrl + 'user/reg-user-signin';
    constructor(
        private httpClient: HttpClient,
        private sessionStoreService: SessionStoreService,
        private electronService: ElectronService
    ) { }

    async signin(requestData: SignInRequest): Promise<UserData> {
        // getting current public IP
        // const ipAddress = await publicIp.v4();
        return this.httpClient.post<UserData>(this.signinUrl, requestData).toPromise();
    }

    async signOut(): Promise<void> {
        this.sessionStoreService.removeUserData();
    }
}
