import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AccountData } from 'app/app.interface';
import { AppConfig } from 'environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AccountService {
    constructor(private httpClient: HttpClient) { }

    accountUrl = AppConfig.baseUrl + 'account/';

    async getAccountById(accountId: string): Promise<AccountData> {
        return this.httpClient.get<AccountData>(this.accountUrl + accountId + '/withsettings').toPromise();
    }
}
