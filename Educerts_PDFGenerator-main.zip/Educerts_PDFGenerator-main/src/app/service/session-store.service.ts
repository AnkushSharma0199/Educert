import { EventEmitter, Injectable } from "@angular/core";
import { UserData, AccountData } from '../app.interface';

const USER_DATA_KEY = 'userData';
const ACCOUNT_DATA_KEY = 'accountData';
const APP_CONFIG_KEY = 'appConfig';

@Injectable({
    providedIn: 'root'
})
export class SessionStoreService {
    authUpdated = new EventEmitter<UserData>();
    getUserData(): UserData {
        const data = sessionStorage.getItem(USER_DATA_KEY);
        return JSON.parse(data);
    }

    setUserData(userData: UserData): void {
        sessionStorage.setItem(USER_DATA_KEY, JSON.stringify(userData));
        this.authUpdated.emit(userData);
    }

    getAccountData(): AccountData {
        const data = sessionStorage.getItem(ACCOUNT_DATA_KEY);
        return JSON.parse(data);
    }

    setAccountData(accountData: AccountData): void {
        sessionStorage.setItem(ACCOUNT_DATA_KEY, JSON.stringify(accountData));
    }

    removeUserData(): void {
        sessionStorage.removeItem(USER_DATA_KEY);
        sessionStorage.removeItem(ACCOUNT_DATA_KEY);
        sessionStorage.removeItem(APP_CONFIG_KEY);
        this.authUpdated.emit({});
    }

    updateUserData(propertyToUpdate, valueToSet) {
        const userData = this.getUserData();
        userData[propertyToUpdate] = valueToSet;
        this.setUserData(userData);
    }

    updateAccountSettings(propertyToUpdate, valueToSet) {
        let accountData = this.getAccountData();
        accountData.settings[propertyToUpdate] = valueToSet;
        this.setAccountData(accountData);
    }
}
