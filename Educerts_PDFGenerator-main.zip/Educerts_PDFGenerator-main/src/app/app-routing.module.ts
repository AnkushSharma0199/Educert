import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AppFrameComponent } from './app-frame/app-frame.component';
import { FieldsMappingComponent } from './fields-mapping/fields-mapping.component';
import { HomeComponent } from './home/home.component';
import { GeneratePdfComponent } from './generate-pdf/generate-pdf.component';
import { SigninComponent } from './user/signin/signin.component';

const routes: Routes = [
    { path: 'signin', component: SigninComponent },
    {
        path: 'app-frame', component: AppFrameComponent, children: [
            { path: 'home', component: HomeComponent },
            { path: 'fields-mapping', component: FieldsMappingComponent },
            { path: 'generate-pdf', component: GeneratePdfComponent }
            // { path: 'preview', component: PreviewComponent }
        ]
    },
    // { path: '**', redirectTo: 'app-frame/home' },
    { path: '**', redirectTo: 'app-frame/signin' },
];

@NgModule({
    imports: [RouterModule.forRoot(routes, { useHash: true, relativeLinkResolution: 'legacy' })],
    exports: [RouterModule],
    declarations: [],
})
export class AppRoutingModule { }
