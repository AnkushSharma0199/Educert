import { UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { Global } from './app.global';

export class FormControlValidators {
    public static get None(): UntypedFormControl {
        return new UntypedFormControl('');
    }
    public static get Disabled(): UntypedFormControl {
        return new UntypedFormControl({ value: '', disabled: true });
    }

    public static get Null(): UntypedFormControl {
        return new UntypedFormControl(null);
    }

    public static get Required(): UntypedFormControl {
        return new UntypedFormControl('', [Validators.required]);
    }

    public static get RequiredMinChar2(): UntypedFormControl {
        return new UntypedFormControl('', [
            Validators.required,
            Validators.minLength(2),
        ]);
    }

    public static get MinChar2(): UntypedFormControl {
        return new UntypedFormControl('', [Validators.minLength(2)]);
    }

    public static get RequiredEmail(): UntypedFormControl {
        return new UntypedFormControl('', [Validators.required, Validators.pattern(Global.regex.customEmailField)]);
    }

    public static get Email(): UntypedFormControl {
        return new UntypedFormControl('', [Validators.email]);
    }

    public static get Password(): UntypedFormControl {
        return new UntypedFormControl('', [
            Validators.required,
            Validators.pattern(Global.regex.password),
        ]);
    }

    public static PasswordMatchValidator(g: UntypedFormGroup) {
        return g.get('password').value === g.get('confirmPassword').value
            ? null
            : { mismatch: true };
    }

    public static ResetPasswordMatchValidator(g: UntypedFormControl) {
        if(!g.get('newPassword').value) {
            return null
        }

        if(!g.get('currentPassword').value) {
            return null
        }

        return g.get('newPassword').value === g.get('currentPassword').value
            ? { isEqual: true }
            : null;
    }

    public static get Phone(): UntypedFormControl {
        return new UntypedFormControl('', [
            Validators.pattern(Global.regex.phone),
            Validators.minLength(10),
            Validators.maxLength(10),
        ]);
    }

    public static get Number(): UntypedFormControl {
        return new UntypedFormControl('', [Validators.pattern(Global.regex.number)]);
    }

    public static get MinChar1(): UntypedFormControl {
        return new UntypedFormControl('', [Validators.minLength(1)]);
    }

    public static get NoSpace(): UntypedFormControl {
        return new UntypedFormControl('', [
            Validators.pattern(Global.regex.stringWithNoSpace),
        ]);
    }

    public static get OnlyAlphabets(): UntypedFormControl {
        return new UntypedFormControl('', [
            Validators.pattern(Global.regex.onlyAlphabets),
            Validators.required,
        ]);
    }

    public static get FullNumber(): UntypedFormControl {
        return new UntypedFormControl('', [
            Validators.pattern(Global.regex.fullNumber),
        ]);
    }

    public static get MinimumQuantity(): UntypedFormControl {
        return new UntypedFormControl('', [
            Validators.pattern(Global.regex.fullNumber),
            Validators.min(1),
        ]);
    }

    public static get PostalCode(): UntypedFormControl {
        return new UntypedFormControl('', [
            Validators.pattern(Global.regex.postalCode),
        ]);
    }

    public static get AadharNumber(): UntypedFormControl {
        return new UntypedFormControl('', [
            Validators.pattern(Global.regex.aadharNumber),
        ]);
    }
    public static get Year(): UntypedFormControl {
        return new UntypedFormControl('', [Validators.pattern(Global.regex.year)]);
    }
}
