const global = {
    regex: {
        stringWithNoSpace: /^\S+$/,
        onlyAlphabets: /^[a-zA-Z ]*$/,
        password: /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9]).{8,20}$/,
        phone: /^\+?[0-9\.\-\(\)\s]+$/,
        number: /^(0|(0*[1-9][0-9]*(\.\d\d?)?)|(0?\.\d\d?))$/,
        removeHtmlTag: /<[^>]*>/g,
        replaceUnderscoreWithSpace: /_/g,
        customEmailField: /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[a-z]{2,4}$/,
        fax: /^\+?[0-9\.\-\(\)\s]+$/,
        fullNumber: /^[0-9]+$/,
        year: /^\d{4}$/,
        postalCode: /^[1-9][0-9]{5}$/,
        aadharNumber: /^([0-9]){12}$/,
        onlyNumbers: /^[0-9]*$/,
        specialCharacters: /[^a-zA-Z0-9 ]/g,
        extraSpaces: /\s{2,}/g,
    },
};

export const Global = Object.freeze(global);
