import { Component, NgZone, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SessionStoreService } from 'app/service/session-store.service';
import { SharedService } from 'app/service/shared.service';
import { UserService } from 'app/service/user.service';

@Component({
    selector: 'app-frame',
    templateUrl: './app-frame.component.html',
    styleUrls: ['./app-frame.component.scss']
})
export class AppFrameComponent implements OnInit, OnDestroy {
    constructor(
        private router: Router,
        private userService: UserService,
        private sharedService: SharedService,
        private sessionStoreService: SessionStoreService
    ) { }

    async ngOnInit(): Promise<void> {

    }

    ngOnDestroy(): void {
    }

    signOut(): void {
        this.userService.signOut();
        this.router.navigate(['signin'])
    }

    getOrganizationName(): string {
        return this.sessionStoreService.getAccountData()?.organizationName;
    }

    getUserName(): string {
        const userInfo = this.sessionStoreService.getUserData();
        return this.sharedService.getFullName(userInfo.firstName, userInfo.middleName, userInfo.lastName)
    }

    getUserRoleName(): string {
        const userInfo = this.sessionStoreService.getUserData();
        return this.sharedService.getUserRoleName(userInfo.role)
    }
}
