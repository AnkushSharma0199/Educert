import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { AppFrameComponent } from "./app-frame.component";
import { TranslateModule } from "@ngx-translate/core";
import { RouterModule } from "@angular/router";
import { CoreModule } from "../core/core.module";

@NgModule({
    declarations: [
        AppFrameComponent,
    ],
    imports: [
        CommonModule,
        CoreModule,
        TranslateModule,
        RouterModule,
    ],
    providers: [
    ]
})
export class AppFrameModule {}
