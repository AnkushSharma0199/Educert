export const AppConfig = {
    production: false,
    environment: 'DEV',
    baseUrl: 'http://localhost:3000/',
    appVersion: '2.2345.4',
    // config values specific to UI
    uiSettings: {
        // Duration for which to show snackbar
        snackBarDurationInSec: 3500,
    },
    customFields: {
        allowedCount: 5
    },
    csv: {
        outputCsvName: 'Bulk_Import.csv',
        reportCsvNamePrefix: 'Report_'
    },
    pdfGeneration: {
        batch: 1000
    }
};
