export const AppConfig = {
    production: false,
    environment: 'WEB',
    baseUrl: 'http://localhost:3000/',
    appVersion: '23.44.8',
    // config values specific to UI
    uiSettings: {
        // Duration for which to show snackbar
        snackBarDurationInSec: 3500,
    },
    customFields: {
        allowedCount: 5
    },
    csv: {
        outputCsvName: 'Bulk-Import.csv',
        reportCsvNamePrefix: 'Report_'
    },
    pdfGeneration: {
        batch: 1000
    }
};
