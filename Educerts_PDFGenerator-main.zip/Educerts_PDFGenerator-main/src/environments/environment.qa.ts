export const AppConfig = {
    production: true,
    environment: 'QA',
    baseUrl: 'https://api.layered-security.com/v2/',
    appVersion: '23.44.8',
   // config values specific to UI
    uiSettings: {
        // Duration for which to show snackbar
        snackBarDurationInSec: 3500,
    },
    customFields: {
        allowedCount: 5
    },
    csv: {
        outputCsvName: 'Bulk-Import.csv',
        reportCsvNamePrefix: 'Report_'
    },
    pdfGeneration: {
        batch: 1000
    }
};
